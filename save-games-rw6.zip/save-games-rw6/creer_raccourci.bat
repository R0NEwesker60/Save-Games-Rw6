@echo off
rem Cree un raccourci "Save Games Rw6" sur le Bureau, avec l'icone icone.ico (si elle est a cote de ce fichier).
rem Le fichier .pyw doit se trouver dans le meme dossier que ce fichier.
setlocal
set "APPDIR=%~dp0"
set "SCRIPT="
for %%f in ("%APPDIR%*.pyw") do set "SCRIPT=%%~ff"
if not defined SCRIPT (
  echo Aucun fichier .pyw trouve a cote de ce fichier.
  pause
  exit /b 1
)
set "ICON=%APPDIR%icone.ico"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'Save Games Rw6.lnk')); $s.TargetPath=$env:SCRIPT; $s.WorkingDirectory=$env:APPDIR; if (Test-Path $env:ICON) { $s.IconLocation=$env:ICON }; $s.Save()"
echo.
if errorlevel 1 (
  echo Le raccourci n'a pas pu etre cree.
) else (
  echo Raccourci "Save Games Rw6" cree sur le Bureau.
  if not exist "%ICON%" echo Ajoutez un fichier icone.ico a cote de ce fichier puis relancez-le pour avoir votre icone.
)
echo.
pause
