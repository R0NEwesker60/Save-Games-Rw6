@echo off
rem Crée un raccourci « Save Games Rw6 » sur le Bureau.
rem Si icone.ico est à côté du script, elle sert d’icône.
cd /d "%~dp0"
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Save Games Rw6.lnk'); $s.TargetPath='%~dp0save_games_rw6.pyw'; $s.WorkingDirectory='%~dp0'; if (Test-Path '%~dp0icone.ico') { $s.IconLocation='%~dp0icone.ico' }; $s.Save()"
echo Raccourci cree sur le Bureau.
pause
