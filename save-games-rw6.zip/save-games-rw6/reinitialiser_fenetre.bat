@echo off
rem Remet la fenetre de l'appli de sauvegarde a sa taille et sa place par defaut.
rem Fermez d'abord l'appli, puis double-cliquez sur ce fichier.
del "%~dp0fenetre.json" 2>nul
echo.
echo La taille et la position de la fenetre ont ete reinitialisees.
echo Relancez l'appli de sauvegarde.
echo.
pause
