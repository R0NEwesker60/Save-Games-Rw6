@echo off
rem Remet la fenêtre à sa taille et à sa place d’origine.
cd /d "%~dp0"
if exist fenetre.json del fenetre.json
echo Fenetre reinitialisee. Relancez l’appli.
pause
