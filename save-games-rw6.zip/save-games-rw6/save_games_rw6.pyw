"""Save Games Rw6 : un bouton par jeu, des onglets par jeu, une note par sauvegarde.

Copyright (c) 2026 Rw6 — licence MIT (voir le fichier LICENSE).

Lancement : double-clic sur le fichier (Python installé). L’extension .pyw évite d’ouvrir un terminal.
Les sauvegardes sont rangées dans le dossier « Sauvegardes » à côté de ce fichier.

Glisser-déposer vers l’Explorateur : `py -m pip install tkinterdnd2` (une seule fois).
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import tkinter as tk
import tkinter.font as tkfont
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

try:
    from tkinterdnd2 import COPY, DND_FILES, TkinterDnD
    BaseWindow = TkinterDnD.Tk
    HAS_DND = True
except Exception:  # bibliothèque absente : l’appli marche, sans le glisser-déposer
    BaseWindow = tk.Tk
    HAS_DND = False

APP_DIR = Path(__file__).resolve().parent
BACKUP_DIR = APP_DIR / "Sauvegardes"
CONFIG_FILE = APP_DIR / "config.json"
NOTES_FILE = APP_DIR / "notes.json"      # une note par sauvegarde
WINDOW_FILE = APP_DIR / "fenetre.json"   # taille et position de la fenêtre
DISPLAY_FILE = APP_DIR / "affichage.json"   # taille du texte
LIMITS_FILE = APP_DIR / "limites.json"   # limite de sauvegardes par jeu (optionnelle)
FAVORITES_FILE = APP_DIR / "favoris.json"   # sauvegardes marquées ★ (protégées)
ICON_FILE = APP_DIR / "icone.ico"          # facultatif : icône de la fenêtre et de la barre des tâches
NOTE_FILE = "Note.txt"                   # la note est aussi écrite dans le dossier de la sauvegarde
DEFAULT_LIMIT = {"on": False, "max": 6}

ZOOM_STEPS = (70, 80, 90, 100, 110, 125, 150, 175, 200)  # taille du texte, en %
FONT_NAMES = ("TkDefaultFont", "TkTextFont", "TkHeadingFont", "TkMenuFont", "TkIconFont")
DEFAULT_GAMES = {}  # version publique : on part d’une liste vide, chacun ajoute ses jeux

STAMP_FR = "%d-%m-%Y_%H-%M-%S"   # date des dossiers : MonJeu_01-11-2026_14-30-00
STAMP_OLD = "%Y-%m-%d_%H-%M-%S"  # ancien format, encore reconnu

# Thème sombre
BG, PANEL, FG = "#16191d", "#1f2429", "#e8eaed"
MUTED, ACCENT, ERR, LINE = "#9aa3ad", "#3d7fc4", "#ff7b72", "#343b43"


def log_error(text):
    """Sans terminal, les erreurs seraient invisibles : on les note dans erreurs.log."""
    try:
        with open(APP_DIR / "erreurs.log", "a", encoding="utf-8") as f:
            f.write(f"--- {datetime.now():%d/%m/%Y %H:%M:%S}\n{text}\n")
    except OSError:
        pass


def load_config():
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict) and data:
            return data
    except (OSError, ValueError):
        pass
    return dict(DEFAULT_GAMES)


def save_config(games):
    CONFIG_FILE.write_text(json.dumps(games, indent=2, ensure_ascii=False), encoding="utf-8")


def load_notes():
    """Notes rangées sous la clé « jeu/dossier-de-la-sauvegarde »."""
    try:
        data = json.loads(NOTES_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {str(k): str(v) for k, v in data.items()}
    except (OSError, ValueError):
        pass
    return {}


def save_notes(notes):
    NOTES_FILE.write_text(json.dumps(notes, indent=2, ensure_ascii=False), encoding="utf-8")


def remap_notes(notes, old, new):
    """Quand un jeu est renommé, ses notes suivent le nouveau nom des dossiers."""
    out = {}
    for key, text in notes.items():
        game, _, folder = key.partition("/")
        if game == old:
            d = parse_stamp(folder)
            if d:
                folder = f"{new}_{d.strftime(STAMP_FR)}"
            game = new
        out[f"{game}/{folder}"] = text
    return out


def load_zoom():
    """Taille du texte enregistrée (en %), ramenée au cran le plus proche ; 100 par défaut."""
    try:
        z = int(json.loads(DISPLAY_FILE.read_text(encoding="utf-8")).get("zoom", 100))
        return min(ZOOM_STEPS, key=lambda step: abs(step - z))
    except (OSError, ValueError, AttributeError, TypeError):
        return 100


def save_zoom(zoom):
    try:
        DISPLAY_FILE.write_text(json.dumps({"zoom": zoom}), encoding="utf-8")
    except OSError:
        pass


def scaled_size(base, pct):
    """Taille d’une police après zoom (une taille négative = en pixels, on garde le signe)."""
    sign = -1 if base < 0 else 1
    return sign * max(6, round(abs(base) * pct / 100))


def load_limits():
    """Limite par jeu : {jeu: {"on": bool, "max": int}}. Désactivée tant qu’on ne l’a pas choisie."""
    try:
        data = json.loads(LIMITS_FILE.read_text(encoding="utf-8"))
        return {str(g): {"on": bool(v.get("on", False)), "max": min(99, max(1, int(v.get("max", 6))))}
                for g, v in data.items()}
    except (OSError, ValueError, AttributeError, TypeError):
        return {}


def save_limits(limits):
    LIMITS_FILE.write_text(json.dumps(limits, indent=2, ensure_ascii=False), encoding="utf-8")


def remap_limits(limits, old, new):
    return {(new if k == old else k): v for k, v in limits.items()}


def write_note_file(folder, text):
    """Écrit (ou efface si la note est vide) Note.txt dans le dossier d’une sauvegarde."""
    target = Path(folder) / NOTE_FILE
    try:
        if text:
            try:
                current = target.read_text(encoding="utf-8")
            except (OSError, ValueError):
                current = None
            if current != text + "\n":
                target.write_text(text + "\n", encoding="utf-8")
        elif target.exists():
            target.unlink()
    except OSError:
        pass


def sync_note_files(notes):
    """Remet Note.txt à jour dans chaque dossier de sauvegarde qui a une note."""
    for key, text in notes.items():
        game, _, folder = key.partition("/")
        d = BACKUP_DIR / game / folder
        if d.is_dir():
            write_note_file(d, text)


def load_favorites():
    """Ensemble de clés « jeu/dossier » des sauvegardes favorites."""
    try:
        data = json.loads(FAVORITES_FILE.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return {str(k) for k in data}
    except (OSError, ValueError):
        pass
    return set()


def save_favorites(favs):
    FAVORITES_FILE.write_text(json.dumps(sorted(favs), indent=2, ensure_ascii=False), encoding="utf-8")


def remap_favorites(favs, old, new):
    """Quand un jeu est renommé, ses favoris suivent le nouveau nom des dossiers."""
    out = set()
    for key in favs:
        game, _, folder = key.partition("/")
        if game == old:
            d = parse_stamp(folder)
            if d:
                folder = f"{new}_{d.strftime(STAMP_FR)}"
            game = new
        out.add(f"{game}/{folder}")
    return out


def backups_to_prune(game, keep, favorites=()):
    """Les sauvegardes les plus anciennes au-delà de `keep`. Les favoris ★ ne sont jamais
    concernés (et ne comptent pas dans le total), ni les dossiers dont le nom ne se termine
    pas par une date de sauvegarde : un dossier à vous n’est jamais touché."""
    mine = [b for _g, b in list_backups(game)
            if parse_stamp(b.name) and f"{game}/{b.name}" not in favorites]
    return mine[keep:]


def load_window():
    """Renvoie (largeur, hauteur, x, y, agrandie) ou None si rien n’est encore enregistré."""
    try:
        d = json.loads(WINDOW_FILE.read_text(encoding="utf-8"))
        x, y = d.get("x"), d.get("y")
        return (int(d["width"]), int(d["height"]),
                int(x) if x is not None else None, int(y) if y is not None else None,
                bool(d.get("zoomed", False)))
    except (OSError, ValueError, KeyError, TypeError):
        return None


def parse_geometry(geo):
    """'900x700+120+40' -> (900, 700, 120, 40). Gère aussi les positions négatives (autre écran)."""
    m = re.match(r"(\d+)x(\d+)([+-])(-?\d+)([+-])(-?\d+)$", geo)
    if not m:
        return None
    w, h, sx, x, sy, y = m.groups()
    return int(w), int(h), (int(x) if sx == "+" else -int(x)), (int(y) if sy == "+" else -int(y))


def position_visible(x, y, w, vx, vy, vw, vh):
    """Vrai si le haut de la fenêtre (barre de titre) est assez visible sur le bureau (tous écrans)."""
    return vx - w + 100 <= x <= vx + vw - 100 and vy <= y <= vy + vh - 60


def valid_name(name):
    return bool(name) and not any(c in name for c in '\\/:*?"<>|') and name == name.rstrip(" .")


def parse_stamp(name):
    """Lit la date à la fin du nom du dossier (avec ou sans le nom du jeu devant)."""
    tail = name[-19:]
    for fmt in (STAMP_FR, STAMP_OLD):
        try:
            return datetime.strptime(tail, fmt)
        except ValueError:
            pass
    return None


def size_of(path):
    """Poids total d’un dossier ou fichier ; ignore ce qui disparaît pendant le calcul."""
    path = Path(path)
    total = 0
    try:
        if path.is_file():
            return path.stat().st_size
        for f in path.rglob("*"):
            try:
                if f.is_file() and not (f.name == NOTE_FILE and f.parent == path):
                    total += f.stat().st_size
            except OSError:
                pass
    except OSError:
        pass
    return total


def human(n):
    for unit in ("o", "Ko", "Mo", "Go"):
        if n < 1024 or unit == "Go":
            return f"{n:.0f} {unit}" if unit == "o" else f"{n:.1f} {unit}"
        n /= 1024


def open_folder(path):
    path = str(path)
    if sys.platform.startswith("win"):
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


class VerificationError(Exception):
    """La copie n’est pas identique à l’original."""


def files_of(root):
    """{chemin relatif: chemin réel} de tous les fichiers d’un dossier (ou du fichier seul)."""
    root = Path(root)
    if root.is_file():
        return {Path(root.name): root}
    return {f.relative_to(root): f for f in root.rglob("*") if f.is_file()}


def file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_copy(src, dst):
    """Compare une copie à son original : fichiers présents, tailles et contenu (SHA-256).
    Renvoie la liste des problèmes trouvés (vide = copie identique)."""
    problems = []
    try:
        a, b = files_of(src), files_of(dst)
    except OSError as e:
        return [f"lecture impossible ({e})"]
    for rel in sorted(a):
        if rel not in b:
            problems.append(f"fichier manquant dans la copie : {rel.as_posix()}")
            continue
        try:
            if a[rel].stat().st_size != b[rel].stat().st_size or file_hash(a[rel]) != file_hash(b[rel]):
                problems.append(f"contenu différent : {rel.as_posix()}")
        except OSError as e:
            problems.append(f"lecture impossible : {rel.as_posix()} ({e})")
    for rel in sorted(set(b) - set(a)):
        problems.append(f"fichier en trop dans la copie : {rel.as_posix()}")
    return problems


def _copy_once(source, dest):
    if source.is_dir():
        shutil.copytree(source, dest)
    else:
        dest.mkdir(parents=True)
        shutil.copy2(source, dest)


def make_backup(game, source, now=None):
    """Copie `source` (dossier ou fichier) dans Sauvegardes/<jeu>/<jeu>_<JJ-MM-AAAA_HH-MM-SS>,
    puis vérifie que la copie est identique. En cas d’écart, une deuxième tentative est faite ;
    si elle échoue aussi, la copie défectueuse est supprimée et une erreur est levée."""
    source = Path(source)
    if not source.exists():
        raise FileNotFoundError(f"Le chemin n’existe pas : {source}")
    dest = BACKUP_DIR / game / f"{game}_{(now or datetime.now()).strftime(STAMP_FR)}"
    if dest.exists():
        raise FileExistsError("Une sauvegarde existe déjà pour cette seconde, réessayez.")
    problems = []
    for _attempt in range(2):
        _copy_once(source, dest)
        problems = verify_copy(source, dest)
        if not problems:
            return dest
        shutil.rmtree(dest, ignore_errors=True)
    raise VerificationError(
        "La copie n’est pas identique à l’original, elle a été supprimée.\n"
        "Le jeu ou l’émulateur est peut-être en train d’écrire sa sauvegarde : fermez-le et réessayez.\n\n"
        + "\n".join(problems[:5]))


def list_backups(game=None):
    """Liste (jeu, dossier) triée de la plus récente à la plus ancienne."""
    found = []
    if BACKUP_DIR.is_dir():
        for gdir in BACKUP_DIR.iterdir():
            if gdir.is_dir() and (game is None or gdir.name == game):
                found.extend((gdir.name, b) for b in gdir.iterdir() if b.is_dir())
    return sorted(found, key=lambda t: parse_stamp(t[1].name) or datetime.min, reverse=True)


def migrate_old_names():
    """Met tous les dossiers au format <jeu>_JJ-MM-AAAA_HH-MM-SS (anciens noms et jeux renommés)."""
    for game, b in list_backups():
        d = parse_stamp(b.name)
        if d is None:
            continue
        target = b.with_name(f"{game}_{d.strftime(STAMP_FR)}")
        if target.name != b.name and not target.exists():
            try:
                b.rename(target)
            except OSError:
                pass


class App(BaseWindow):
    def __init__(self):
        super().__init__()
        self.set_icon()
        self.title("Save Games Rw6")
        w, h, x, y, zoomed = load_window() or (780, 620, None, None, False)
        w = max(700, min(w, self.winfo_screenwidth()))   # jamais plus grande que l’écran
        h = max(520, min(h, self.winfo_screenheight()))
        if x is not None and y is not None and not position_visible(
                x, y, w, self.winfo_vrootx(), self.winfo_vrooty(),
                self.winfo_vrootwidth(), self.winfo_vrootheight()):
            x = y = None  # position hors écran : on laisse Windows placer la fenêtre
        self.geometry(f"{w}x{h}" if x is None else f"{w}x{h}+{x}+{y}")
        self.normal_geo = (w, h, x, y)
        self._save_job = None
        if zoomed:
            try:
                self.state("zoomed")
            except tk.TclError:
                pass
        self.bind("<Configure>", self.on_configure)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self._base_fonts = {}
        for name in FONT_NAMES:  # tailles de départ, avant tout zoom
            try:
                self._base_fonts[name] = tkfont.nametofont(name).cget("size")
            except tk.TclError:
                pass
        self.font_bold = tkfont.nametofont("TkDefaultFont").copy()
        self.font_bold.configure(weight="bold")
        self.zoom = load_zoom()
        self.set_fonts()
        self.update_minsize()
        self.apply_theme()
        self.games = load_config()
        self.notes = load_notes()
        sync_note_files(self.notes)
        self.limits = load_limits()
        self.favorites = load_favorites()
        self._vars = []
        self.trees = {}
        self._sig = ()              # « empreinte » de la liste, pour savoir si elle a changé
        self._last_check = 0.0
        self._lasso_active = False  # vrai pendant qu’on trace un rectangle de sélection

        self.cards = tk.Frame(self)
        self.cards.pack(fill="x", padx=12, pady=(12, 6))
        bar = tk.Frame(self)
        bar.pack(fill="x", padx=12)
        ttk.Button(bar, text="Ajouter un jeu", command=self.add_game).pack(side="left")
        zoom_box = tk.Frame(bar)
        zoom_box.pack(side="right")
        tk.Label(zoom_box, text="Taille du texte", fg=MUTED).pack(side="left", padx=(0, 6))
        ttk.Button(zoom_box, text="A−", width=3, command=lambda: self.step_zoom(-1)).pack(side="left")
        self.zoom_label = tk.Label(zoom_box, text=f"{self.zoom} %", width=6)
        self.zoom_label.pack(side="left")
        ttk.Button(zoom_box, text="A+", width=3, command=lambda: self.step_zoom(1)).pack(side="left")
        for seq in ("<Control-plus>", "<Control-equal>", "<Control-KP_Add>"):
            self.bind(seq, lambda e: self.step_zoom(1))
        for seq in ("<Control-minus>", "<Control-KP_Subtract>"):
            self.bind(seq, lambda e: self.step_zoom(-1))
        self.bind("<Control-Key-0>", lambda e: self.change_zoom(100))

        tk.Label(self, text="Sauvegardes faites", font=self.font_bold, anchor="w").pack(
            fill="x", padx=12, pady=(14, 4))
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=12)

        if HAS_DND:
            hint = "Glissez une sauvegarde de la liste vers un dossier pour la copier."
        else:
            hint = "Glisser-déposer : installez-le avec  py -m pip install tkinterdnd2  puis relancez."
        tk.Label(self, text=hint, anchor="w", fg=MUTED).pack(fill="x", padx=12, pady=(4, 0))

        actions = tk.Frame(self)
        actions.pack(fill="x", padx=12, pady=10)
        ttk.Button(actions, text="Copier vers…", command=self.copy_selected).pack(side="left")
        ttk.Button(actions, text="Ouvrir le dossier", command=self.open_selected).pack(side="left", padx=6)
        ttk.Button(actions, text="Note…", command=self.edit_note).pack(side="left")
        ttk.Button(actions, text="★ Favori", command=self.toggle_favorite).pack(side="left", padx=6)
        ttk.Button(actions, text="Supprimer", command=self.delete_selected).pack(side="left")
        self.status = tk.Label(actions, text="", anchor="e", fg=MUTED)
        self.status.pack(side="right")

        self.refresh()
        self.dark_titlebar()
        self.bind("<FocusIn>", self.on_focus, add="+")
        self.after(10000, self.tick)

    def set_icon(self):
        """Utilise icone.ico (à côté du script) pour la fenêtre, ses boîtes de dialogue et la barre des tâches."""
        if sys.platform.startswith("win") and ICON_FILE.is_file():
            try:
                self.iconbitmap(str(ICON_FILE))
                self.iconbitmap(default=str(ICON_FILE))
            except tk.TclError:
                pass  # fichier .ico invalide : on garde l’icône par défaut

    # ----- taille du texte -----
    def set_fonts(self):
        for name, base in self._base_fonts.items():
            tkfont.nametofont(name).configure(size=scaled_size(base, self.zoom))
        size = tkfont.nametofont("TkDefaultFont").cget("size")
        self.font_bold.configure(size=size + (2 if size > 0 else -2))

    def row_height(self):
        return tkfont.nametofont("TkDefaultFont").metrics("linespace") + 12

    def update_minsize(self):
        k = self.zoom / 100
        self.minsize(min(max(520, int(700 * k)), self.winfo_screenwidth()),
                     min(max(420, int(520 * k)), self.winfo_screenheight()))

    def step_zoom(self, delta):
        i = ZOOM_STEPS.index(self.zoom) + delta
        if 0 <= i < len(ZOOM_STEPS):
            self.change_zoom(ZOOM_STEPS[i])

    def change_zoom(self, pct):
        if pct == self.zoom:
            return
        ratio = pct / self.zoom
        self.zoom = pct
        self.set_fonts()
        ttk.Style(self).configure("Treeview", rowheight=self.row_height())
        self.zoom_label.config(text=f"{pct} %")
        self.update_minsize()
        if ratio > 1 and self.state() == "normal":  # texte plus grand : on agrandit la fenêtre d’autant
            self.geometry(f"{min(self.winfo_screenwidth(), int(self.winfo_width() * ratio))}x"
                          f"{min(self.winfo_screenheight(), int(self.winfo_height() * ratio))}")
        save_zoom(pct)
        self.refresh()

    # ----- actualisation automatique -----
    def signature(self):
        return tuple((g, b.name, size_of(b)) for g, b in list_backups())

    def auto_refresh(self):
        """Recharge la liste seulement si quelque chose a changé sur le disque."""
        if self.grab_current() is not None or self._lasso_active:
            return  # une boîte de dialogue est ouverte, ou on trace un rectangle
        try:
            if self.signature() != self._sig:
                self.refresh()
        except Exception:
            import traceback
            log_error(traceback.format_exc())

    def on_focus(self, event):
        # quand on revient de l’Explorateur, on vérifie (au plus une fois par seconde)
        if time.monotonic() - self._last_check > 1.0:
            self._last_check = time.monotonic()
            self.after(100, self.auto_refresh)

    def tick(self):
        self.auto_refresh()
        self.after(10000, self.tick)

    def report_callback_exception(self, exc, val, tb):
        import traceback
        log_error("".join(traceback.format_exception(exc, val, tb)))
        messagebox.showerror("Erreur", f"{val}\n\nDétails dans le fichier erreurs.log, à côté de l’appli.")

    # ----- taille de la fenêtre -----
    def on_configure(self, event):
        if event.widget is not self:
            return
        if self.state() == "normal":
            g = parse_geometry(self.geometry())
            if g:
                self.normal_geo = g
        if self._save_job:
            self.after_cancel(self._save_job)
        self._save_job = self.after(500, self.save_window)

    def save_window(self):
        w, h, x, y = self.normal_geo
        data = {"width": w, "height": h, "x": x, "y": y, "zoomed": self.state() == "zoomed"}
        try:
            WINDOW_FILE.write_text(json.dumps(data), encoding="utf-8")
        except OSError:
            pass

    def on_close(self):
        self.save_window()
        self.destroy()

    # ----- thème -----
    def apply_theme(self):
        self.configure(bg=BG)
        for pattern, value in (("*Background", BG), ("*Foreground", FG),
                               ("*Entry.Background", PANEL), ("*Entry.Foreground", FG),
                               ("*Entry.insertBackground", FG),
                               ("*selectBackground", ACCENT), ("*selectForeground", "#ffffff")):
            self.option_add(pattern, value)
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure(".", background=BG, foreground=FG, fieldbackground=PANEL,
                     bordercolor=LINE, lightcolor=PANEL, darkcolor=PANEL, troughcolor=BG)
        st.configure("TButton", background=PANEL, foreground=FG, padding=(10, 5), borderwidth=1)
        st.map("TButton", background=[("pressed", ACCENT), ("active", "#2b323a")])
        st.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG,
                     rowheight=self.row_height(), borderwidth=0)
        st.map("Treeview", background=[("selected", ACCENT)], foreground=[("selected", "#ffffff")])
        st.configure("Treeview.Heading", background="#2b323a", foreground=FG, relief="flat", padding=4)
        st.map("Treeview.Heading", background=[("active", "#353d46")])
        st.configure("TCheckbutton", background=BG, foreground=FG, focuscolor=BG)
        st.map("TCheckbutton", background=[("active", BG)],
               indicatorcolor=[("selected", ACCENT), ("!selected", PANEL)])
        st.configure("TSpinbox", fieldbackground=PANEL, foreground=FG, background="#2b323a",
                     bordercolor=LINE, arrowcolor=FG, insertcolor=FG)
        st.configure("TNotebook", background=BG, borderwidth=0, tabmargins=(0, 4, 0, 0))
        st.configure("TNotebook.Tab", background=PANEL, foreground=MUTED, padding=(16, 6),
                     borderwidth=0, focuscolor=PANEL)
        st.map("TNotebook.Tab", background=[("selected", "#2b323a"), ("active", "#262d34")],
               foreground=[("selected", FG), ("active", FG)])
        for sb in ("TScrollbar", "Vertical.TScrollbar"):
            st.configure(sb, background="#3a424b", troughcolor=BG, bordercolor=BG,
                         lightcolor="#3a424b", darkcolor="#3a424b", arrowcolor=FG, gripcount=0)
            st.map(sb, background=[("pressed", ACCENT), ("active", "#566170")],
                   lightcolor=[("pressed", ACCENT), ("active", "#566170")],
                   darkcolor=[("pressed", ACCENT), ("active", "#566170")],
                   arrowcolor=[("disabled", MUTED)])

    def dark_titlebar(self):
        """Barre de titre sombre sous Windows 10/11 (sinon elle reste blanche)."""
        if not sys.platform.startswith("win"):
            return
        try:
            import ctypes
            self.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(self.winfo_id())
            value = ctypes.c_int(1)
            for attr in (20, 19):  # 20 : Windows récent, 19 : anciennes versions de Windows 10
                if ctypes.windll.dwmapi.DwmSetWindowAttribute(
                        hwnd, attr, ctypes.byref(value), ctypes.sizeof(value)) == 0:
                    break
        except Exception:
            pass

    # ----- affichage -----
    def current_tree(self):
        return self.trees.get(self.nb.select())

    def add_tab(self, title, game, rows):
        frame = tk.Frame(self.nb)
        self.nb.add(frame, text=title)
        cols = ("fav", "jeu", "date", "taille", "note")
        tree = ttk.Treeview(frame, columns=cols, show="headings", selectmode="extended")
        tree.tag_configure("vide", foreground=ERR)  # sauvegarde de 0 octet : texte en rouge
        for c, label, w, stretch, anchor in (("fav", "★", 36, False, "center"), ("jeu", "Jeu", 110, False, "w"),
                                             ("date", "Date", 190, False, "w"), ("taille", "Taille", 90, False, "w"),
                                             ("note", "Note", 260, True, "w")):
            tree.heading(c, text=label)
            tree.column(c, width=int(w * self.zoom / 100), anchor=anchor, stretch=stretch)
        # dans l’onglet d’un jeu, la colonne « Jeu » est inutile
        tree["displaycolumns"] = cols if game is None else ("fav", "date", "taille", "note")
        sb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        tree.bind("<Double-1>", lambda e: self.open_selected())
        tree.bind("<Control-a>", lambda e: (tree.selection_set(tree.get_children()), "break")[1])
        tree.bind("<Delete>", lambda e: self.delete_selected())
        tree.bind("<Button-3>", lambda e, t=tree: self.show_menu(t, e))
        if sys.platform == "darwin":  # Mac : clic droit = Button-2 ou Ctrl + clic
            tree.bind("<Button-2>", lambda e, t=tree: self.show_menu(t, e))
            tree.bind("<Control-Button-1>", lambda e, t=tree: self.show_menu(t, e))
        self.bind_lasso(tree)
        if HAS_DND:
            tree.drag_source_register(1, DND_FILES)
            tree.dnd_bind("<<DragInitCmd>>", self.on_drag_init)
        for g, b, date, size, note in rows:
            if game is None or g == game:
                star = "★" if f"{g}/{b.name}" in self.favorites else ""
                tree.insert("", "end", iid=str(b), values=(star, g, date, human(size), note),
                            tags=("vide",) if size == 0 else ())
        self.trees[str(frame)] = tree

    def bind_lasso(self, tree):
        """Rectangle de sélection : on appuie dans la zone vide sous les lignes et on glisse.
        (Ctrl enfoncé : on ajoute à la sélection existante.)"""
        st = {"start": None, "base": (), "lines": []}

        def press(e):
            if tree.identify_region(e.x, e.y) != "nothing":
                st["start"] = None
                return
            ctrl = bool(e.state & 0x4)
            st["start"] = (e.x, e.y)
            st["base"] = tuple(tree.selection()) if ctrl else ()
            if not ctrl:
                tree.selection_set(())
            self._lasso_active = True
            if not st["lines"]:
                st["lines"] = [tk.Frame(tree, bg=ACCENT) for _ in range(4)]

        def motion(e):
            if not st["start"]:
                return
            l, r = sorted((st["start"][0], e.x))
            t, b = sorted((st["start"][1], e.y))
            top, bottom, left, right = st["lines"]
            top.place(x=l, y=t, width=r - l + 1, height=1)
            bottom.place(x=l, y=b, width=r - l + 1, height=1)
            left.place(x=l, y=t, width=1, height=b - t + 1)
            right.place(x=r, y=t, width=1, height=b - t + 1)
            hits = []
            for iid in tree.get_children():
                bb = tree.bbox(iid)
                if bb and bb[1] < b and bb[1] + bb[3] > t and bb[0] < r and bb[0] + bb[2] > l:
                    hits.append(iid)
            tree.selection_set(tuple(dict.fromkeys(st["base"] + tuple(hits))))

        def release(e):
            for f in st["lines"]:
                f.destroy()
            st["lines"] = []
            st["start"] = None
            self._lasso_active = False

        tree.bind("<ButtonPress-1>", press, add="+")
        tree.bind("<B1-Motion>", motion, add="+")
        tree.bind("<ButtonRelease-1>", release, add="+")

    def refresh(self):
        for w in self.cards.winfo_children():
            w.destroy()
        self._vars = []
        if not self.games:
            tk.Label(self.cards, text="Aucun jeu pour l’instant. Cliquez sur « Ajouter un jeu » pour commencer.",
                     fg=MUTED, anchor="w").pack(fill="x", pady=8)
        for name, path in self.games.items():
            box = tk.LabelFrame(self.cards, text=name, padx=8, pady=6, bg=BG, fg=FG,
                                highlightbackground=LINE)
            box.pack(fill="x", pady=3)
            backups = list_backups(name)
            if backups:
                last = parse_stamp(backups[0][1].name)
                when = f"{last:%d/%m/%Y à %H:%M}" if last else backups[0][1].name
                info = f"{len(backups)} sauvegarde(s), dernière le {when}"
            else:
                info = "Aucune sauvegarde pour l’instant"
            tk.Label(box, text=path or "Chemin des sauvegardes du jeu à définir", anchor="w",
                     fg=FG if path else ERR, wraplength=int(560 * self.zoom / 100), justify="left").pack(fill="x")
            tk.Label(box, text=info, anchor="w", fg=MUTED).pack(fill="x")
            row = tk.Frame(box)
            row.pack(fill="x", pady=(4, 0))
            ttk.Button(row, text=f"Sauvegarder {name}",
                       command=lambda n=name: self.backup(n)).pack(side="left")
            ttk.Button(row, text="Dossier…",
                       command=lambda n=name: self.pick(n, folder=True)).pack(side="left", padx=6)
            ttk.Button(row, text="Fichier…",
                       command=lambda n=name: self.pick(n, folder=False)).pack(side="left")
            ttk.Button(row, text="Renommer",
                       command=lambda n=name: self.rename_game(n)).pack(side="left", padx=6)

            lim = self.limits.get(name, DEFAULT_LIMIT)
            on_var, max_var = tk.BooleanVar(value=lim["on"]), tk.StringVar(value=str(lim["max"]))
            self._vars.extend((on_var, max_var))
            commit = lambda n=name, o=on_var, m=max_var: self.commit_limit(n, o, m)
            row2 = tk.Frame(box)
            row2.pack(fill="x", pady=(6, 0))
            ttk.Checkbutton(row2, text="Garder au maximum", variable=on_var, command=commit).pack(side="left")
            spin = ttk.Spinbox(row2, from_=1, to=99, width=4, textvariable=max_var, command=commit)
            spin.pack(side="left", padx=6)
            spin.bind("<Return>", lambda e, c=commit: c())
            spin.bind("<FocusOut>", lambda e, c=commit: c())
            tk.Label(row2, text="sauvegardes, hors favoris ★ (les plus anciennes en trop sont supprimées)",
                     fg=MUTED).pack(side="left")

        # onglets : on garde celui qui était ouvert, la sélection et la position dans la liste
        old = self.current_tree()
        keep_sel = tuple(old.selection()) if old else ()
        top = old.yview()[0] if old else 0.0
        try:
            current = self.nb.tab(self.nb.select(), "text")
        except tk.TclError:
            current = None
        for tab in self.nb.tabs():
            self.nb.nametowidget(tab).destroy()
        self.trees = {}
        rows = []
        for g, b in list_backups():
            d = parse_stamp(b.name)
            date = f"{d:%d/%m/%Y à %H:%M:%S}" if d else b.name
            rows.append((g, b, date, size_of(b), self.notes.get(f"{g}/{b.name}", "")))
        self._sig = tuple((g, b.name, size) for g, b, _d, size, _n in rows)
        self.add_tab("Tous", None, rows)
        for name in self.games:
            self.add_tab(name, name, rows)
        for tab in self.nb.tabs():
            if self.nb.tab(tab, "text") == current:
                self.nb.select(tab)
        new = self.current_tree()
        if new:
            new.selection_set(tuple(i for i in keep_sel if new.exists(i)))
            new.yview_moveto(top)

    # ----- actions -----
    def pick(self, name, folder):
        path = filedialog.askdirectory(title=f"Dossier de sauvegarde de {name}") if folder \
            else filedialog.askopenfilename(title=f"Fichier de sauvegarde de {name}")
        if path:
            self.games[name] = path
            save_config(self.games)
            self.refresh()

    def add_game(self):
        name = (simpledialog.askstring("Ajouter un jeu", "Nom du jeu :", parent=self) or "").strip()
        if not name:
            return
        if not valid_name(name):
            messagebox.showwarning("Nom invalide", "Évitez les caractères \\ / : * ? \" < > | et un point ou espace à la fin.")
            return
        if name in self.games:
            messagebox.showinfo("Déjà présent", f"{name} existe déjà.")
            return
        self.games[name] = ""
        save_config(self.games)
        self.refresh()

    def rename_game(self, old):
        new = (simpledialog.askstring("Renommer", f"Nouveau nom pour {old} :",
                                      initialvalue=old, parent=self) or "").strip()
        if not new or new == old:
            return
        if not valid_name(new):
            messagebox.showwarning("Nom invalide", "Évitez les caractères \\ / : * ? \" < > | et un point ou espace à la fin.")
            return
        if new in self.games:
            messagebox.showinfo("Déjà présent", f"{new} existe déjà.")
            return
        old_dir, new_dir = BACKUP_DIR / old, BACKUP_DIR / new
        try:
            if old_dir.exists():
                if new_dir.exists() and not old_dir.samefile(new_dir):
                    messagebox.showerror("Renommage impossible", f"Un dossier « {new} » existe déjà dans Sauvegardes.")
                    return
                old_dir.rename(new_dir)
        except OSError as e:
            messagebox.showerror("Renommage impossible", f"{e}\n\nFermez l’Explorateur s’il est ouvert dans ce dossier.")
            return
        self.games = {(new if k == old else k): v for k, v in self.games.items()}
        save_config(self.games)
        migrate_old_names()  # met aussi le nouveau nom du jeu dans les dossiers déjà faits
        self.notes = remap_notes(self.notes, old, new)
        save_notes(self.notes)
        self.limits = remap_limits(self.limits, old, new)
        save_limits(self.limits)
        self.favorites = remap_favorites(self.favorites, old, new)
        save_favorites(self.favorites)
        sync_note_files(self.notes)
        self.refresh()
        self.status.config(text=f"{old} renommé en {new}")

    def backup(self, name):
        path = self.games.get(name, "")
        if not path:
            messagebox.showinfo("Chemin manquant", f"Définissez d’abord le chemin de {name} (bouton Dossier… ou Fichier…).")
            return
        try:
            make_backup(name, path)
        except Exception as e:
            messagebox.showerror("Sauvegarde impossible", str(e))
            return
        removed = self.enforce_limit(name)  # seulement APRÈS une sauvegarde réussie et vérifiée
        self.refresh()
        text = f"{name} sauvegardé et vérifié à {datetime.now():%H:%M:%S}"
        if removed:
            text += f", {removed} ancienne(s) supprimée(s)"
        self.status.config(text=text)

    def enforce_limit(self, name):
        lim = self.limits.get(name)
        if not lim or not lim.get("on"):
            return 0
        removed = 0
        for b in backups_to_prune(name, lim["max"], self.favorites):
            shutil.rmtree(b, ignore_errors=True)
            if not b.exists():
                removed += 1
                self.notes.pop(f"{name}/{b.name}", None)
        if removed:
            save_notes(self.notes)
        return removed

    def commit_limit(self, name, on_var, max_var):
        """Enregistre la case et le nombre. Rien n’est supprimé ici : la limite s’applique
        à la prochaine sauvegarde, après avoir prévenu s’il y a déjà trop de sauvegardes."""
        cur = self.limits.get(name, DEFAULT_LIMIT)
        try:
            n = int(max_var.get())
            if not 1 <= n <= 99:
                raise ValueError
        except ValueError:
            n = cur["max"]
            max_var.set(str(n))
        new = {"on": bool(on_var.get()), "max": n}
        if new == cur:
            return
        if new["on"]:
            extra = len(backups_to_prune(name, 0, self.favorites)) + 1 - n
            if extra > 0 and not messagebox.askyesno(
                    "Limite de sauvegardes",
                    f"Il y a déjà {extra + n - 1} sauvegarde(s) de {name}.\n\n"
                    f"Avec un maximum de {n}, la prochaine sauvegarde supprimera "
                    f"automatiquement les {extra} plus ancienne(s).\n\nActiver cette limite ?"):
                on_var.set(cur["on"])
                max_var.set(str(cur["max"]))
                return
        self.limits[name] = new
        save_limits(self.limits)
        self.status.config(text=f"{name} : " + (f"maximum {n} sauvegardes" if new["on"] else "pas de limite"))

    def selected_all(self, quiet=False):
        """Toutes les sauvegardes sélectionnées (liste de chemins)."""
        tree = self.current_tree()
        sel = tree.selection() if tree else ()
        if not sel and not quiet:
            messagebox.showinfo("Sélection", "Cliquez d’abord sur une sauvegarde dans la liste.")
        return [Path(i) for i in sel]

    def selected(self, quiet=False):
        """Une seule sauvegarde : pour les actions qui n’ont pas de sens sur plusieurs."""
        items = self.selected_all(quiet=quiet)
        if len(items) > 1:
            if not quiet:
                messagebox.showinfo("Sélection", "Choisissez une seule sauvegarde pour cette action.")
            return None
        return items[0] if items else None

    def on_drag_init(self, event):
        if self._lasso_active:
            return "break"
        items = self.selected_all(quiet=True)
        if not items:
            return "break"
        return (COPY, DND_FILES, tuple(str(p) for p in items))

    def edit_note(self):
        p = self.selected()
        if not p:
            return
        key = f"{p.parent.name}/{p.name}"
        new = simpledialog.askstring("Note", f"Note pour la sauvegarde {p.name} :\n(laisser vide pour l’effacer)",
                                     initialvalue=self.notes.get(key, ""), parent=self)
        if new is None:
            return
        new = new.strip()
        if new:
            self.notes[key] = new
        else:
            self.notes.pop(key, None)
        save_notes(self.notes)
        write_note_file(p, new)  # Note.txt voyage avec le dossier (glisser-déposer, copie)
        self.refresh()

    def show_menu(self, tree, event):
        """Clic droit sur une sauvegarde : les mêmes actions que les boutons du bas."""
        iid = tree.identify_row(event.y)
        if not iid:
            return
        if iid not in tree.selection():  # comme l’Explorateur : on sélectionne la ligne cliquée
            tree.selection_set(iid)
        items = [Path(i) for i in tree.selection()]
        keys = {f"{p.parent.name}/{p.name}" for p in items}
        one = "normal" if len(items) == 1 else "disabled"  # ces deux actions n’ont de sens que sur une seule
        menu = tk.Menu(self, tearoff=0, bg=PANEL, fg=FG, activebackground=ACCENT,
                       activeforeground="#ffffff", disabledforeground=MUTED, bd=0, relief="flat")
        menu.add_command(label="Copier vers…", command=self.copy_selected)
        menu.add_command(label="Ouvrir le dossier", command=self.open_selected, state=one)
        menu.add_command(label="Note…", command=self.edit_note, state=one)
        menu.add_command(label="Retirer des favoris" if keys <= self.favorites else "★ Ajouter aux favoris",
                         command=self.toggle_favorite)
        menu.add_separator()
        menu.add_command(label="Supprimer", command=self.delete_selected)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def toggle_favorite(self):
        items = self.selected_all()
        if not items:
            return
        keys = {f"{p.parent.name}/{p.name}" for p in items}
        if keys <= self.favorites:
            self.favorites -= keys
            text = f"{len(keys)} sauvegarde(s) retirée(s) des favoris"
        else:
            self.favorites |= keys
            text = f"{len(keys)} sauvegarde(s) protégée(s) ★"
        save_favorites(self.favorites)
        self.refresh()
        self.status.config(text=text)

    def open_selected(self):
        p = self.selected()
        if p:
            open_folder(p)

    def copy_selected(self):
        items = self.selected_all()
        if not items:
            return
        target = filedialog.askdirectory(title="Copier la sauvegarde vers…" if len(items) == 1
                                         else f"Copier les {len(items)} sauvegardes vers…")
        if not target:
            return
        done, errors = 0, []
        for p in items:
            dest = Path(target) / p.name
            try:
                shutil.copytree(p, dest)
                problems = verify_copy(p, dest)
                if problems:
                    shutil.rmtree(dest, ignore_errors=True)
                    errors.append(f"{p.name} : copie différente de l’original, supprimée ({problems[0]})")
                else:
                    done += 1
            except Exception as e:
                errors.append(f"{p.name} : {e}")
        if errors:
            messagebox.showerror("Copie incomplète", f"{done} copiée(s), {len(errors)} en erreur :\n\n" + "\n".join(errors[:6]))
        else:
            self.status.config(text=f"{done} copiée(s) et vérifiée(s) vers {target}")

    def delete_selected(self):
        items = self.selected_all()
        if not items:
            return
        if len(items) == 1:
            question = f"Supprimer définitivement cette sauvegarde ?\n{items[0].parent.name} – {items[0].name}"
        else:
            names = "\n".join(f"{p.parent.name} – {p.name}" for p in items[:8])
            more = f"\n… et {len(items) - 8} autres" if len(items) > 8 else ""
            question = f"Supprimer définitivement ces {len(items)} sauvegardes ?\n\n{names}{more}"
        if not messagebox.askyesno("Supprimer", question):
            return
        favs = [p for p in items if f"{p.parent.name}/{p.name}" in self.favorites]
        if favs:
            names = "\n".join(f"★ {p.parent.name} – {p.name}" for p in favs[:6])
            more = f"\n… et {len(favs) - 6} autres" if len(favs) > 6 else ""
            delete_favs = messagebox.askyesno(
                "Favoris protégés",
                f"{len(favs)} favori(s) dans la sélection :\n\n{names}{more}\n\n"
                "Les supprimer aussi ?\n\nOui : tout est supprimé, favoris compris.\n"
                "Non : les favoris sont gardés, le reste est supprimé.",
                icon="warning", default="no")
            if not delete_favs:
                items = [p for p in items if p not in favs]
                if not items:
                    return
        failed = []
        for p in items:
            shutil.rmtree(p, ignore_errors=True)
            if p.exists():
                failed.append(p.name)
            else:
                key = f"{p.parent.name}/{p.name}"
                if self.notes.pop(key, None) is not None:
                    save_notes(self.notes)
                if key in self.favorites:
                    self.favorites.discard(key)
                    save_favorites(self.favorites)
        self.refresh()
        if failed:
            messagebox.showwarning("Suppression incomplète",
                                   "Impossible de supprimer entièrement :\n" + "\n".join(failed[:8]) +
                                   "\n\nUn fichier est peut-être ouvert ailleurs (Explorateur, jeu…).")
        else:
            self.status.config(text=f"{len(items)} sauvegarde(s) supprimée(s)")


if __name__ == "__main__":
    if sys.platform.startswith("win"):
        try:  # identité propre à l’appli, pour que la barre des tâches affiche NOTRE icône et non celle de Python
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Rw6.SaveGames")
        except Exception:
            pass
    try:
        BACKUP_DIR.mkdir(exist_ok=True)
        migrate_old_names()
        App().mainloop()
    except Exception as e:
        import traceback
        log_error(traceback.format_exc())
        try:
            messagebox.showerror("Erreur au lancement", f"{e}\n\nDétails dans le fichier erreurs.log, à côté de l’appli.")
        except Exception:
            pass
