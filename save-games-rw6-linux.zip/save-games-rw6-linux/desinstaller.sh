#!/usr/bin/env bash
# Retire le lanceur, le demarrage automatique et .venv. Tes sauvegardes et reglages restent.
# Removes the launcher, the autostart entry and .venv. Your backups and settings stay.
cd "$(dirname "$(readlink -f "$0")")" || exit 1
rm -f "$HOME/.local/share/applications/save-games-rw6.desktop" "$HOME/.config/autostart/save-games-rw6.desktop"
rm -rf .venv
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1
echo "OK : lanceur, demarrage automatique et .venv retires. / launcher, autostart and .venv removed."
echo "Tes sauvegardes (dossier Sauvegardes/) et reglages n'ont pas ete touches. / Your backups and settings were not touched."
