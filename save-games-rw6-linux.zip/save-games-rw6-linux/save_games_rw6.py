#!/usr/bin/env python3
"""Save Games Rw6 : un bouton par jeu, une liste de jeux, des notes, des favoris, la sauvegarde automatique.

Copyright (c) 2026 Rw6 — licence MIT (voir le fichier LICENSE).

Lancement : double-clic sur le fichier (Python installé) ; sous Linux : ./install.sh puis le lanceur « Save Games Rw6 ».
L’extension .pyw (Windows) évite d’ouvrir un terminal. Langues : Français et English (menu en haut de la fenêtre).
Les sauvegardes sont rangées dans le dossier « Sauvegardes » à côté de ce fichier.

Glisser-déposer vers l’Explorateur : `py -m pip install tkinterdnd2` (une seule fois), ou installer_dependances.bat.
"""
import csv
import hashlib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
from datetime import datetime, timedelta
from datetime import time as dtime
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

try:
    from tkinterdnd2 import COPY, DND_FILES, TkinterDnD
    BaseWindow = TkinterDnD.Tk
    HAS_DND = True
except Exception:  # bibliothèque absente : l’appli marche, sans le glisser-déposer
    BaseWindow = tk.Tk
    HAS_DND = False

APP_DIR = Path(__file__).resolve().parent
SETTINGS_FILE = APP_DIR / "reglages.json"   # réglages généraux (emplacement du dossier des sauvegardes)
DEFAULT_BACKUP_DIR = APP_DIR / "Sauvegardes"


def _initial_backup_dir():
    try:
        p = json.loads(SETTINGS_FILE.read_text(encoding="utf-8")).get("backup_dir")
        if isinstance(p, str) and p.strip():
            return Path(p)
    except (OSError, ValueError, AttributeError):
        pass
    return DEFAULT_BACKUP_DIR


BACKUP_DIR = _initial_backup_dir()   # modifiable depuis l’appli (bouton « Changer… »)

IS_WINDOWS = sys.platform.startswith("win")
IS_LINUX = sys.platform.startswith("linux")

# ----- langues -----
# Pour ajouter une langue : l’ajouter ici, puis créer TRANSLATIONS["code"] = {texte français: traduction} en bas du fichier.
# Le français d’origine sert de clé : un texte sans traduction reste simplement en français.
LANGUAGES = {"fr": "Français", "en": "English"}
TRANSLATIONS = {}


def _system_language():
    """Langue du système si l’appli la connaît (fr / en), sinon None."""
    try:
        if IS_WINDOWS:
            import ctypes
            code = ctypes.windll.kernel32.GetUserDefaultUILanguage() & 0xFF
            return {0x0C: "fr", 0x09: "en"}.get(code)
        for var in ("LC_ALL", "LC_MESSAGES", "LANG", "LANGUAGE"):
            value = os.environ.get(var, "")
            if value:
                return value[:2].lower() if value[:2].lower() in LANGUAGES else None
    except Exception:
        pass
    return None


def _initial_language():
    """Langue choisie dans le menu (reglages.json), sinon celle du système si elle est connue (fr / en), sinon l’anglais."""
    try:
        lang = json.loads(SETTINGS_FILE.read_text(encoding="utf-8")).get("language")
        if lang in LANGUAGES:
            return lang
    except (OSError, ValueError, AttributeError):
        pass
    return _system_language() or "en"


LANG = _initial_language()   # la langue change au redémarrage de l’appli (le menu la relance tout seul)


def T(text, *args):
    """Texte affiché à l’écran. `text` est le français d’origine ; {0}, {1}… sont remplacés par `args`."""
    out = TRANSLATIONS.get(LANG, {}).get(text, text)
    return out.format(*args) if args else out


def save_language(lang):
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {}
    except (OSError, ValueError):
        data = {}
    data["language"] = lang
    try:
        SETTINGS_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        return True
    except OSError:
        return False

CONFIG_FILE = APP_DIR / "config.json"
NOTES_FILE = APP_DIR / "notes.json"      # une note par sauvegarde
WINDOW_FILE = APP_DIR / "fenetre.json"   # taille et position de la fenêtre
DISPLAY_FILE = APP_DIR / "affichage.json"   # taille du texte
AUTO_FILE = APP_DIR / "auto.json"          # sauvegarde automatique, par jeu
LIMITS_FILE = APP_DIR / "limites.json"   # limite de sauvegardes par jeu (optionnelle)
FAVORITES_FILE = APP_DIR / "favoris.json"   # sauvegardes marquées ★ (protégées)
ICON_FILE = APP_DIR / "icone.ico"          # facultatif : icône de la fenêtre et de la barre des tâches
NOTE_FILE = "Note.txt"                   # la note est aussi écrite dans le dossier de la sauvegarde
DEFAULT_LIMIT = {"on": False, "max": 6}
AUTO_MODES = ("interval", "fixed", "session")   # on peut en cocher plusieurs ; aucun = désactivée
DEFAULT_AUTO = {"modes": [], "every": 6, "unit": "heures", "process": "", "limit_on": True, "limit": 5,
                "at": "20:00", "days": [0, 1, 2, 3, 4, 5, 6]}
DAY_NAMES = ("lun", "mar", "mer", "jeu", "ven", "sam", "dim")
INSTANCE_PORT = 48721   # une seule copie de l’appli à la fois (écoute locale uniquement)
INSTANCE_OPEN, INSTANCE_PING = b"SAVEGAMESRW6-OPEN", b"SAVEGAMESRW6-PING"
AUTO_DIRNAME = "Auto"   # les sauvegardes automatiques sont rangées dans Sauvegardes/<jeu>/Auto/
INJECT_DIRNAME = "Avant injection"   # copies de sécurité faites avant chaque injection : Sauvegardes/<jeu>/Avant injection/
KIND_DIRS = {"manual": "", "auto": AUTO_DIRNAME, "inject": INJECT_DIRNAME}   # sous-dossier de chaque sorte de sauvegarde
DEFAULT_INJECT_KEEP = 5    # sauvegardes « Avant injection » gardées par jeu (1 à 99, réglable)
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"   # démarrage avec Windows (clé de l’utilisateur)
RUN_NAME = "SaveGamesRw6"
CLOUD_FILE = APP_DIR / "cloud.json"       # cloud : dossiers, réglages par jeu, envois en attente
CLOUD_DIRNAME = "Save Games Rw6"          # dossier créé DANS chaque dossier cloud choisi
CLOUD_UNITS = {"minutes": 60, "heures": 3600, "jours": 86400}   # délai entre deux essais d’envoi
DEFAULT_CLOUD_GAME = {"on": False, "folders": [], "max_on": True, "max": 6}
DEFAULT_CLOUD = {"folders": [], "games": {}, "retry_every": 10, "retry_unit": "minutes", "tries": 5,
                 "limit_on": False, "limit_gb": 3.0, "over": "delete", "pending": []}
AUTO_UNITS = {"heures": 3600, "jours": 86400, "semaines": 604800}  # secondes


def unit_name(unit, n=2):
    """« heures » -> « hours » ; au singulier quand n vaut 1 (« heure », « hour »)."""
    try:
        single = int(n) == 1
    except (TypeError, ValueError):
        single = False
    return T(unit[:-1] if single and unit.endswith("s") else unit)


def unit_from_label(label, units, default):
    """Retrouve l’unité enregistrée (toujours en français) à partir du texte affiché dans la liste déroulante."""
    for u in units:
        if label in (u, T(u)):
            return u
    return default


AUTO_TICK_MS = 5000     # fréquence de vérification de la sauvegarde automatique
SESSION_DELAY = 5       # secondes d’attente après la fermeture du jeu, pour qu’il finisse d’écrire

ZOOM_STEPS = (70, 80, 90, 100, 110, 125, 150, 175, 200)  # taille du texte, en %
FONT_NAMES = ("TkDefaultFont", "TkTextFont", "TkHeadingFont", "TkMenuFont", "TkIconFont")
DEFAULT_GAMES = {}  # version publique : on part d’une liste vide, chacun ajoute ses jeux

STAMP_FR = "%d-%m-%Y_%H-%M-%S"   # date des dossiers : MonJeu_01-11-2026_14-30-00
STAMP_OLD = "%Y-%m-%d_%H-%M-%S"  # ancien format, encore reconnu

# Thème sombre
BG, PANEL, FG = "#16191d", "#1f2429", "#e8eaed"
MUTED, ACCENT, ERR, LINE = "#9aa3ad", "#3d7fc4", "#ff7b72", "#343b43"


def log_error(text):
    """Sans terminal, les erreurs seraient invisibles : on les note dans erreurs.log."""
    try:
        with open(APP_DIR / "erreurs.log", "a", encoding="utf-8") as f:
            f.write(f"--- {datetime.now():%d/%m/%Y %H:%M:%S}\n{text}\n")
    except OSError:
        pass


def load_config():
    """{jeu: chemin}. Le chemin est un dossier, un fichier, ou une liste de fichiers précis."""
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict) and data:
            out = {}
            for k, v in data.items():
                if isinstance(v, list):
                    v = [str(x) for x in v if str(x)]
                elif not isinstance(v, str):
                    v = ""
                out[str(k)] = v
            return out
    except (OSError, ValueError):
        pass
    return dict(DEFAULT_GAMES)


def save_config(games):
    CONFIG_FILE.write_text(json.dumps(games, indent=2, ensure_ascii=False), encoding="utf-8")


def load_notes():
    """Notes rangées sous la clé « jeu/dossier-de-la-sauvegarde »."""
    try:
        data = json.loads(NOTES_FILE.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {str(k): str(v) for k, v in data.items()}
    except (OSError, ValueError):
        pass
    return {}


def save_notes(notes):
    NOTES_FILE.write_text(json.dumps(notes, indent=2, ensure_ascii=False), encoding="utf-8")


def remap_notes(notes, old, new):
    """Quand un jeu est renommé, ses notes suivent le nouveau nom des dossiers."""
    out = {}
    for key, text in notes.items():
        game, _, folder = key.partition("/")
        if game == old:
            d = parse_stamp(folder)
            if d:
                folder = f"{new}_{d.strftime(STAMP_FR)}"
            game = new
        out[f"{game}/{folder}"] = text
    return out


def load_zoom():
    """Taille du texte enregistrée (en %), ramenée au cran le plus proche ; 100 par défaut."""
    try:
        z = int(json.loads(DISPLAY_FILE.read_text(encoding="utf-8")).get("zoom", 100))
        return min(ZOOM_STEPS, key=lambda step: abs(step - z))
    except (OSError, ValueError, AttributeError, TypeError):
        return 100


def save_zoom(zoom):
    try:
        DISPLAY_FILE.write_text(json.dumps({"zoom": zoom}), encoding="utf-8")
    except OSError:
        pass


def scaled_size(base, pct):
    """Taille d’une police après zoom (une taille négative = en pixels, on garde le signe)."""
    sign = -1 if base < 0 else 1
    return sign * max(6, round(abs(base) * pct / 100))


AUTOSTART_FILE = Path.home() / ".config" / "autostart" / "save-games-rw6.desktop"   # Linux : lancement à l’ouverture de session


def startup_command():
    """Commande lancée à l’ouverture de session : l’appli, sans terminal, réduite."""
    exe = Path(sys.executable)
    if exe.name.lower() == "python.exe" and exe.with_name("pythonw.exe").exists():
        exe = exe.with_name("pythonw.exe")
    return f'"{exe}" "{Path(__file__).resolve()}" --reduit'


def _startup_value():
    """Commande enregistrée pour le démarrage ('' si aucune), ou None si le système ne le permet pas."""
    if IS_LINUX:
        try:
            for line in AUTOSTART_FILE.read_text(encoding="utf-8").splitlines():
                if line.startswith("Exec="):
                    return line[5:].strip()
        except OSError:
            pass
        return ""
    if not IS_WINDOWS:
        return None
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as key:
            return str(winreg.QueryValueEx(key, RUN_NAME)[0])
    except OSError:
        return ""
    except ImportError:
        return None


def startup_enabled():
    """True / False (l’appli se lance-t-elle à l’ouverture de session ?), None si le système ne le permet pas."""
    value = _startup_value()
    return None if value is None else bool(value)


def set_startup(enabled):
    """Active ou désactive le lancement à l’ouverture de session. Renvoie False en cas d’échec."""
    if IS_LINUX:
        try:
            if enabled:
                AUTOSTART_FILE.parent.mkdir(parents=True, exist_ok=True)
                AUTOSTART_FILE.write_text(
                    "[Desktop Entry]\nType=Application\nName=Save Games Rw6\n"
                    f"Exec={startup_command()}\nTerminal=false\nX-GNOME-Autostart-enabled=true\n", encoding="utf-8")
            else:
                AUTOSTART_FILE.unlink(missing_ok=True)
            return True
        except OSError:
            return False
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
            if enabled:
                winreg.SetValueEx(key, RUN_NAME, 0, winreg.REG_SZ, startup_command())
            else:
                try:
                    winreg.DeleteValue(key, RUN_NAME)
                except FileNotFoundError:
                    pass
        return True
    except (OSError, ImportError):
        return False


def tray_missing_text():
    """Message de la croix quand il n’y a pas d’icône système (pystray absent ou bureau sans zone de notification)."""
    if IS_WINDOWS:
        return T("La croix devrait masquer l’appli, mais le module « pystray » n’est pas installé.\n\n"
                 "Pour l’installer (une seule fois), ouvrez l’invite de commandes Windows et tapez :\n"
                 "py -m pip install pystray\npuis relancez l’appli.\n\nFermer l’appli maintenant ?")
    return T("La croix devrait masquer l’appli, mais l’icône système n’est pas disponible (module « pystray » absent, "
             "ou bureau sans zone de notification).\n\nPour installer le module : lancez install.sh dans le dossier de "
             "l’appli, puis relancez l’appli.\n\nFermer l’appli maintenant ?")


def hide_text():
    if IS_WINDOWS:
        return T("La fenêtre va disparaître, mais l’appli continue de tourner (les sauvegardes automatiques aussi).\n\n"
                 "Pour la rouvrir : relancez l’appli (raccourci ou double-clic sur le fichier), la fenêtre déjà ouverte "
                 "réapparaîtra.\nPour une icône près de l’horloge : py -m pip install pystray\n\nMasquer maintenant ?")
    return T("La fenêtre va disparaître, mais l’appli continue de tourner (les sauvegardes automatiques aussi).\n\n"
             "Pour la rouvrir : relancez l’appli (lanceur « Save Games Rw6 »), la fenêtre déjà ouverte réapparaîtra.\n"
             "Pour une icône système : lancez install.sh\n\nMasquer maintenant ?")


def startup_repair():
    """Si l’appli a été déplacée, l’entrée de démarrage pointe au mauvais endroit : on la remet à jour."""
    value = _startup_value()
    if value and value != startup_command():
        set_startup(True)


def source_paths(source):
    """Liste des chemins à copier pour un jeu (un dossier, un fichier, ou plusieurs fichiers)."""
    if isinstance(source, (list, tuple)):
        return [Path(p) for p in source]
    return [Path(source)]


def describe_source(path):
    """(texte à afficher, défini ?) pour le chemin d’un jeu."""
    if not path:
        return T("Chemin des sauvegardes du jeu à définir"), False
    if isinstance(path, (list, tuple)):
        names = ", ".join(Path(f).name for f in path[:6])
        more = f" … (+{len(path) - 6})" if len(path) > 6 else ""
        return T("{0} fichiers dans {1} : {2}{3}", len(path), Path(path[0]).parent, names, more), True
    return str(path), True


def load_auto():
    """Sauvegarde automatique par jeu : {jeu: {"modes", "every", "unit", "process"}}."""
    try:
        data = json.loads(AUTO_FILE.read_text(encoding="utf-8"))
        out = {}
        for g, v in data.items():
            raw = v.get("modes")
            if raw is None:   # ancien réglage : un seul mode
                raw = [v.get("mode", "off")]
            raw = raw if isinstance(raw, (list, tuple)) else [raw]
            out[str(g)] = {
                "modes": [m for m in AUTO_MODES if m in raw],
                "every": min(999, max(1, int(v.get("every", 6)))),
                "unit": v.get("unit") if v.get("unit") in AUTO_UNITS else "heures",
                "process": normalize_process(str(v.get("process", ""))),
                "limit_on": bool(v.get("limit_on", True)),
                "limit": min(99, max(1, int(v.get("limit", 5)))),
                "at": "{:02d}:{:02d}".format(*(parse_hhmm(v.get("at", "20:00")) or (20, 0))),
                "days": sorted({int(d) for d in v.get("days", range(7)) if 0 <= int(d) <= 6}) or list(range(7)),
            }
        return out
    except (OSError, ValueError, AttributeError, TypeError):
        return {}


def save_auto(auto):
    AUTO_FILE.write_text(json.dumps(auto, indent=2, ensure_ascii=False), encoding="utf-8")


def remap_auto(auto, old, new):
    return {(new if k == old else k): v for k, v in auto.items()}


def normalize_process(name):
    """'MonJeu' -> 'monjeu.exe' (Windows compare les noms de programmes sans tenir compte des majuscules)."""
    name = name.strip().lower()
    return name + ".exe" if IS_WINDOWS and name and "." not in name else name


def interval_seconds(cfg):
    return AUTO_UNITS.get(cfg.get("unit"), 3600) * max(1, int(cfg.get("every", 6)))


def interval_due(now, latest_ts, last_check_ts, delta):
    """Vrai si la dernière sauvegarde (ou la dernière vérification) date de `delta` secondes ou plus."""
    return now - max(latest_ts or 0, last_check_ts or 0) >= delta


def parse_hhmm(text):
    """'20:05' -> (20, 5), ou None si ce n’est pas une heure valide."""
    try:
        h, m = str(text).split(":")
        h, m = int(h), int(m)
    except ValueError:
        return None
    return (h, m) if 0 <= h <= 23 and 0 <= m <= 59 else None


def last_scheduled(now, hour, minute, days):
    """Dernier moment prévu (datetime) à hour:minute, un des `days` (0 = lundi), qui ne soit pas dans le futur."""
    for back in range(8):
        day = now.date() - timedelta(days=back)
        if day.weekday() in days:
            moment = datetime.combine(day, dtime(hour, minute))
            if moment <= now:
                return moment
    return None


def fixed_due(now, hhmm, days, latest_ts, last_check_ts):
    """Vrai si l’heure prévue est passée sans qu’il y ait eu de sauvegarde (ou de vérification) depuis."""
    hm = parse_hhmm(hhmm)
    if hm is None or not days:
        return False
    moment = last_scheduled(now, hm[0], hm[1], days)
    return moment is not None and max(latest_ts or 0, last_check_ts or 0) < moment.timestamp()


def signal_running_instance(show=True):
    """Si l’appli tourne déjà, le lui dit (elle réaffiche sa fenêtre si show) et renvoie True."""
    try:
        with socket.create_connection(("127.0.0.1", INSTANCE_PORT), timeout=1.5) as c:
            c.sendall((INSTANCE_OPEN if show else INSTANCE_PING) + b"\n")
            return c.recv(16).startswith(b"OK")
    except OSError:
        return False


def listen_for_instances(on_show):
    """Écoute, en arrière-plan, les relances de l’appli. Renvoie le socket, ou None si le port est pris."""
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        srv.bind(("127.0.0.1", INSTANCE_PORT))
        srv.listen(2)
    except OSError:
        srv.close()
        return None

    def loop():
        while True:
            try:
                conn, _addr = srv.accept()
            except OSError:
                return
            with conn:
                try:
                    conn.settimeout(1.5)
                    data = conn.recv(64)
                    if data.startswith(INSTANCE_OPEN) or data.startswith(INSTANCE_PING):
                        conn.sendall(b"OK\n")
                        if data.startswith(INSTANCE_OPEN):
                            on_show()
                except OSError:
                    pass

    threading.Thread(target=loop, daemon=True).start()
    return srv


def parse_tasklist(text):
    """Noms des programmes dans la sortie CSV de la commande Windows `tasklist`."""
    names = set()
    for row in csv.reader(text.splitlines()):
        if row and row[0].strip():
            names.add(row[0].strip())
    return sorted(names, key=str.lower)


def list_processes_linux():
    """Programmes en cours d’exécution sous Linux (lus dans /proc) : nom court, nom du fichier lancé et, pour un jeu
    Windows lancé avec Wine, le nom du .exe."""
    names = set()
    try:
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
    except OSError:
        return None
    for pid in pids:
        base = Path("/proc") / pid
        try:
            comm = (base / "comm").read_text(encoding="utf-8", errors="replace").strip()
            if comm:
                names.add(comm)
            args = (base / "cmdline").read_bytes().split(b"\0")[:8]
        except OSError:
            continue
        try:
            names.add(Path(os.readlink(base / "exe")).name)
        except OSError:
            pass
        for i, raw in enumerate(args):
            arg = raw.decode("utf-8", errors="replace").replace("\\", "/")
            if arg and (i == 0 or arg.lower().endswith(".exe")):
                names.add(arg.rsplit("/", 1)[-1])
    names.discard("")
    return sorted(names, key=str.lower)


def list_processes():
    """Programmes en cours d’exécution, ou None si on ne peut pas les lister."""
    if IS_LINUX:
        return list_processes_linux()
    if not IS_WINDOWS:
        return None
    try:
        r = subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True,
                           errors="replace", timeout=15,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return parse_tasklist(r.stdout) if r.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


def load_limits():
    """Limite par jeu : {jeu: {"on": bool, "max": int}}. Désactivée tant qu’on ne l’a pas choisie."""
    try:
        data = json.loads(LIMITS_FILE.read_text(encoding="utf-8"))
        return {str(g): {"on": bool(v.get("on", False)), "max": min(99, max(1, int(v.get("max", 6))))}
                for g, v in data.items()}
    except (OSError, ValueError, AttributeError, TypeError):
        return {}


def save_limits(limits):
    LIMITS_FILE.write_text(json.dumps(limits, indent=2, ensure_ascii=False), encoding="utf-8")


def remap_limits(limits, old, new):
    return {(new if k == old else k): v for k, v in limits.items()}


def write_note_file(folder, text):
    """Écrit (ou efface si la note est vide) Note.txt dans le dossier d’une sauvegarde."""
    target = Path(folder) / NOTE_FILE
    try:
        if text:
            try:
                current = target.read_text(encoding="utf-8")
            except (OSError, ValueError):
                current = None
            if current != text + "\n":
                target.write_text(text + "\n", encoding="utf-8")
        elif target.exists():
            target.unlink()
    except OSError:
        pass


def sync_note_files(notes):
    """Remet Note.txt à jour dans chaque dossier de sauvegarde (manuelle ou automatique) qui a une note."""
    for key, text in notes.items():
        game, _, folder = key.partition("/")
        for d in (BACKUP_DIR / game / sub / folder for sub in KIND_DIRS.values()):
            if d.is_dir():
                write_note_file(d, text)
                break


def load_favorites():
    """Ensemble de clés « jeu/dossier » des sauvegardes favorites."""
    try:
        data = json.loads(FAVORITES_FILE.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return {str(k) for k in data}
    except (OSError, ValueError):
        pass
    return set()


def save_favorites(favs):
    FAVORITES_FILE.write_text(json.dumps(sorted(favs), indent=2, ensure_ascii=False), encoding="utf-8")


def remap_favorites(favs, old, new):
    """Quand un jeu est renommé, ses favoris suivent le nouveau nom des dossiers."""
    out = set()
    for key in favs:
        game, _, folder = key.partition("/")
        if game == old:
            d = parse_stamp(folder)
            if d:
                folder = f"{new}_{d.strftime(STAMP_FR)}"
            game = new
        out.add(f"{game}/{folder}")
    return out


def is_auto(backup):
    """Vrai pour une sauvegarde automatique (rangée dans le sous-dossier Auto)."""
    return Path(backup).parent.name == AUTO_DIRNAME


def backup_kind(backup):
    """"manual", "auto" (sous-dossier Auto) ou "inject" (sous-dossier Avant injection)."""
    name = Path(backup).parent.name
    return "auto" if name == AUTO_DIRNAME else "inject" if name == INJECT_DIRNAME else "manual"


def game_of(backup):
    """Nom du jeu d’un dossier de sauvegarde, quelle que soit sa sorte."""
    b = Path(backup)
    return b.parent.parent.name if b.parent.name in (AUTO_DIRNAME, INJECT_DIRNAME) else b.parent.name


def backups_to_prune(game, keep, favorites=(), auto=False, kind=None):
    """Les sauvegardes les plus anciennes au-delà de `keep`, parmi les manuelles (auto=False), les automatiques
    (auto=True) ou celles d’une sorte précise (kind="inject"). Les favoris ★ ne sont jamais concernés (et ne
    comptent pas dans le total), ni les dossiers dont le nom ne se termine pas par une date de sauvegarde."""
    kind = kind or ("auto" if auto else "manual")
    mine = [b for _g, b in list_backups(game)
            if parse_stamp(b.name) and backup_kind(b) == kind and f"{game}/{b.name}" not in favorites]
    return mine[keep:]


def load_window():
    """Renvoie (largeur, hauteur, x, y, agrandie) ou None si rien n’est encore enregistré."""
    try:
        d = json.loads(WINDOW_FILE.read_text(encoding="utf-8"))
        x, y = d.get("x"), d.get("y")
        return (int(d["width"]), int(d["height"]),
                int(x) if x is not None else None, int(y) if y is not None else None,
                bool(d.get("zoomed", False)))
    except (OSError, ValueError, KeyError, TypeError):
        return None


def parse_geometry(geo):
    """'900x700+120+40' -> (900, 700, 120, 40). Gère aussi les positions négatives (autre écran)."""
    m = re.match(r"(\d+)x(\d+)([+-])(-?\d+)([+-])(-?\d+)$", geo)
    if not m:
        return None
    w, h, sx, x, sy, y = m.groups()
    return int(w), int(h), (int(x) if sx == "+" else -int(x)), (int(y) if sy == "+" else -int(y))


def position_visible(x, y, w, vx, vy, vw, vh):
    """Vrai si le haut de la fenêtre (barre de titre) est assez visible sur le bureau (tous écrans)."""
    return vx - w + 100 <= x <= vx + vw - 100 and vy <= y <= vy + vh - 60


def valid_name(name):
    return (bool(name) and not any(c in name for c in '\\/:*?"<>|') and name == name.rstrip(" .")
            and name.lower() not in (AUTO_DIRNAME.lower(), INJECT_DIRNAME.lower()))


def parse_stamp(name):
    """Lit la date à la fin du nom du dossier (avec ou sans le nom du jeu devant)."""
    tail = name[-19:]
    for fmt in (STAMP_FR, STAMP_OLD):
        try:
            return datetime.strptime(tail, fmt)
        except ValueError:
            pass
    return None


def size_of(path):
    """Poids total d’un dossier ou fichier ; ignore ce qui disparaît pendant le calcul."""
    path = Path(path)
    total = 0
    try:
        if path.is_file():
            return path.stat().st_size
        for f in path.rglob("*"):
            try:
                if f.is_file() and not (f.name == NOTE_FILE and f.parent == path):
                    total += f.stat().st_size
            except OSError:
                pass
    except OSError:
        pass
    return total


def human(n):
    units = ("o", "Ko", "Mo", "Go") if LANG == "fr" else ("B", "KB", "MB", "GB")
    for i, unit in enumerate(units):
        if n < 1024 or i == len(units) - 1:
            return f"{n:.0f} {unit}" if i == 0 else f"{n:.1f} {unit}"
        n /= 1024


def open_folder(path):
    path = str(path)
    if sys.platform.startswith("win"):
        os.startfile(path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", path])
    else:
        subprocess.Popen(["xdg-open", path])


class VerificationError(Exception):
    """La copie n’est pas identique à l’original."""


def files_of(root):
    """{chemin relatif: chemin réel} de tous les fichiers d’un dossier, d’un fichier ou d’une liste de fichiers."""
    if isinstance(root, (list, tuple)):
        return {Path(Path(f).name): Path(f) for f in root}
    root = Path(root)
    if root.is_file():
        return {Path(root.name): root}
    return {f.relative_to(root): f for f in root.rglob("*") if f.is_file()}


def file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_copy(src, dst):
    """Compare une copie à son original : fichiers présents, tailles et contenu (SHA-256).
    Renvoie la liste des problèmes trouvés (vide = copie identique). Note.txt n’est pas une donnée du jeu."""
    problems = []
    try:
        a, b = files_of(src), files_of(dst)
    except OSError as e:
        return [T("lecture impossible ({0})", e)]
    for rel in sorted(a):
        if rel not in b:
            problems.append(T("fichier manquant dans la copie : {0}", rel.as_posix()))
            continue
        try:
            if a[rel].stat().st_size != b[rel].stat().st_size or file_hash(a[rel]) != file_hash(b[rel]):
                problems.append(T("contenu différent : {0}", rel.as_posix()))
        except OSError as e:
            problems.append(T("lecture impossible : {0} ({1})", rel.as_posix(), e))
    for rel in sorted(set(b) - set(a) - {Path(NOTE_FILE)}):
        problems.append(T("fichier en trop dans la copie : {0}", rel.as_posix()))
    return problems


def _copy_once(source, dest):
    if isinstance(source, (list, tuple)):  # plusieurs fichiers précis : on les copie à plat
        dest.mkdir(parents=True)
        for f in source:
            shutil.copy2(f, dest)
        return
    source = Path(source)
    if source.is_dir():
        shutil.copytree(source, dest)
    else:
        dest.mkdir(parents=True)
        shutil.copy2(source, dest)


def make_backup(game, source, now=None, auto=False, kind=None):
    """Copie `source` (dossier, fichier ou liste de fichiers) dans Sauvegardes/<jeu>/<jeu>_<JJ-MM-AAAA_HH-MM-SS>,
    puis vérifie que la copie est identique. En cas d’écart, une deuxième tentative est faite ;
    si elle échoue aussi, la copie défectueuse est supprimée et une erreur est levée."""
    paths = source_paths(source)
    missing = [str(p) for p in paths if not p.exists()]
    if missing:
        raise FileNotFoundError(T("Le chemin n’existe pas :\n") + "\n".join(missing[:5]))
    if isinstance(source, (list, tuple)) and len({p.name.lower() for p in paths}) != len(paths):
        raise ValueError(T("Deux fichiers portent le même nom : choisissez des fichiers d’un seul dossier."))
    kind = kind or ("auto" if auto else "manual")
    base = BACKUP_DIR / game / KIND_DIRS[kind]
    dest = base / f"{game}_{(now or datetime.now()).strftime(STAMP_FR)}"
    if dest.exists():
        raise FileExistsError(T("Une sauvegarde existe déjà pour cette seconde, réessayez."))
    problems = []
    for _attempt in range(2):
        _copy_once(source, dest)
        problems = verify_copy(source, dest)
        if not problems:
            return dest
        shutil.rmtree(dest, ignore_errors=True)
    raise VerificationError(
        T("La copie n’est pas identique à l’original, elle a été supprimée.\n"
                "Le jeu ou l’émulateur est peut-être en train d’écrire sa sauvegarde : fermez-le et "
                "réessayez.\n"
                "\n")
        + "\n".join(problems[:5]))


def list_backups(game=None, root=None):
    """Liste (jeu, dossier) des sauvegardes manuelles ET automatiques, de la plus récente à la plus ancienne.
    `root` : un autre dossier de sauvegardes (celui de l’appli dans un dossier cloud), par défaut le sien."""
    found = []
    root = BACKUP_DIR if root is None else Path(root)
    if root.is_dir():
        try:
            gdirs = list(root.iterdir())
        except OSError:
            gdirs = []
        for gdir in gdirs:
            if not gdir.is_dir() or (game is not None and gdir.name != game):
                continue
            skip = (AUTO_DIRNAME, INJECT_DIRNAME)
            found.extend((gdir.name, b) for b in gdir.iterdir() if b.is_dir() and b.name not in skip)
            for sub in skip:
                sdir = gdir / sub
                if sdir.is_dir():
                    found.extend((gdir.name, b) for b in sdir.iterdir() if b.is_dir())
    return sorted(found, key=lambda t: parse_stamp(t[1].name) or datetime.min, reverse=True)


def latest_backup(game):
    """La sauvegarde la plus récente d’un jeu (dossier), ou None."""
    for _g, b in list_backups(game):
        if parse_stamp(b.name):
            return b
    return None


def migrate_old_names():
    """Met tous les dossiers au format <jeu>_JJ-MM-AAAA_HH-MM-SS (anciens noms et jeux renommés)."""
    for game, b in list_backups():
        d = parse_stamp(b.name)
        if d is None:
            continue
        target = b.with_name(f"{game}_{d.strftime(STAMP_FR)}")
        if target.name != b.name and not target.exists():
            try:
                b.rename(target)
            except OSError:
                pass


def load_cloud():
    """Réglages du cloud : dossiers cloud, réglages par jeu, file d’attente. Tout est désactivé par défaut."""
    cfg = json.loads(json.dumps(DEFAULT_CLOUD))   # copie indépendante
    try:
        data = json.loads(CLOUD_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return cfg
    if not isinstance(data, dict):
        return cfg

    def num(value, low, high, default, kind=int):
        try:
            n = kind(value)
        except (TypeError, ValueError):
            return default
        return n if low <= n <= high else default

    folders = []
    for p in data.get("folders") or []:
        if isinstance(p, str) and p and p not in folders:
            folders.append(p)
    cfg["folders"] = folders
    games = data.get("games")
    for g, v in (games.items() if isinstance(games, dict) else []):
        if isinstance(v, dict):
            cfg["games"][str(g)] = {
                "on": bool(v.get("on")),
                "folders": [p for p in (v.get("folders") or []) if p in folders],
                "max_on": bool(v.get("max_on", True)),
                "max": num(v.get("max"), 1, 999, 6)}
    cfg["retry_every"] = num(data.get("retry_every"), 1, 9999, 10)
    cfg["retry_unit"] = data.get("retry_unit") if data.get("retry_unit") in CLOUD_UNITS else "minutes"
    cfg["tries"] = num(data.get("tries"), 1, 99, 5)
    cfg["limit_on"] = bool(data.get("limit_on"))
    cfg["limit_gb"] = num(data.get("limit_gb"), 0.1, 100000, 3.0, float)
    cfg["over"] = data.get("over") if data.get("over") in ("stop", "delete") else "delete"
    for item in data.get("pending") or []:
        if isinstance(item, dict) and item.get("folder") in folders and item.get("game") and item.get("name"):
            kind = item.get("kind") if item.get("kind") in KIND_DIRS else ("auto" if item.get("auto") else "manual")
            cfg["pending"].append({"game": str(item["game"]), "name": str(item["name"]),
                                   "auto": kind == "auto", "kind": kind, "folder": item["folder"],
                                   "tries": num(item.get("tries"), 1, 99, 1)})
    return cfg


def save_cloud(cfg):
    CLOUD_FILE.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")


def cloud_root(folder):
    """Le dossier créé par l’appli DANS un dossier cloud : <dossier cloud>/Save Games Rw6."""
    return Path(folder) / CLOUD_DIRNAME


def cloud_target(folder, backup):
    """Où une sauvegarde est copiée dans le cloud (même rangement que sur le PC : <jeu>/ et <jeu>/Auto/)."""
    b = Path(backup)
    base = cloud_root(folder) / game_of(b)
    return base / KIND_DIRS[backup_kind(b)] / b.name


def cloud_retry_seconds(cfg):
    return int(cfg["retry_every"]) * CLOUD_UNITS[cfg["retry_unit"]]


def plan_room(used, need, limit, candidates):
    """Quelles sauvegardes supprimer (les plus anciennes d’abord) pour qu’il reste `need` octets de place sous
    `limit` ? `candidates` : [(date, taille, chemin)] du plus ancien au plus récent. Renvoie la liste des chemins
    à supprimer, ou None si même en supprimant tout ça ne suffit pas."""
    out = []
    for _date, size, path in candidates:
        if used + need <= limit:
            break
        out.append(path)
        used -= size
    return out if used + need <= limit else None


def cloud_to_prune(folder, game, keep, favorites=(), protect=None):
    """Les sauvegardes du cloud à supprimer pour n’en garder que `keep` (manuelles et automatiques ensemble,
    favoris ★ exclus). `protect` : la sauvegarde qu’on vient d’envoyer, qui n’est jamais supprimée."""
    mine = [b for _g, b in list_backups(game, cloud_root(folder))
            if parse_stamp(b.name) and f"{game}/{b.name}" not in favorites]
    if protect is not None and any(b.name == protect for b in mine):
        mine = [b for b in mine if b.name != protect]
        keep = max(0, keep - 1)
    return mine[keep:]


def folder_used(root):
    """Place prise par les sauvegardes qui sont dans le dossier de l’appli d’un dossier cloud."""
    return sum(size_of(b) for _g, b in list_backups(None, root))


def cloud_send(backup, folder):
    """Copie une sauvegarde (Note.txt comprise) dans le dossier cloud, puis vérifie la copie (SHA-256)."""
    if not Path(folder).is_dir():
        raise FileNotFoundError(T("Dossier cloud introuvable : {0}", folder))
    dest = cloud_target(folder, backup)
    if dest.is_dir():
        if not verify_copy(backup, dest):
            return dest   # déjà là et identique
        shutil.rmtree(dest, ignore_errors=True)
    dest.parent.mkdir(parents=True, exist_ok=True)
    problems = []
    for _attempt in range(2):
        shutil.copytree(backup, dest)
        problems = verify_copy(backup, dest)
        if not problems:
            return dest
        shutil.rmtree(dest, ignore_errors=True)
    raise VerificationError(T("La copie vers le cloud n’est pas identique, elle a été supprimée : ") + problems[0])


def inject_backup(source, backup):
    """Remet une sauvegarde à la place de celle du jeu (le contraire de make_backup), puis vérifie chaque fichier.
    Note.txt n’est jamais remise dans le jeu. Pour un dossier, son contenu est remplacé."""
    backup = Path(backup)
    data = {rel: f for rel, f in files_of(backup).items() if rel != Path(NOTE_FILE)}
    if not data:
        raise ValueError(T("La sauvegarde choisie ne contient aucun fichier."))
    if isinstance(source, (list, tuple)):   # plusieurs fichiers précis : chacun retourne à sa place
        targets = {Path(p).name: Path(p) for p in source}
        missing = [n for n in targets if Path(n) not in data]
        if missing:
            raise FileNotFoundError(T("Fichier absent de la sauvegarde : ") + ", ".join(missing[:5]))
        plan = {targets[n]: data[Path(n)] for n in targets}
    else:
        dest = Path(source)
        first = next(iter(data))
        if len(data) == 1 and first.parent == Path(".") and first.name == dest.name and not dest.is_dir():
            plan = {dest: data[first]}   # le jeu pointe vers un seul fichier
        else:
            if dest.exists() and not dest.is_dir():
                raise ValueError(T("Le jeu pointe vers un fichier, mais cette sauvegarde contient un dossier."))
            dest.mkdir(parents=True, exist_ok=True)
            for child in list(dest.iterdir()):   # on remplace : l’ancien contenu part (il est gardé dans la sauvegarde d’avant)
                if child.is_dir() and not child.is_symlink():
                    shutil.rmtree(child)
                else:
                    child.unlink()
            plan = {dest / rel: f for rel, f in data.items()}
    for target, src in plan.items():
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target)
    problems = []
    for target, src in plan.items():
        try:
            if target.stat().st_size != src.stat().st_size or file_hash(target) != file_hash(src):
                problems.append(T("contenu différent : {0}", target.name))
        except OSError as e:
            problems.append(T("lecture impossible : {0} ({1})", target.name, e))
    if problems:
        raise VerificationError(T("L’injection est incomplète : ") + " ; ".join(problems[:5]))


def source_folder(source):
    """Le dossier le plus proche qui existe pour le chemin d’un jeu : le dossier lui-même, ou celui qui contient
    le fichier (ou les fichiers). Sert à « Accéder au dossier » et à ouvrir les explorateurs au bon endroit."""
    if not source:
        return None
    paths = source_paths(source)
    p = paths[0]
    cand = p if (not isinstance(source, (list, tuple)) and p.is_dir()) else p.parent
    while not cand.exists() and cand != cand.parent:
        cand = cand.parent
    return cand if cand.exists() else None


def save_backup_dir(path):
    """Change l’emplacement du dossier des sauvegardes ; il est retenu dans reglages.json."""
    global BACKUP_DIR
    BACKUP_DIR = Path(path)
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {}
    except (OSError, ValueError):
        data = {}
    if BACKUP_DIR == DEFAULT_BACKUP_DIR:
        data.pop("backup_dir", None)
    else:
        data["backup_dir"] = str(BACKUP_DIR)
    SETTINGS_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def load_inject_keep():
    """Combien de sauvegardes « Avant injection » garder par jeu (1 à 99, 10 par défaut)."""
    try:
        n = int(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")).get("inject_keep", DEFAULT_INJECT_KEEP))
        return n if 1 <= n <= 99 else DEFAULT_INJECT_KEEP
    except (OSError, ValueError, AttributeError, TypeError):
        return DEFAULT_INJECT_KEEP


def _read_settings():
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def next_inject_number(game):
    """Numéro de la prochaine sauvegarde « Avant injection » de ce jeu (1, 2, 3…). Le compteur est retenu
    dans reglages.json : il continue de monter même quand les plus anciennes sont supprimées."""
    data = _read_settings()
    counts = data.get("inject_count")
    if not isinstance(counts, dict):
        counts = {}
    try:
        n = int(counts.get(game, 0)) + 1
    except (TypeError, ValueError):
        n = 1
    counts[game] = n
    data["inject_count"] = counts
    try:
        SETTINGS_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass
    return n


def rename_inject_counter(old, new):
    """Quand un jeu est renommé, son compteur « Avant injection » le suit."""
    data = _read_settings()
    counts = data.get("inject_count")
    if isinstance(counts, dict) and old in counts:
        counts[new] = counts.pop(old)
        try:
            SETTINGS_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass


def save_inject_keep(n):
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            data = {}
    except (OSError, ValueError):
        data = {}
    data["inject_keep"] = int(n)
    SETTINGS_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def move_backups(old, new):
    """Déplace tous les dossiers de jeu de `old` vers `new` : tout est d’abord copié et vérifié (SHA-256), l’ancien
    n’est supprimé qu’ensuite. Au moindre problème, rien ne change. Renvoie la liste des problèmes (vide = réussi)."""
    old, new = Path(old), Path(new)
    try:
        games = [g for g in old.iterdir() if g.is_dir()] if old.is_dir() else []
    except OSError as e:
        return [str(e)]
    clash = [g.name for g in games if (new / g.name).exists()]
    if clash:
        return [T("« {0} » existe déjà dans le nouveau dossier", n) for n in clash]
    made, problems = [], []
    try:
        new.mkdir(parents=True, exist_ok=True)
        for g in games:
            dest = new / g.name
            made.append(dest)
            shutil.copytree(g, dest)
            bad = verify_copy(g, dest)
            if bad:
                problems.append(f"{g.name} : {bad[0]}")
                break
    except OSError as e:
        problems.append(str(e))
    if problems:
        for d in made:
            shutil.rmtree(d, ignore_errors=True)
        return problems
    for g in games:
        shutil.rmtree(g, ignore_errors=True)
    try:
        old.rmdir()
    except OSError:
        pass
    return []


class App(BaseWindow):
    def __init__(self):
        super().__init__()
        self.set_icon()
        self.title("Save Games Rw6")
        w, h, x, y, zoomed = load_window() or (960, 660, None, None, False)
        w = max(820, min(w, self.winfo_screenwidth()))   # jamais plus grande que l’écran
        h = max(520, min(h, self.winfo_screenheight()))
        if x is not None and y is not None and not position_visible(
                x, y, w, self.winfo_vrootx(), self.winfo_vrooty(),
                self.winfo_vrootwidth(), self.winfo_vrootheight()):
            x = y = None  # position hors écran : on laisse Windows placer la fenêtre
        self.geometry(f"{w}x{h}" if x is None else f"{w}x{h}+{x}+{y}")
        self.normal_geo = (w, h, x, y)
        self._save_job = None
        if zoomed:
            try:
                if IS_LINUX:
                    self.attributes("-zoomed", True)
                else:
                    self.state("zoomed")
            except tk.TclError:
                pass
        self.bind("<Configure>", self.on_configure)
        self.protocol("WM_DELETE_WINDOW", self.on_x)
        self._base_fonts = {}
        for name in FONT_NAMES:  # tailles de départ, avant tout zoom
            try:
                self._base_fonts[name] = tkfont.nametofont(name).cget("size")
            except tk.TclError:
                pass
        self.font_bold = tkfont.nametofont("TkDefaultFont").copy()
        self.font_bold.configure(weight="bold")
        self.zoom = load_zoom()
        self.set_fonts()
        self.update_minsize()
        self.apply_theme()
        self.games = load_config()
        self.notes = load_notes()
        sync_note_files(self.notes)
        self.limits = load_limits()
        self.favorites = load_favorites()
        self._vars = []
        self.trees = {}
        self._sig = ()              # « empreinte » de la liste, pour savoir si elle a changé
        self._last_check = 0.0
        self._lasso_active = False  # vrai pendant qu’on trace un rectangle de sélection

        self.auto = load_auto()
        self.cloud = load_cloud()          # cloud : désactivé tant qu’on n’a rien réglé
        self._cloud_next = 0.0             # prochain essai des envois en attente
        self.cloud_alerts = {}             # avertissements par dossier cloud (limite de place)
        self.inject_keep = load_inject_keep()   # sauvegardes « Avant injection » gardées par jeu
        self._cloud_win = None
        self.current_game = None   # None = « Tous »
        self._rows = []
        self._names = [None]
        self._was_running, self._pending, self._last_auto, self._backoff = {}, {}, {}, {}

        langbar = tk.Frame(self)   # bandeau du haut : le menu de langue, au milieu
        langbar.pack(fill="x", padx=12, pady=(10, 0))
        self.lang_button = ttk.Menubutton(langbar, text=LANGUAGES[LANG], width=14)
        lang_menu = tk.Menu(self.lang_button, tearoff=0, bg=PANEL, fg=FG, activebackground=ACCENT,
                            activeforeground="#ffffff", bd=0, relief="flat")
        for code, label in LANGUAGES.items():
            lang_menu.add_command(label=label, command=lambda c=code: self.change_language(c))
        self.lang_button["menu"] = lang_menu
        self.lang_button.pack()
        bar = tk.Frame(self)
        bar.pack(fill="x", padx=12, pady=(8, 8))
        ttk.Button(bar, text=T("Ajouter un jeu"), command=self.add_game).pack(side="left")
        ttk.Button(bar, text=T("Cloud…"), command=self.cloud_window).pack(side="left", padx=(8, 0))
        ttk.Button(bar, text=T("Avant injection/manuel-auto"), command=self.toggle_inject_page).pack(side="left", padx=(8, 0))
        ttk.Button(bar, text=T("Pour tous…"), command=self.all_limits_window).pack(side="left", padx=(8, 0))
        self.bar = bar
        self.startup_var = tk.BooleanVar(value=bool(startup_enabled()))
        if startup_enabled() is not None:   # Windows et Linux
            startup_repair()
            ttk.Checkbutton(bar, text=T("Lancer avec Windows") if IS_WINDOWS else T("Lancer à l’ouverture de session"),
                            variable=self.startup_var,
                            command=self.toggle_startup).pack(side="left", padx=16)
        ttk.Button(bar, text=T("Masquer"), command=self.hide_window).pack(side="right", padx=(14, 0))
        zoom_box = tk.Frame(bar)
        zoom_box.pack(side="right")
        tk.Label(zoom_box, text=T("Taille du texte"), fg=MUTED).pack(side="left", padx=(0, 6))
        ttk.Button(zoom_box, text="A−", width=3, command=lambda: self.step_zoom(-1)).pack(side="left")
        self.zoom_label = tk.Label(zoom_box, text=f"{self.zoom} %", width=6)
        self.zoom_label.pack(side="left")
        ttk.Button(zoom_box, text="A+", width=3, command=lambda: self.step_zoom(1)).pack(side="left")
        for seq in ("<Control-plus>", "<Control-equal>", "<Control-KP_Add>"):
            self.bind(seq, lambda e: self.step_zoom(1))
        for seq in ("<Control-minus>", "<Control-KP_Subtract>"):
            self.bind(seq, lambda e: self.step_zoom(-1))
        self.bind("<Control-Key-0>", lambda e: self.change_zoom(100))
        dirbar = tk.Frame(self)
        dirbar.pack(fill="x", padx=12, pady=(0, 8))
        ttk.Button(dirbar, text=T("Ouvrir"), command=self.open_backup_dir).pack(side="right", padx=(6, 0))
        ttk.Button(dirbar, text=T("Changer…"), command=self.change_backup_dir).pack(side="right")
        tk.Label(dirbar, text=T("Dossier des sauvegardes :"), fg=MUTED).pack(side="left")
        self.dir_label = tk.Label(dirbar, text="", anchor="w")
        self.dir_label.pack(side="left", fill="x", expand=True, padx=(6, 0))

        # à gauche : la liste des jeux (défile s’il y en a beaucoup) ; à droite : le jeu choisi et ses sauvegardes
        self.body = tk.PanedWindow(self, orient="horizontal", sashwidth=4, bg=LINE, bd=0, sashrelief="flat")
        self.body.pack(fill="both", expand=True, padx=12)
        self.side = tk.Frame(self.body)
        tk.Label(self.side, text=T("Jeux"), font=self.font_bold, anchor="w").pack(fill="x", pady=(0, 4))
        lbox = tk.Frame(self.side)
        lbox.pack(fill="both", expand=True)
        self.game_list = tk.Listbox(lbox, exportselection=False, activestyle="none", width=10, bg=PANEL, fg=FG,
                                    selectbackground=ACCENT, selectforeground="#ffffff",
                                    highlightthickness=0, bd=0)
        gsb = ttk.Scrollbar(lbox, orient="vertical", command=self.game_list.yview)
        self.game_list.configure(yscrollcommand=gsb.set)
        self.game_list.pack(side="left", fill="both", expand=True)
        gsb.pack(side="right", fill="y")
        self.game_list.bind("<<ListboxSelect>>", self.on_game_select)
        main = tk.Frame(self.body, padx=10)
        self.body.add(self.side, minsize=120, width=int(300 * self.zoom / 100), stretch="never")
        self.body.add(main, minsize=380, stretch="always")

        self.cards = tk.Frame(main)
        self.cards.pack(fill="x", pady=(0, 4))
        # Les barres du bas sont posées AVANT la zone des listes (side="bottom") : quand la fenêtre manque de place
        # (zoom élevé), ce sont les listes qui rétrécissent, jamais les boutons.
        actions2 = tk.Frame(main)
        actions2.pack(side="bottom", fill="x", pady=(0, 8))
        ttk.Button(actions2, text=T("Injecter la sauvegarde"), command=self.inject_selected).pack(side="left")
        ttk.Button(actions2, text=T("Envoyer vers le cloud"), command=self.cloud_send_selected).pack(side="left", padx=6)
        tk.Label(actions2, text=T("Injecter : remet la sauvegarde choisie dans le jeu."), fg=MUTED).pack(side="left", padx=8)
        actions = tk.Frame(main)
        actions.pack(side="bottom", fill="x", pady=10)
        ttk.Button(actions, text=T("Copier vers…"), command=self.copy_selected).pack(side="left")
        ttk.Button(actions, text=T("Ouvrir le dossier"), command=self.open_selected).pack(side="left", padx=6)
        ttk.Button(actions, text=T("Note…"), command=self.edit_note).pack(side="left")
        ttk.Button(actions, text=T("★ Favori"), command=self.toggle_favorite).pack(side="left", padx=6)
        ttk.Button(actions, text=T("Supprimer"), command=self.delete_selected).pack(side="left")
        self.status = tk.Label(actions, text="", anchor="e", fg=MUTED)
        self.status.pack(side="right")
        if HAS_DND:
            hint = T("Glissez une sauvegarde de la liste vers un dossier pour la copier.")
        else:
            hint = (T("Glisser-déposer : installez-le avec  py -m pip install tkinterdnd2  puis relancez.") if IS_WINDOWS
                else T("Glisser-déposer : lancez install.sh pour installer tkinterdnd2, puis relancez."))
        self.hint_label = tk.Label(main, text=hint, anchor="w", fg=MUTED)
        self.hint_label.pack(side="bottom", fill="x", pady=(4, 0))
        self._fixed_bars = (bar, dirbar, self.hint_label, actions, actions2)   # leur hauteur fixe l’écran minimal

        # deux « pages » dans la même zone : les listes habituelles, ou la page « Avant injection » (bouton du haut)
        self.page_host = tk.Frame(main)
        self.page_host.pack(fill="both", expand=True, pady=(8, 0))
        self.page = "main"
        self.page_lists = tk.PanedWindow(self.page_host, orient="vertical", sashwidth=4, bg=LINE, bd=0, sashrelief="flat")
        self.lists = self.page_lists
        self.page_lists.pack(fill="both", expand=True)
        panes = []
        for _ in range(2):
            box = tk.Frame(self.page_lists)
            head = tk.Frame(box)
            head.pack(fill="x", pady=(6, 2))
            label = tk.Label(head, text="", font=self.font_bold, anchor="w")
            label.pack(side="left")
            lim = tk.Label(head, text="", fg=MUTED, anchor="w")   # « limite de 5 » à côté du titre
            lim.pack(side="left", padx=(10, 0))
            holder = tk.Frame(box)
            holder.pack(fill="both", expand=True)
            panes.append((label, lim, self.build_tree(holder)))
            self.page_lists.add(box, minsize=60, stretch="always")
        (self.lab_manual, self.lim_manual, self.tree_manual), (self.lab_auto, self.lim_auto, self.tree_auto) = panes

        self.page_inject = tk.Frame(self.page_host)   # affichée à la place des deux listes par « Avant injection… »
        ihead = tk.Frame(self.page_inject)
        ihead.pack(fill="x", pady=(6, 2))
        ttk.Button(ihead, text=T("← Retour"), command=lambda: self.show_page("main")).pack(side="left")
        self.lab_inject = tk.Label(ihead, text="", font=self.font_bold, anchor="w")
        self.lab_inject.pack(side="left", padx=(10, 0))
        self.lim_inject = tk.Label(ihead, text="", fg=MUTED, anchor="w")
        self.lim_inject.pack(side="left", padx=(10, 0))
        tk.Label(self.page_inject, text=T("L’état actuel du jeu est copié ici avant chaque injection : vous pouvez toujours revenir "
                "en arrière."),
                 fg=MUTED, anchor="w").pack(fill="x")
        srow = tk.Frame(self.page_inject)
        srow.pack(fill="x", pady=(4, 4))
        tk.Label(srow, text=T("Garder au maximum")).pack(side="left")
        self.v_inject_keep = tk.StringVar(value=str(self.inject_keep))
        ispin = ttk.Spinbox(srow, from_=1, to=99, width=5, textvariable=self.v_inject_keep, command=self.commit_inject_keep)
        ispin.pack(side="left", padx=6)
        ispin.bind("<Return>", self.commit_inject_keep)
        ispin.bind("<FocusOut>", self.commit_inject_keep)
        tk.Label(srow, text=T("par jeu, hors favoris ★ (les plus anciennes en trop sont supprimées à la prochaine "
                "injection)"),
                 fg=MUTED).pack(side="left")
        iholder = tk.Frame(self.page_inject)
        iholder.pack(fill="both", expand=True)
        self.tree_inject = self.build_tree(iholder)
        self.active_tree = self.tree_manual
        self.setup_columns()

        self.update_dir_label()
        self.refresh()
        self.dark_titlebar()
        self.bind("<FocusIn>", self.on_focus, add="+")
        self.after(10000, self.tick)
        self.after(AUTO_TICK_MS, self.auto_tick)
        self._hide_warned = False
        self.tray = self.start_tray()
        if "--reduit" in sys.argv:   # lancée par Windows au démarrage : on démarre discrète
            if self.tray:
                self.withdraw()
            else:
                self.iconify()

    def set_icon(self):
        """Utilise icone.ico (à côté du script) pour la fenêtre, ses boîtes de dialogue et la barre des tâches."""
        if IS_WINDOWS and ICON_FILE.is_file():
            try:
                self.iconbitmap(str(ICON_FILE))
                self.iconbitmap(default=str(ICON_FILE))
            except tk.TclError:
                pass  # fichier .ico invalide : on garde l’icône par défaut

    # ----- taille du texte -----
    def set_fonts(self):
        for name, base in self._base_fonts.items():
            tkfont.nametofont(name).configure(size=scaled_size(base, self.zoom))
        size = tkfont.nametofont("TkDefaultFont").cget("size")
        self.font_bold.configure(size=size + (2 if size > 0 else -2))

    def row_height(self):
        return tkfont.nametofont("TkDefaultFont").metrics("linespace") + 12

    def update_minsize(self):
        """Taille minimale de la fenêtre : assez large pour toute la barre du haut, assez haute pour que les boutons du
        bas restent visibles (surtout quand on agrandit le texte)."""
        k = self.zoom / 100
        w, h = max(560, int(820 * k)), max(460, int(620 * k))
        bar, fixed = self.__dict__.get("bar"), self.__dict__.get("_fixed_bars")   # pas encore créés au tout début
        if bar is not None and fixed:
            try:
                self.update_idletasks()
                w = max(w, bar.winfo_reqwidth() + 30)
                h = max(h, sum(x.winfo_reqheight() for x in fixed) + self.cards.winfo_reqheight() + 190)
            except tk.TclError:
                pass
        self.minsize(min(w, self.winfo_screenwidth()), min(h, self.winfo_screenheight()))

    def step_zoom(self, delta):
        i = ZOOM_STEPS.index(self.zoom) + delta
        if 0 <= i < len(ZOOM_STEPS):
            self.change_zoom(ZOOM_STEPS[i])

    def change_zoom(self, pct):
        if pct == self.zoom:
            return
        ratio = pct / self.zoom
        self.zoom = pct
        self.set_fonts()
        ttk.Style(self).configure("Treeview", rowheight=self.row_height())
        self.zoom_label.config(text=f"{pct} %")
        self.setup_columns()
        try:
            self.body.paneconfigure(self.side, width=int(300 * pct / 100))
        except tk.TclError:
            pass
        self.update_minsize()
        if ratio > 1 and self.state() == "normal":  # texte plus grand : on agrandit la fenêtre d’autant
            self.geometry(f"{min(self.winfo_screenwidth(), int(self.winfo_width() * ratio))}x"
                          f"{min(self.winfo_screenheight(), int(self.winfo_height() * ratio))}")
        save_zoom(pct)
        self.refresh()

    # ----- sauvegarde automatique -----
    def auto_summary(self, name):
        cfg = {**DEFAULT_AUTO, **self.auto.get(name, {})}
        if not cfg["modes"]:
            return T("Sauvegarde automatique : désactivée")
        if not cfg["process"]:
            return T("⚠ Sauvegarde automatique : indiquez le programme du jeu, sinon rien n’est sauvegardé")
        parts = []
        if "interval" in cfg["modes"]:
            parts.append(T("toutes les {0} {1}", cfg['every'], unit_name(cfg['unit'], cfg['every'])))
        if "fixed" in cfg["modes"]:
            days = T("chaque jour") if len(cfg["days"]) == 7 else T("le ") + ", ".join(T(DAY_NAMES[d]) for d in cfg["days"])
            parts.append(f"{days} à {cfg['at']}")
        if "session" in cfg["modes"]:
            parts.append(T("à la fin d’une session de {0}", cfg['process']))
        keep = T(", garde les {0} dernières", cfg['limit']) if cfg["limit_on"] else ""
        return T("Sauvegarde automatique : {0}{1}", ' + '.join(parts), keep)

    def edit_auto(self, name):
        cfg = {**DEFAULT_AUTO, **self.auto.get(name, {})}
        hh, mm = parse_hhmm(cfg["at"]) or (20, 0)
        win = tk.Toplevel(self)
        win.title(T("Sauvegarde automatique : {0}", name))
        win.configure(bg=BG)
        win.transient(self)
        win.resizable(False, False)
        m_interval = tk.BooleanVar(value="interval" in cfg["modes"])
        m_fixed = tk.BooleanVar(value="fixed" in cfg["modes"])
        m_session = tk.BooleanVar(value="session" in cfg["modes"])
        every = tk.StringVar(value=str(cfg["every"]))
        unit = tk.StringVar(value=T(cfg["unit"]))
        hour, minute = tk.StringVar(value=f"{hh:02d}"), tk.StringVar(value=f"{mm:02d}")
        day_vars = [tk.BooleanVar(value=i in cfg["days"]) for i in range(7)]
        proc = tk.StringVar(value=cfg["process"])
        lim_on = tk.BooleanVar(value=cfg["limit_on"])
        lim = tk.StringVar(value=str(cfg["limit"]))
        f = tk.Frame(win, padx=16, pady=14)
        f.pack()
        tk.Label(f, text=T("Cochez un ou plusieurs modes (ils marchent ensemble). Aucun coché = désactivée."),
                 fg=MUTED).grid(row=0, column=0, columnspan=4, sticky="w", pady=3)
        ttk.Checkbutton(f, text=T("Toutes les"), variable=m_interval).grid(row=1, column=0, sticky="w", pady=3)
        ttk.Spinbox(f, from_=1, to=999, width=5, textvariable=every).grid(row=1, column=1, padx=6)
        ttk.Combobox(f, values=tuple(T(u) for u in AUTO_UNITS), textvariable=unit, state="readonly", width=10).grid(
            row=1, column=2, sticky="w")
        tk.Label(f, text=T("(seulement si la sauvegarde a changé)"), fg=MUTED).grid(row=1, column=3, sticky="w", padx=8)
        ttk.Checkbutton(f, text=T("À heure fixe"), variable=m_fixed).grid(row=2, column=0, sticky="w", pady=3)
        tf = tk.Frame(f)
        tf.grid(row=2, column=1, columnspan=2, sticky="w", padx=6)
        ttk.Spinbox(tf, from_=0, to=23, width=3, wrap=True, format="%02.0f", textvariable=hour).pack(side="left")
        tk.Label(tf, text=" : ").pack(side="left")
        ttk.Spinbox(tf, from_=0, to=59, width=3, wrap=True, format="%02.0f", textvariable=minute).pack(side="left")
        days_box = tk.Frame(f)
        days_box.grid(row=3, column=0, columnspan=4, sticky="w", padx=(26, 0))
        for i, label in enumerate(DAY_NAMES):
            ttk.Checkbutton(days_box, text=T(label), variable=day_vars[i]).pack(side="left", padx=(0, 8))
        ttk.Checkbutton(f, text=T("À la fin d’une session de jeu"), variable=m_session).grid(
            row=4, column=0, columnspan=4, sticky="w", pady=(6, 3))
        tk.Label(f, text=T("Programme du jeu :")).grid(row=5, column=0, sticky="w", pady=(10, 3))
        ttk.Entry(f, textvariable=proc, width=26).grid(row=5, column=1, columnspan=2, sticky="we", padx=6, pady=(10, 3))

        def browse():
            path = filedialog.askopenfilename(
                parent=win, title=T("Choisissez le programme du jeu (ou de l’émulateur)"),
                filetypes=[(T("Programmes"), "*.exe"), (T("Tous les fichiers"), "*.*")] if IS_WINDOWS
                else [(T("Tous les fichiers"), "*")])
            if path:
                proc.set(Path(path).name)

        pbtn = tk.Frame(f)
        pbtn.grid(row=5, column=3, sticky="w", padx=8, pady=(10, 3))
        ttk.Button(pbtn, text=T("Parcourir…"), command=browse).pack(side="left")
        ttk.Button(pbtn, text=T("Choisir dans la liste…"), command=lambda: self.pick_process(win, proc)).pack(
            side="left", padx=(6, 0))
        ttk.Checkbutton(f, text=T("Garder au maximum"), variable=lim_on).grid(row=6, column=0, sticky="w", pady=(10, 3))
        ttk.Spinbox(f, from_=1, to=99, width=5, textvariable=lim).grid(row=6, column=1, padx=6, pady=(10, 3))
        tk.Label(f, text=T("sauvegardes automatiques, hors favoris ★"), fg=MUTED).grid(
            row=6, column=2, columnspan=2, sticky="w", pady=(10, 3))
        tk.Label(f, text=(T("Le programme du jeu est obligatoire : c’est lui qui permet de ne JAMAIS sauvegarder "
                "pendant une partie, ce qui pourrait abîmer la sauvegarde. Pour un jeu sur émulateur, "
                "c’est l’émulateur. « Parcourir… » ouvre l’explorateur de fichiers pour choisir le .exe. "
                "Si le jeu tourne à l’heure prévue, la copie se fait dès qu’il est fermé. L’appli doit "
                "rester ouverte (réduite ou masquée, c’est bon).")),
                 fg=MUTED, justify="left", wraplength=int(600 * self.zoom / 100)).grid(
            row=7, column=0, columnspan=4, sticky="w", pady=(8, 10))
        btns = tk.Frame(f)
        btns.grid(row=8, column=0, columnspan=4, sticky="e")

        def number(var, low, high):
            try:
                n = int(var.get())
            except ValueError:
                return None
            return n if low <= n <= high else None

        def ok():
            n, keep = number(every, 1, 999), number(lim, 1, 99)
            h, m = number(hour, 0, 23), number(minute, 0, 59)
            if None in (n, keep, h, m):
                messagebox.showerror(T("Valeur invalide"),
                                     T("Vérifiez les nombres : intervalle 1 à 999, maximum 1 à 99, heure 0 à 23, minutes 0 à 59."),
                                     parent=win)
                return
            days = [i for i, v in enumerate(day_vars) if v.get()]
            if m_fixed.get() and not days:
                messagebox.showerror(T("Jours manquants"), T("Cochez au moins un jour."), parent=win)
                return
            p = normalize_process(proc.get())
            chosen = [m for m, v in (("interval", m_interval), ("fixed", m_fixed), ("session", m_session)) if v.get()]
            if chosen and not p:
                messagebox.showerror(T("Programme manquant"),
                                     T("Indiquez le programme du jeu (par exemple l’émulateur) : sans lui, l’appli ne peut pas "
                                             "savoir si le jeu tourne, et sauvegarder pendant une partie risque d’abîmer la sauvegarde."),
                                     parent=win)
                return
            self.auto[name] = {"modes": chosen, "every": n,
                               "unit": unit_from_label(unit.get(), AUTO_UNITS, "heures"), "process": p,
                               "limit_on": bool(lim_on.get()), "limit": keep,
                               "at": f"{h:02d}:{m:02d}", "days": days or list(range(7))}
            save_auto(self.auto)
            for d in (self._was_running, self._pending, self._last_auto, self._backoff):
                d.pop(name, None)
            win.destroy()
            self.refresh()
            self.status.config(text=f"{name} : " + self.auto_summary(name).replace(T("Sauvegarde automatique : "), T("auto, ")))

        ttk.Button(btns, text=T("Annuler"), command=win.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(btns, text=T("OK"), command=ok).pack(side="right")
        win.update_idletasks()
        x = self.winfo_rootx() + max(0, (self.winfo_width() - win.winfo_reqwidth()) // 2)
        y = self.winfo_rooty() + max(0, (self.winfo_height() - win.winfo_reqheight()) // 3)
        win.geometry(f"+{max(0, x)}+{max(0, y)}")
        self.dark_titlebar(win)
        try:
            win.wait_visibility()
            win.grab_set()   # pendant ce temps, la sauvegarde automatique est en pause
        except tk.TclError:
            pass

    def pick_process(self, parent, var):
        names = list_processes()
        if names is None:
            messagebox.showinfo(T("Liste indisponible"),
                                T("La liste des programmes n’est pas disponible ici. Tapez le nom du programme à la main."),
                                parent=parent)
            return
        dlg = tk.Toplevel(parent)
        dlg.title(T("Programmes en cours"))
        dlg.configure(bg=BG)
        dlg.transient(parent)
        tk.Label(dlg, text=T("Lancez le jeu, puis choisissez son programme dans la liste."), fg=MUTED).pack(
            padx=12, pady=(12, 4), anchor="w")
        q = tk.StringVar()
        entry = ttk.Entry(dlg, textvariable=q)
        entry.pack(fill="x", padx=12)
        box = tk.Frame(dlg)
        box.pack(fill="both", expand=True, padx=12, pady=8)
        lb = tk.Listbox(box, height=14, width=36, activestyle="none", bg=PANEL, fg=FG, selectbackground=ACCENT,
                        selectforeground="#ffffff", highlightthickness=0, bd=0, exportselection=False)
        sb = ttk.Scrollbar(box, command=lb.yview)
        lb.configure(yscrollcommand=sb.set)
        lb.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        state = {"names": names}

        def fill(*_):
            term = q.get().strip().lower()
            lb.delete(0, "end")
            for n in state["names"]:
                if term in n.lower():
                    lb.insert("end", n)

        def reload():
            fresh = list_processes()
            if fresh is not None:
                state["names"] = fresh
            fill()

        def close():
            dlg.destroy()
            try:
                parent.grab_set()
            except tk.TclError:
                pass

        def choose(*_):
            sel = lb.curselection()
            if sel:
                var.set(lb.get(sel[0]))
                close()

        q.trace_add("write", fill)
        lb.bind("<Double-1>", choose)
        row = tk.Frame(dlg)
        row.pack(fill="x", padx=12, pady=(0, 12))
        ttk.Button(row, text=T("Actualiser"), command=reload).pack(side="left")
        ttk.Button(row, text=T("Annuler"), command=close).pack(side="right", padx=(6, 0))
        ttk.Button(row, text=T("Choisir"), command=choose).pack(side="right")
        fill()
        self.dark_titlebar(dlg)
        entry.focus_set()
        try:
            dlg.wait_visibility()
            dlg.grab_set()
        except tk.TclError:
            pass

    def auto_tick(self):
        try:
            self.run_auto()
            self.cloud_tick()
        except Exception:
            import traceback
            log_error(traceback.format_exc())
        self.after(AUTO_TICK_MS, self.auto_tick)

    def run_auto(self, now=None):
        """Décide, pour chaque jeu réglé en automatique, s’il faut sauvegarder maintenant."""
        active = {}
        for g, c in self.auto.items():
            c = {**DEFAULT_AUTO, **c}
            # sans programme du jeu, on ne peut pas savoir si une partie est en cours : on ne sauvegarde pas
            if g in self.games and self.games.get(g) and c["modes"] and c["process"]:
                active[g] = c
        if not active or self.grab_current() is not None or self._lasso_active:
            return  # rien à faire, ou une boîte de dialogue est ouverte
        now = now or time.time()
        running = None
        if any(c["process"] for c in active.values()):
            names = list_processes()
            running = None if names is None else {n.lower() for n in names}
        for g, c in active.items():
            if now < self._backoff.get(g, 0):
                continue
            proc = c["process"]
            if proc:
                if running is None:
                    continue  # liste des programmes indisponible : on ne décide rien
                is_running = proc in running
            else:
                is_running = False
            modes = c["modes"]
            reason = None
            if "session" in modes:
                was = self._was_running.get(g)
                self._was_running[g] = is_running
                if was and not is_running:   # le jeu vient de se fermer
                    self._pending[g] = now + SESSION_DELAY
                due = self._pending.get(g)
                if due and now >= due:
                    del self._pending[g]
                    if not is_running:
                        reason = T("fin de session")
            if reason is None and not is_running:
                # on ne sauvegarde jamais un jeu en cours d’exécution : si l’heure est passée, ce sera fait à sa fermeture
                latest = latest_backup(g)
                ts = parse_stamp(latest.name).timestamp() if latest else None
                if "fixed" in modes and fixed_due(datetime.fromtimestamp(now), c["at"], c["days"], ts, self._last_auto.get(g)):
                    reason = f"à {c['at']}"
                elif "interval" in modes and interval_due(now, ts, self._last_auto.get(g), interval_seconds(c)):
                    reason = T("toutes les {0} {1}", c['every'], unit_name(c['unit'], c['every']))
            if reason:   # une seule sauvegarde par passage, même si plusieurs modes sont d’accord
                self.auto_backup(g, reason, now)

    def auto_backup(self, game, reason, now=None):
        now = now or time.time()
        path = self.games.get(game)
        self._last_auto[game] = now  # même s’il n’y a rien à sauvegarder : prochain essai après l’intervalle
        try:
            latest = latest_backup(game)
            if latest and verify_copy(path, latest) == []:
                self.status.config(text=T("Auto : {0} inchangé, rien à sauvegarder ({1:%H:%M})", game, datetime.now()))
                return
            dest = make_backup(game, path, auto=True)
        except Exception as e:
            import traceback
            log_error(f"Sauvegarde automatique de {game} : {e}\n{traceback.format_exc()}")
            self._backoff[game] = now + 600
            self.status.config(text=T("Auto : échec pour {0}, nouvel essai dans 10 min (voir erreurs.log)", game))
            return
        try:
            cloud_text = self.cloud_after_backup(game, dest)
        except Exception:
            import traceback
            log_error(traceback.format_exc())
            cloud_text = ""
        removed = self.enforce_auto_limit(game)
        self.refresh()
        text = T("Auto : {0} sauvegardé et vérifié à {1:%H:%M} ({2})", game, datetime.now(), reason)
        if removed:
            text += T(", {0} ancienne(s) supprimée(s)", removed)
        self.status.config(text=text + cloud_text)

    def backup_all(self):
        done, skipped, errors = 0, [], []
        for name, path in self.games.items():
            if not path:
                skipped.append(name)
                continue
            try:
                make_backup(name, path)
                self.enforce_limit(name)
                done += 1
            except Exception as e:
                errors.append(f"{name} : {e}")
        self.refresh()
        text = T("{0} jeu(x) sauvegardé(s) et vérifié(s)", done)
        if skipped:
            text += T(", sans chemin : {0}", ', '.join(skipped))
        self.status.config(text=text)
        if errors:
            messagebox.showerror(T("Sauvegarde incomplète"), "\n\n".join(errors[:5]))

    # ----- actualisation automatique -----
    def signature(self):
        return tuple((g, b.name, size_of(b)) for g, b in list_backups())

    def auto_refresh(self):
        """Recharge la liste seulement si quelque chose a changé sur le disque."""
        if self.grab_current() is not None or self._lasso_active:
            return  # une boîte de dialogue est ouverte, ou on trace un rectangle
        try:
            if self.signature() != self._sig:
                self.refresh()
        except Exception:
            import traceback
            log_error(traceback.format_exc())

    def on_focus(self, event):
        # quand on revient de l’Explorateur, on vérifie (au plus une fois par seconde)
        if time.monotonic() - self._last_check > 1.0:
            self._last_check = time.monotonic()
            self.after(100, self.auto_refresh)

    def tick(self):
        self.auto_refresh()
        self.after(10000, self.tick)

    def report_callback_exception(self, exc, val, tb):
        import traceback
        log_error("".join(traceback.format_exception(exc, val, tb)))
        messagebox.showerror(T("Erreur"), T("{0}\n"
                "\n"
                "Détails dans le fichier erreurs.log, à côté de l’appli.", val))

    # ----- taille de la fenêtre -----
    def on_configure(self, event):
        if event.widget is not self:
            return
        if self.state() == "normal":
            g = parse_geometry(self.geometry())
            if g:
                self.normal_geo = g
        if self._save_job:
            self.after_cancel(self._save_job)
        self._save_job = self.after(500, self.save_window)

    def _is_zoomed(self):
        try:
            if IS_LINUX:
                return bool(self.attributes("-zoomed"))
            return self.state() == "zoomed"
        except tk.TclError:
            return False

    def save_window(self):
        w, h, x, y = self.normal_geo
        data = {"width": w, "height": h, "x": x, "y": y, "zoomed": self._is_zoomed()}
        try:
            WINDOW_FILE.write_text(json.dumps(data), encoding="utf-8")
        except OSError:
            pass

    def on_x(self):
        """La croix ne ferme jamais l’appli : elle la masque. Pour quitter : clic droit sur l’icône près de l’horloge.
        Sans icône (pystray absent) il n’y aurait plus aucun moyen de rouvrir ou de quitter : on ferme comme avant."""
        if self.tray:
            self.save_window()
            self.hide_window()
        else:
            if not messagebox.askyesno(
                    T("Pas d’icône près de l’horloge"),
                    tray_missing_text(), parent=self):
                return
            self.on_close()

    def change_language(self, code):
        """Choix dans le menu de langue : on l’enregistre, puis l’appli se relance toute seule dans la nouvelle langue."""
        if code == LANG or code not in LANGUAGES:
            return
        if not save_language(code):
            messagebox.showerror(T("Erreur"), T("Réglage impossible ({0})", "reglages.json"), parent=self)
            return
        self.restart_app()

    def restart_app(self):
        self.save_window()
        self.stop_tray()
        try:   # on libère le port de l’instance unique pour que la nouvelle fenêtre puisse démarrer
            if globals().get("server"):
                globals()["server"].close()
        except OSError:
            pass
        exe = Path(sys.executable)
        if IS_WINDOWS and exe.name.lower() == "python.exe" and exe.with_name("pythonw.exe").exists():
            exe = exe.with_name("pythonw.exe")
        args = [a for a in sys.argv[1:] if a != "--reduit"] + ["--relance"]
        extra = {"creationflags": 0x00000008 | 0x00000200} if IS_WINDOWS else {"start_new_session": True}
        try:
            subprocess.Popen([str(exe), str(Path(__file__).resolve()), *args], close_fds=True, **extra)
        except OSError as e:
            log_error(f"Relance impossible : {e}")
        self.destroy()

    def on_close(self):
        self.save_window()
        self.stop_tray()
        self.destroy()

    # ----- thème -----
    def apply_theme(self):
        self.configure(bg=BG)
        # La molette ne doit JAMAIS changer un nombre ou une liste de choix par erreur (cases à chiffres, menus déroulants) :
        # on retire ce comportement de Tk pour toute l’appli. La fenêtre continue de défiler normalement avec la molette.
        for cls in ("TSpinbox", "TCombobox"):
            for seq in ("<MouseWheel>", "<Shift-MouseWheel>", "<Button-4>", "<Button-5>"):
                self.bind_class(cls, seq, lambda e: None)
        for pattern, value in (("*Background", BG), ("*Foreground", FG),
                               ("*Entry.Background", PANEL), ("*Entry.Foreground", FG),
                               ("*Entry.insertBackground", FG),
                               ("*selectBackground", ACCENT), ("*selectForeground", "#ffffff"),
                               ("*TCombobox*Listbox.background", PANEL), ("*TCombobox*Listbox.foreground", FG),
                               ("*TCombobox*Listbox.selectBackground", ACCENT),
                               ("*TCombobox*Listbox.selectForeground", "#ffffff")):
            self.option_add(pattern, value)
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure(".", background=BG, foreground=FG, fieldbackground=PANEL,
                     bordercolor=LINE, lightcolor=PANEL, darkcolor=PANEL, troughcolor=BG)
        st.configure("TButton", background=PANEL, foreground=FG, padding=(10, 5), borderwidth=1)
        st.map("TButton", background=[("pressed", ACCENT), ("active", "#2b323a")])
        st.configure("TMenubutton", background=PANEL, foreground=FG, padding=(10, 5), borderwidth=1, arrowcolor=FG)
        st.map("TMenubutton", background=[("pressed", ACCENT), ("active", "#2b323a")])
        st.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG,
                     rowheight=self.row_height(), borderwidth=0)
        st.map("Treeview", background=[("selected", ACCENT)], foreground=[("selected", "#ffffff")])
        st.configure("Treeview.Heading", background="#2b323a", foreground=FG, relief="flat", padding=4)
        st.map("Treeview.Heading", background=[("active", "#353d46")])
        st.configure("TCheckbutton", background=BG, foreground=FG, focuscolor=BG)
        st.map("TCheckbutton", background=[("active", BG)],
               indicatorcolor=[("selected", ACCENT), ("!selected", PANEL)])
        st.configure("TRadiobutton", background=BG, foreground=FG, focuscolor=BG)
        st.map("TRadiobutton", background=[("active", BG)],
               indicatorcolor=[("selected", ACCENT), ("!selected", PANEL)])
        st.configure("TEntry", fieldbackground=PANEL, foreground=FG, insertcolor=FG, bordercolor=LINE)
        st.configure("TCombobox", fieldbackground=PANEL, background="#2b323a", foreground=FG,
                     arrowcolor=FG, bordercolor=LINE)
        st.map("TCombobox", fieldbackground=[("readonly", PANEL)], foreground=[("readonly", FG)],
               selectbackground=[("readonly", PANEL)], selectforeground=[("readonly", FG)])
        st.configure("TSpinbox", fieldbackground=PANEL, foreground=FG, background="#2b323a",
                     bordercolor=LINE, arrowcolor=FG, insertcolor=FG)
        st.configure("TNotebook", background=BG, borderwidth=0, tabmargins=(0, 4, 0, 0))
        st.configure("TNotebook.Tab", background=PANEL, foreground=MUTED, padding=(16, 6),
                     borderwidth=0, focuscolor=PANEL)
        st.map("TNotebook.Tab", background=[("selected", "#2b323a"), ("active", "#262d34")],
               foreground=[("selected", FG), ("active", FG)])
        for sb in ("TScrollbar", "Vertical.TScrollbar"):
            st.configure(sb, background="#3a424b", troughcolor=BG, bordercolor=BG,
                         lightcolor="#3a424b", darkcolor="#3a424b", arrowcolor=FG, gripcount=0)
            st.map(sb, background=[("pressed", ACCENT), ("active", "#566170")],
                   lightcolor=[("pressed", ACCENT), ("active", "#566170")],
                   darkcolor=[("pressed", ACCENT), ("active", "#566170")],
                   arrowcolor=[("disabled", MUTED)])

    def dark_titlebar(self, win=None):
        """Barre de titre sombre sous Windows 10/11 (sinon elle reste blanche)."""
        if not sys.platform.startswith("win"):
            return
        win = win or self
        try:
            import ctypes
            win.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(win.winfo_id())
            value = ctypes.c_int(1)
            for attr in (20, 19):  # 20 : Windows récent, 19 : anciennes versions de Windows 10
                if ctypes.windll.dwmapi.DwmSetWindowAttribute(
                        hwnd, attr, ctypes.byref(value), ctypes.sizeof(value)) == 0:
                    break
        except Exception:
            pass

    # ----- affichage -----
    def current_tree(self):
        """La liste (manuelles ou automatiques) dans laquelle on a cliqué en dernier."""
        return self.active_tree

    # ----- pages : listes habituelles / « Avant injection » -----
    def every_tree(self):
        """Les trois listes, qu’elles soient visibles ou non."""
        return (self.tree_manual, self.tree_auto, self.tree_inject)

    def all_trees(self):
        """Les listes visibles à l’écran : on n’agit jamais sur une sélection cachée."""
        return (self.tree_inject,) if self.page == "inject" else (self.tree_manual, self.tree_auto)

    def show_page(self, page):
        """Bascule entre la page des listes habituelles (manuelles, automatiques) et la page « Avant injection »."""
        if page == self.page:
            return
        for t in self.every_tree():
            if t.selection():
                t.selection_set(())
        self.page = page
        if page == "inject":
            self.page_lists.pack_forget()
            self.page_inject.pack(fill="both", expand=True)
            self.active_tree = self.tree_inject
        else:
            self.page_inject.pack_forget()
            self.page_lists.pack(fill="both", expand=True)
            self.active_tree = self.tree_manual

    def toggle_inject_page(self):
        self.show_page("main" if self.page == "inject" else "inject")

    def commit_inject_keep(self, *_):
        """Nombre de sauvegardes « Avant injection » gardées par jeu (1 à 99) : enregistré dès qu’on le change."""
        try:
            n = int(self.v_inject_keep.get())
        except ValueError:
            n = 0
        if not 1 <= n <= 99:
            self.v_inject_keep.set(str(self.inject_keep))
            self.status.config(text=T("Avant injection : entrez un nombre de 1 à 99"))
            return
        if n == self.inject_keep:
            return
        self.inject_keep = n
        try:
            save_inject_keep(n)
        except OSError as e:
            self.status.config(text=T("Réglage impossible ({0})", e))
            return
        self.update_limit_labels()
        self.status.config(text=T("Avant injection : {0} gardée(s) par jeu (appliqué à la prochaine injection)", n))

    def activate(self, tree, keep=False):
        """Clic simple : on ne garde que la sélection de cette liste. Ctrl + clic : on garde aussi celle des autres listes."""
        self.active_tree = tree
        if not keep:
            for other in self.every_tree():
                if other is not tree and other.selection():
                    other.selection_set(())

    def build_tree(self, parent):
        cols = tuple(c[0] for c in COLUMNS)
        tree = ttk.Treeview(parent, columns=cols, show="headings", selectmode="extended")
        tree.tag_configure("vide", foreground=ERR)  # sauvegarde de 0 octet : texte en rouge
        for c, label, _w, _stretch, anchor in COLUMNS:
            tree.heading(c, text=label)
            tree.column(c, anchor=anchor)
        sb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        tree.bind("<ButtonPress-1>", lambda e, t=tree: self.activate(t, keep=bool(e.state & 0x4)), add="+")
        tree.bind("<Double-1>", lambda e: self.open_selected())
        tree.bind("<Control-a>", lambda e, t=tree: (self.activate(t, keep=True), self.select_everything(), "break")[2])
        tree.bind("<Delete>", lambda e: self.delete_selected())
        tree.bind("<Button-3>", lambda e, t=tree: self.show_menu(t, e))
        if sys.platform == "darwin":  # Mac : clic droit = Button-2 ou Ctrl + clic
            tree.bind("<Button-2>", lambda e, t=tree: self.show_menu(t, e))
            tree.bind("<Control-Button-1>", lambda e, t=tree: self.show_menu(t, e))
        self.bind_lasso(tree)
        if HAS_DND:
            tree.drag_source_register(1, DND_FILES)
            tree.dnd_bind("<<DragInitCmd>>", self.on_drag_init)
        return tree

    def setup_columns(self):
        for tree in self.every_tree():
            for c, _label, w, stretch, _anchor in COLUMNS:
                tree.column(c, width=int(w * self.zoom / 100), stretch=stretch)

    def fill_tree(self):
        """Remplit les trois listes avec les sauvegardes du jeu choisi (ou de tous), en gardant sélection et position."""
        game = self.current_game
        views = {"manual": self.tree_manual, "auto": self.tree_auto, "inject": self.tree_inject}
        state = {k: (tuple(t.selection()), t.yview()[0]) for k, t in views.items()}
        cols = tuple(c[0] for c in COLUMNS) if game is None else ("fav", "date", "taille", "note")
        for t in views.values():
            t.delete(*t.get_children())
            t["displaycolumns"] = cols
        counts = {k: 0 for k in views}
        for g, b, date, size, note in self._rows:
            if game is not None and g != game:
                continue
            kind = backup_kind(b)
            counts[kind] += 1
            star = "★" if f"{g}/{b.name}" in self.favorites else ""
            views[kind].insert("", "end", iid=str(b), values=(star, g, date, human(size), note),
                               tags=("vide",) if size == 0 else ())
        self.lab_manual.config(text=T("Sauvegardes manuelles ({0})", counts['manual']))
        self.lab_auto.config(text=T("Sauvegardes automatiques ({0})", counts['auto']))
        self.lab_inject.config(text=T("Avant injection ({0})", counts['inject']))
        for k, t in views.items():
            keep, top = state[k]
            t.selection_set(tuple(i for i in keep if t.exists(i)))
            t.yview_moveto(top)
        self.update_limit_labels()

    def toggle_startup(self):
        want = self.startup_var.get()
        if not set_startup(want):
            messagebox.showerror(T("Démarrage avec Windows") if IS_WINDOWS else T("Démarrage automatique"),
                                 T("Impossible de modifier le démarrage automatique."))
            self.startup_var.set(not want)
            return
        if IS_WINDOWS:
            self.status.config(text=T("L’appli se lancera avec Windows (réduite).") if want
                               else T("L’appli ne se lancera plus avec Windows."))
        else:
            self.status.config(text=T("L’appli se lancera à l’ouverture de session (réduite).") if want
                               else T("L’appli ne se lancera plus à l’ouverture de session."))

    def start_tray(self):
        """Icône près de l’horloge (facultative : `py -m pip install pystray`). Clic = rouvrir ; menu : Quitter."""
        try:
            import pystray
            from PIL import Image, ImageDraw
        except Exception:
            return None
        try:
            if ICON_FILE.is_file():
                image = Image.open(ICON_FILE)
            else:
                image = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
                d = ImageDraw.Draw(image)
                d.rounded_rectangle((4, 4, 60, 60), radius=12, fill=(61, 127, 196, 255))
                d.rectangle((16, 12, 48, 28), fill=(232, 234, 237, 255))
                d.rectangle((20, 38, 44, 52), fill=(22, 25, 29, 255))
            menu = pystray.Menu(
                pystray.MenuItem(T("Ouvrir Save Games Rw6"), lambda *_: self.after(0, self.show_window), default=True),
                pystray.MenuItem(T("Quitter"), lambda *_: self.after(0, self.quit_app)))
            icon = pystray.Icon("SaveGamesRw6", image, "Save Games Rw6", menu)
            icon.run_detached()
            return icon
        except Exception:
            import traceback
            log_error(traceback.format_exc())
            return None

    def stop_tray(self):
        try:
            if self.tray:
                self.tray.stop()
        except Exception:
            pass
        self.tray = None

    def hide_window(self):
        """Cache la fenêtre sans arrêter l’appli (les sauvegardes automatiques continuent)."""
        if not self.tray and not self._hide_warned:
            if not messagebox.askyesno(
                    T("Masquer la fenêtre"),
                    hide_text()):
                return
            self._hide_warned = True
        self.withdraw()
        self.status.config(text="")

    def show_window(self):
        try:
            self.deiconify()
            self.state("normal")
            self.lift()
            self.attributes("-topmost", True)   # pour passer devant les autres fenêtres
            self.after(300, lambda: self.attributes("-topmost", False))
            self.focus_force()
        except tk.TclError:
            pass

    def quit_app(self):
        self.on_close()

    def on_game_select(self, _event=None):
        sel = self.game_list.curselection()
        if not sel or sel[0] >= len(self._names):
            return
        self.current_game = self._names[sel[0]]
        self.show_card()
        self.fill_tree()

    def bind_lasso(self, tree):
        """Rectangle de sélection : on appuie dans la zone vide sous les lignes et on glisse.
        (Ctrl enfoncé : on ajoute à la sélection existante.)"""
        st = {"start": None, "base": (), "lines": []}

        def press(e):
            if tree.identify_region(e.x, e.y) != "nothing":
                st["start"] = None
                return
            ctrl = bool(e.state & 0x4)
            st["start"] = (e.x, e.y)
            st["base"] = tuple(tree.selection()) if ctrl else ()
            if not ctrl:
                tree.selection_set(())
            self._lasso_active = True
            if not st["lines"]:
                st["lines"] = [tk.Frame(tree, bg=ACCENT) for _ in range(4)]

        def motion(e):
            if not st["start"]:
                return
            l, r = sorted((st["start"][0], e.x))
            t, b = sorted((st["start"][1], e.y))
            top, bottom, left, right = st["lines"]
            top.place(x=l, y=t, width=r - l + 1, height=1)
            bottom.place(x=l, y=b, width=r - l + 1, height=1)
            left.place(x=l, y=t, width=1, height=b - t + 1)
            right.place(x=r, y=t, width=1, height=b - t + 1)
            hits = []
            for iid in tree.get_children():
                bb = tree.bbox(iid)
                if bb and bb[1] < b and bb[1] + bb[3] > t and bb[0] < r and bb[0] + bb[2] > l:
                    hits.append(iid)
            tree.selection_set(tuple(dict.fromkeys(st["base"] + tuple(hits))))

        def release(e):
            for f in st["lines"]:
                f.destroy()
            st["lines"] = []
            st["start"] = None
            self._lasso_active = False

        tree.bind("<ButtonPress-1>", press, add="+")
        tree.bind("<B1-Motion>", motion, add="+")
        tree.bind("<ButtonRelease-1>", release, add="+")

    def refresh(self):
        rows = []
        for g, b in list_backups():
            d = parse_stamp(b.name)
            date = T("{0:%d/%m/%Y à %H:%M:%S}", d) if d else b.name
            rows.append((g, b, date, size_of(b), self.notes.get(f"{g}/{b.name}", "")))
        self._rows = rows
        self._sig = tuple((g, b.name, size) for g, b, _d, size, _n in rows)
        if self.current_game not in self.games:
            self.current_game = None
        self._names = [None] + list(self.games)
        self.game_list.delete(0, "end")
        self.game_list.insert("end", T("Tous"))
        for name in self.games:
            mine = [b for g, b, *_ in rows if g == name]
            kinds = [backup_kind(b) for b in mine]
            n_fav = sum(1 for b in mine if f"{name}/{b.name}" in self.favorites)
            self.game_list.insert("end", T("{0} · {1} manu · {2} auto · {3} inj · {4} ★", name, kinds.count('manual'), kinds.count('auto'), kinds.count('inject'), n_fav))
        idx = self._names.index(self.current_game)
        self.game_list.selection_clear(0, "end")
        self.game_list.selection_set(idx)
        self.game_list.see(idx)
        self.show_card()
        self.fill_tree()
        self.update_minsize()

    def show_card(self):
        for w in self.cards.winfo_children():
            w.destroy()
        self._vars = []
        if not self.games:
            tk.Label(self.cards, text=T("Aucun jeu pour l’instant. Cliquez sur « Ajouter un jeu » pour commencer."),
                     fg=MUTED, anchor="w").pack(fill="x", pady=8)
        elif self.current_game is None:
            box = tk.Frame(self.cards)
            box.pack(fill="x", pady=4)
            tk.Label(box, text=T("Tous les jeux : {0} sauvegarde(s)", len(self._rows)), fg=MUTED).pack(side="left")
            ttk.Button(box, text=T("Tout sauvegarder"), command=self.backup_all).pack(side="right")
        else:
            self.build_game_card(self.current_game)

    def build_game_card(self, name):
        path = self.games.get(name, "")
        box = tk.LabelFrame(self.cards, text=name, padx=8, pady=6, bg=BG, fg=FG, highlightbackground=LINE)
        box.pack(fill="x", pady=3)
        mine = [b for g, b, *_ in self._rows if g == name]
        if mine:
            last = parse_stamp(mine[0].name)
            when = T("{0:%d/%m/%Y à %H:%M}", last) if last else mine[0].name
            kinds = [backup_kind(b) for b in mine]
            info = (T("{0} manuelle(s), {1} automatique(s), {2} avant injection, dernière le {3}", kinds.count('manual'), kinds.count('auto'), kinds.count('inject'), when))
        else:
            info = T("Aucune sauvegarde pour l’instant")
        text, defined = describe_source(path)
        head = tk.Frame(box)
        head.pack(fill="x")
        if defined:
            ttk.Button(head, text=T("Accéder au dossier"), command=lambda: self.open_source(name)).pack(
                side="right", padx=(8, 0), anchor="n")
        tk.Label(head, text=text, anchor="w", fg=FG if defined else ERR,
                 wraplength=int(400 * self.zoom / 100), justify="left").pack(side="left", fill="x", expand=True)
        tk.Label(box, text=info, anchor="w", fg=MUTED).pack(fill="x")
        row = tk.Frame(box)
        row.pack(fill="x", pady=(4, 0))
        ttk.Button(row, text=T("Sauvegarder {0}", name), command=lambda: self.backup(name)).pack(side="left")
        ttk.Button(row, text=T("Dossier…"), command=lambda: self.pick(name, folder=True)).pack(side="left", padx=6)
        ttk.Button(row, text=T("Fichiers…"), command=lambda: self.pick(name, folder=False)).pack(side="left")
        ttk.Button(row, text=T("Renommer"), command=lambda: self.rename_game(name)).pack(side="left", padx=6)

        lim = self.limits.get(name, DEFAULT_LIMIT)
        on_var, max_var = tk.BooleanVar(value=lim["on"]), tk.StringVar(value=str(lim["max"]))
        self._vars.extend((on_var, max_var))
        commit = lambda: self.commit_limit(name, on_var, max_var)
        row2 = tk.Frame(box)
        row2.pack(fill="x", pady=(6, 0))
        ttk.Checkbutton(row2, text=T("Garder au maximum"), variable=on_var, command=commit).pack(side="left")
        spin = ttk.Spinbox(row2, from_=1, to=99, width=4, textvariable=max_var, command=commit)
        spin.pack(side="left", padx=6)
        spin.bind("<Return>", lambda e: commit())
        spin.bind("<FocusOut>", lambda e: commit())
        tk.Label(row2, text=T("sauvegardes manuelles, hors favoris ★ (les plus anciennes en trop sont supprimées)"),
                 fg=MUTED).pack(side="left")

        row3 = tk.Frame(box)
        row3.pack(fill="x", pady=(6, 0))
        ttk.Button(row3, text=T("Automatique…"), command=lambda: self.edit_auto(name)).pack(side="left")
        tk.Label(row3, text=self.auto_summary(name), fg=MUTED).pack(side="left", padx=8)
        row4 = tk.Frame(box)
        row4.pack(fill="x", pady=(6, 0))
        ttk.Button(row4, text=T("Cloud…"), command=self.cloud_window).pack(side="left")
        ctext = self.cloud_summary(name)
        tk.Label(row4, text=ctext, fg=ERR if ctext.startswith("⚠") else MUTED, anchor="w", justify="left",
                 wraplength=int(520 * self.zoom / 100)).pack(side="left", padx=8)

    # ----- actions -----
    def pick(self, name, folder):
        start = source_folder(self.games.get(name, ""))   # on s’ouvre là où le jeu range déjà sa sauvegarde
        kw = {"initialdir": str(start)} if start else {}
        if folder:
            path = filedialog.askdirectory(title=T("Dossier de sauvegarde de {0}", name), **kw)
        else:
            files = filedialog.askopenfilenames(
                title=T("Fichiers de sauvegarde de {0} (Ctrl ou Maj pour en choisir plusieurs)", name), **kw)
            files = list(files) if files and not isinstance(files, str) else ([files] if files else [])
            if len({Path(f).name.lower() for f in files}) != len(files):
                messagebox.showerror(T("Noms identiques"), T("Deux fichiers portent le même nom : choisissez des fichiers d’un seul dossier."))
                return
            path = files[0] if len(files) == 1 else files   # un seul fichier : on garde l’ancien format
        if path:
            self.games[name] = path
            save_config(self.games)
            self.refresh()

    def add_game(self):
        name = (simpledialog.askstring(T("Ajouter un jeu"), T("Nom du jeu :"), parent=self) or "").strip()
        if not name:
            return
        if not valid_name(name):
            messagebox.showwarning(T("Nom invalide"), T("Évitez les caractères \\ / : * ? \" < > | et un point ou espace à la fin. Le nom « Auto » "
                    "est réservé."))
            return
        if name in self.games:
            messagebox.showinfo(T("Déjà présent"), T("{0} existe déjà.", name))
            return
        self.games[name] = ""
        save_config(self.games)
        self.refresh()

    def rename_game(self, old):
        new = (simpledialog.askstring(T("Renommer"), T("Nouveau nom pour {0} :", old),
                                      initialvalue=old, parent=self) or "").strip()
        if not new or new == old:
            return
        if not valid_name(new):
            messagebox.showwarning(T("Nom invalide"), T("Évitez les caractères \\ / : * ? \" < > | et un point ou espace à la fin. Le nom « Auto » "
                    "est réservé."))
            return
        if new in self.games:
            messagebox.showinfo(T("Déjà présent"), T("{0} existe déjà.", new))
            return
        old_dir, new_dir = BACKUP_DIR / old, BACKUP_DIR / new
        try:
            if old_dir.exists():
                if new_dir.exists() and not old_dir.samefile(new_dir):
                    messagebox.showerror(T("Renommage impossible"), T("Un dossier « {0} » existe déjà dans Sauvegardes.", new))
                    return
                old_dir.rename(new_dir)
        except OSError as e:
            messagebox.showerror(T("Renommage impossible"), T("{0}\n"
                    "\n"
                    "Fermez l’Explorateur s’il est ouvert dans ce dossier.", e))
            return
        self.games = {(new if k == old else k): v for k, v in self.games.items()}
        save_config(self.games)
        migrate_old_names()  # met aussi le nouveau nom du jeu dans les dossiers déjà faits
        self.notes = remap_notes(self.notes, old, new)
        save_notes(self.notes)
        self.limits = remap_limits(self.limits, old, new)
        save_limits(self.limits)
        self.favorites = remap_favorites(self.favorites, old, new)
        save_favorites(self.favorites)
        self.auto = remap_auto(self.auto, old, new)
        save_auto(self.auto)
        rename_inject_counter(old, new)
        self.cloud["games"] = {(new if k == old else k): v for k, v in self.cloud["games"].items()}
        self.cloud["pending"] = [p for p in self.cloud["pending"] if p["game"] != old]
        save_cloud(self.cloud)
        if self.current_game == old:
            self.current_game = new
        sync_note_files(self.notes)
        self.refresh()
        self.status.config(text=T("{0} renommé en {1}", old, new))

    def backup(self, name):
        path = self.games.get(name, "")
        if not path:
            messagebox.showinfo(T("Chemin manquant"), T("Définissez d’abord le chemin de {0} (bouton Dossier… ou Fichiers…).", name))
            return
        try:
            make_backup(name, path)
        except Exception as e:
            messagebox.showerror(T("Sauvegarde impossible"), str(e))
            return
        removed = self.enforce_limit(name)  # seulement APRÈS une sauvegarde réussie et vérifiée
        self.refresh()
        text = T("{0} sauvegardé et vérifié à {1:%H:%M:%S}", name, datetime.now())
        if removed:
            text += T(", {0} ancienne(s) supprimée(s)", removed)
        self.status.config(text=text)

    def prune(self, name, keep, auto, kind=None):
        removed = 0
        for b in backups_to_prune(name, keep, self.favorites, auto=auto, kind=kind):
            shutil.rmtree(b, ignore_errors=True)
            if not b.exists():
                removed += 1
                self.notes.pop(f"{name}/{b.name}", None)
        if removed:
            save_notes(self.notes)
        return removed

    def enforce_limit(self, name):
        """Limite des sauvegardes MANUELLES (désactivée tant qu’on ne l’a pas choisie)."""
        lim = self.limits.get(name)
        if not lim or not lim.get("on"):
            return 0
        return self.prune(name, lim["max"], auto=False)

    def enforce_auto_limit(self, name):
        """Limite des sauvegardes AUTOMATIQUES (5 par défaut, réglable dans « Automatique… »)."""
        cfg = {**DEFAULT_AUTO, **self.auto.get(name, {})}
        if not cfg["limit_on"]:
            return 0
        return self.prune(name, cfg["limit"], auto=True)

    def commit_limit(self, name, on_var, max_var):
        """Enregistre la case et le nombre. Rien n’est supprimé ici : la limite s’applique
        à la prochaine sauvegarde, après avoir prévenu s’il y a déjà trop de sauvegardes."""
        cur = self.limits.get(name, DEFAULT_LIMIT)
        try:
            n = int(max_var.get())
            if not 1 <= n <= 99:
                raise ValueError
        except ValueError:
            n = cur["max"]
            max_var.set(str(n))
        new = {"on": bool(on_var.get()), "max": n}
        if new == cur:
            return
        if new["on"]:
            extra = len(backups_to_prune(name, 0, self.favorites)) + 1 - n
            if extra > 0 and not messagebox.askyesno(
                    T("Limite de sauvegardes"),
                    T("Il y a déjà {0} sauvegarde(s) de {1}.\n"
                            "\n"
                            "Avec un maximum de {2}, la prochaine sauvegarde supprimera automatiquement les {3} plus "
                            "ancienne(s).\n"
                            "\n"
                            "Activer cette limite ?", extra + n - 1, name, n, extra)):
                on_var.set(cur["on"])
                max_var.set(str(cur["max"]))
                return
        self.limits[name] = new
        save_limits(self.limits)
        self.status.config(text=f"{name} : " + (T("maximum {0} sauvegardes", n) if new["on"] else T("pas de limite")))
        self.update_limit_labels()

    # ----- rappel des limites à côté du titre des listes -----
    def limit_text(self, kind, game):
        """Texte court de la limite choisie pour une sorte de sauvegarde : « limite de 5 » ou « pas de limite »."""
        if kind == "inject":
            return T("limite de {0}", self.inject_keep)
        if kind == "manual":
            lim = self.limits.get(game, DEFAULT_LIMIT)
            return T("limite de {0}", lim['max']) if lim["on"] else T("pas de limite")
        cfg = {**DEFAULT_AUTO, **self.auto.get(game, {})}
        return T("limite de {0}", cfg['limit']) if cfg["limit_on"] else T("pas de limite")

    def update_limit_labels(self):
        """Affiche la limite à côté du titre de chaque liste (celle du jeu choisi ; en vue « Tous », celle qui est
        commune à tous les jeux, sinon « limite selon le jeu »)."""
        games = [self.current_game] if self.current_game else list(self.games)
        for kind, label in (("manual", self.lim_manual), ("auto", self.lim_auto), ("inject", self.lim_inject)):
            texts = {self.limit_text(kind, g) for g in games}
            text = texts.pop() if len(texts) == 1 else (T("limite selon le jeu") if texts else "")
            label.config(text=text)

    # ----- limites pour tous -----
    def apply_limits(self, kind, n=None, on=None, parent=None):
        """Applique la limite de sauvegardes locales à TOUS les jeux : seulement le nombre (n), seulement la case
        (on), ou les deux. kind : "manual" (Garder au maximum) ou "auto" (réglage de « Automatique… »)."""
        changes, over = {}, []
        for g in self.games:
            if kind == "manual":
                cur = self.limits.get(g, DEFAULT_LIMIT)
                new = {"on": cur["on"] if on is None else bool(on), "max": cur["max"] if n is None else n}
                count = len(backups_to_prune(g, 0, self.favorites))
                on_now, max_now = new["on"], new["max"]
            else:
                cur = {**DEFAULT_AUTO, **self.auto.get(g, {})}
                new = {**cur, "limit_on": cur["limit_on"] if on is None else bool(on),
                       "limit": cur["limit"] if n is None else n}
                count = len(backups_to_prune(g, 0, self.favorites, auto=True))
                on_now, max_now = new["limit_on"], new["limit"]
            changes[g] = new
            if on_now and count > max_now:
                over.append(f"{g} ({count - max_now})")
        if over and not messagebox.askyesno(
                T("Limite pour tous"),
                T("Avec ce réglage, la prochaine sauvegarde supprimera automatiquement les plus anciennes "
                        "(hors favoris ★) de :\n")
                + ", ".join(over) + T("\n"
                        "\n"
                        "Continuer ?"), parent=parent):
            return False
        for g, new in changes.items():
            if kind == "manual":
                self.limits[g] = new
            else:
                self.auto[g] = new
        if kind == "manual":
            save_limits(self.limits)
        else:
            save_auto(self.auto)
        self.refresh()
        what = T("manuelles") if kind == "manual" else T("automatiques")
        if on is None:
            self.status.config(text=T("Sauvegardes {0} : maximum {1} pour tous les jeux (cases inchangées)", what, n))
        else:
            self.status.config(text=T("Sauvegardes {0} : limite {1} pour tous les jeux", what, T("cochée") if on else T("décochée")))
        return True

    def all_limits_window(self):
        """Fenêtre « Limites pour tous les jeux » : change le nombre et/ou coche la case pour tous les jeux d’un coup."""
        win = tk.Toplevel(self)
        win.title(T("Limites pour tous les jeux"))
        win.configure(bg=BG)
        win.transient(self)
        win.resizable(False, False)
        f = tk.Frame(win, padx=16, pady=14)
        f.pack()
        keep_vars = []

        def section(title, label, default, kind):
            tk.Label(f, text=title, font=self.font_bold, anchor="w").pack(fill="x", pady=(8, 0))
            row = tk.Frame(f)
            row.pack(fill="x", pady=3)
            tk.Label(row, text=label).pack(side="left")
            var = tk.StringVar(value=str(default))
            keep_vars.append(var)
            ttk.Spinbox(row, from_=1, to=99, width=5, textvariable=var).pack(side="left", padx=6)

            def number():
                try:
                    n = int(var.get())
                except ValueError:
                    n = 0
                if not 1 <= n <= 99:
                    messagebox.showerror(T("Valeur invalide"), T("Entrez un nombre de 1 à 99."), parent=win)
                    return None
                return n

            def apply_number():
                n = number()
                if n is not None:
                    self.apply_limits(kind, n=n, parent=win)

            brow = tk.Frame(f)
            brow.pack(fill="x", pady=3)
            ttk.Button(brow, text=T("Appliquer le nombre à tous"), command=apply_number).pack(side="left")
            ttk.Button(brow, text=T("Cocher pour tous"), command=lambda: self.apply_limits(kind, on=True, parent=win)).pack(
                side="left", padx=6)
            ttk.Button(brow, text=T("Décocher pour tous"), command=lambda: self.apply_limits(kind, on=False, parent=win)).pack(
                side="left")

        section(T("Sauvegardes manuelles"), T("Garder au maximum"), DEFAULT_LIMIT["max"], "manual")
        section(T("Sauvegardes automatiques"), T("Garder les"), DEFAULT_AUTO["limit"], "auto")
        tk.Label(f, text=T("« Appliquer le nombre » change seulement le chiffre, pas la case cochée. Les favoris ★ ne "
                "comptent jamais."),
                 fg=MUTED, justify="left", anchor="w", wraplength=int(480 * self.zoom / 100)).pack(fill="x", pady=(10, 0))
        ttk.Button(f, text=T("Fermer"), command=win.destroy).pack(anchor="e", pady=(10, 0))
        win.geometry(f"+{self.winfo_rootx() + 80}+{self.winfo_rooty() + 80}")
        self.dark_titlebar(win)

    # ----- dossier des sauvegardes, accès rapide aux dossiers -----
    def update_dir_label(self):
        missing = BACKUP_DIR != DEFAULT_BACKUP_DIR and not BACKUP_DIR.is_dir()
        self.dir_label.config(text=str(BACKUP_DIR) + (T("   ⚠ introuvable (disque débranché ?)") if missing else ""),
                              fg=ERR if missing else FG)

    def open_backup_dir(self):
        target = source_folder(str(BACKUP_DIR))
        try:
            if target is None:
                raise OSError(T("dossier introuvable"))
            open_folder(target)
        except OSError as e:
            self.status.config(text=T("Impossible d’ouvrir le dossier des sauvegardes ({0})", e))

    def open_source(self, name):
        """« Accéder au dossier » : ouvre le dossier où le jeu range sa sauvegarde."""
        target = source_folder(self.games.get(name, ""))
        try:
            if target is None:
                raise OSError(T("chemin introuvable"))
            open_folder(target)
        except OSError as e:
            self.status.config(text=T("Impossible d’ouvrir le dossier de {0} ({1})", name, e))

    def change_backup_dir(self):
        """Choisir où est le dossier qui contient toutes les sauvegardes (par défaut : à côté de l’appli)."""
        old = BACKUP_DIR
        start = source_folder(str(old))
        kw = {"initialdir": str(start)} if start else {}
        chosen = filedialog.askdirectory(parent=self, title=T("Choisissez le dossier où ranger toutes les sauvegardes"), **kw)
        if not chosen:
            return
        new = Path(chosen)
        try:
            r_old, r_new = old.resolve(), new.resolve()
        except OSError:
            r_old, r_new = old, new
        if r_new == r_old:
            return
        if r_old in r_new.parents:
            messagebox.showerror(T("Dossier refusé"), T("Choisissez un dossier hors de l’ancien dossier des sauvegardes."))
            return
        if r_new in r_old.parents:
            messagebox.showerror(T("Dossier refusé"), T("Le nouveau dossier ne peut pas contenir l’ancien : choisissez un dossier à part (la "
                    "fenêtre permet d’en créer un nouveau)."))
            return
        for f in self.cloud["folders"]:
            try:
                rf = Path(f).resolve()
            except OSError:
                continue
            if r_new == rf or r_new in rf.parents:
                messagebox.showerror(T("Dossier refusé"), T("Un dossier cloud est dans ce dossier :\n"
                        "{0}\n"
                        "\n"
                        "Choisissez-en un autre.", f))
                return
        try:
            strange = [p.name for p in new.iterdir() if not (p.is_dir() and p.name in self.games)]
        except OSError as e:
            messagebox.showerror(T("Dossier illisible"), str(e))
            return
        if strange and not messagebox.askyesno(
                T("Ce dossier n’est pas vide"),
                T("Ce dossier contient déjà autre chose : {0}\n"
                        "\n"
                        "Ses sous-dossiers seraient pris pour des jeux. Mieux vaut un dossier vide (vous pouvez en "
                        "créer un). L’utiliser quand même ?", ', '.join(strange[:5])),
                icon="warning", default="no"):
            return
        try:
            has_old = old.is_dir() and any(p.is_dir() for p in old.iterdir())
        except OSError:
            has_old = False
        if has_old:
            ans = messagebox.askyesnocancel(
                T("Déplacer les sauvegardes ?"),
                T("Déplacer les sauvegardes existantes vers le nouveau dossier ?\n"
                        "\n"
                        "Oui : elles sont copiées, vérifiées, puis supprimées de l’ancien dossier.\n"
                        "Non : seul l’emplacement change, les anciennes restent dans\n"
                        "{0}\n"
                        "(la liste sera vide tant que vous ne les remettez pas).", old))
            if ans is None:
                return
            if ans:
                problems = move_backups(old, new)
                if problems:
                    messagebox.showerror(T("Déplacement impossible"), T("Rien n’a été changé.\n"
                            "\n") + "\n".join(problems[:6]))
                    return
        try:
            save_backup_dir(new)
        except OSError as e:
            messagebox.showerror(T("Réglage impossible"), str(e))
            return
        sync_note_files(self.notes)
        self.update_dir_label()
        self.refresh()
        self.status.config(text=T("Dossier des sauvegardes : {0}", new))

    # ----- cloud -----
    def cloud_game(self, name):
        return {**DEFAULT_CLOUD_GAME, **self.cloud["games"].get(name, {})}

    def cloud_limit_bytes(self):
        return int(self.cloud["limit_gb"] * 1024 ** 3) if self.cloud["limit_on"] else None

    def cloud_retry_seconds(self):
        return cloud_retry_seconds(self.cloud)

    def cloud_candidates(self, root):
        """Sauvegardes du cloud qu’on peut supprimer pour faire de la place (hors favoris ★), les plus anciennes d’abord."""
        return sorted(((parse_stamp(b.name), size_of(b), b) for g, b in list_backups(None, root)
                       if parse_stamp(b.name) and f"{g}/{b.name}" not in self.favorites), key=lambda t: t[0])

    def cloud_warning(self, folder):
        """Petit avertissement (jamais de pop-up) sur la place utilisée ; chaîne vide s’il n’y a rien à signaler."""
        msgs = []
        if self.cloud_alerts.get(folder):
            msgs.append(self.cloud_alerts[folder])
        limit = self.cloud_limit_bytes()
        if limit and Path(folder).is_dir():
            used = folder_used(cloud_root(folder))
            if used >= limit:
                msgs.append(T("⚠ Place du cloud pleine"))
            elif used >= 0.9 * limit:
                msgs.append(T("⚠ Attention : plus de 90 % de la place du cloud est utilisée"))
        return " ".join(dict.fromkeys(msgs))

    def cloud_summary(self, name):
        g = self.cloud_game(name)
        if not g["on"]:
            return T("Cloud : désactivé pour ce jeu")
        if not self.cloud["folders"] or not g["folders"]:
            return T("⚠ Cloud : choisissez au moins un dossier cloud (bouton Cloud…), sinon rien n’est envoyé")
        keep = T(", garde les {0} dernières", g['max']) if g["max_on"] else ""
        waiting = sum(1 for p in self.cloud["pending"] if p["game"] == name)
        text = T("Cloud : envoi automatique vers {0} dossier(s){1}", len(g['folders']), keep)
        if waiting:
            text += T(", {0} en attente", waiting)
        if self.cloud["limit_on"]:
            for f in g["folders"]:
                warn = self.cloud_warning(f)
                if warn:
                    return f"{warn} — {text}"
        return text

    def cloud_push(self, backup, folder):
        """Envoie une sauvegarde vers un dossier cloud. Renvoie None si c’est fait, sinon ("retry", texte) (à réessayer
        plus tard) ou ("full", texte) (limite de place atteinte : on n’envoie pas)."""
        backup = Path(backup)
        game = game_of(backup)
        deleted = 0
        try:
            if not Path(folder).is_dir():
                raise FileNotFoundError(T("Dossier cloud introuvable : {0}", folder))
            root = cloud_root(folder)
            limit = self.cloud_limit_bytes()
            if limit is not None and not cloud_target(folder, backup).is_dir():
                used, need = folder_used(root), size_of(backup)
                if used + need > limit:
                    plan = None
                    if self.cloud["over"] == "delete":
                        plan = plan_room(used, need, limit, self.cloud_candidates(root))
                    if plan is None:
                        self.cloud_alerts[folder] = T("⚠ Limite de place atteinte : envoi arrêté")
                        return ("full", self.cloud_alerts[folder])
                    for p in plan:
                        shutil.rmtree(p, ignore_errors=True)
                    deleted = len(plan)
                    self.cloud_alerts[folder] = T("⚠ Limite de place atteinte : {0} ancienne(s) supprimée(s) du cloud", deleted)
            cloud_send(backup, folder)
            g = self.cloud_game(game)
            if g["max_on"]:
                for b in cloud_to_prune(folder, game, g["max"], self.favorites, protect=backup.name):
                    shutil.rmtree(b, ignore_errors=True)
        except Exception as e:
            import traceback
            log_error(f"Envoi cloud de {backup.name} vers {folder} : {e}\n{traceback.format_exc()}")
            return ("retry", str(e))
        if not deleted:
            self.cloud_alerts.pop(folder, None)
        return None

    def cloud_enqueue(self, backup, folder):
        backup = Path(backup)
        item = {"game": game_of(backup), "name": backup.name, "auto": is_auto(backup), "kind": backup_kind(backup),
                "folder": folder, "tries": 1}
        if not any(p["game"] == item["game"] and p["name"] == item["name"] and p["folder"] == folder
                   for p in self.cloud["pending"]):
            self.cloud["pending"].append(item)
            save_cloud(self.cloud)

    def cloud_send_to(self, backup, folders):
        """Envoie une sauvegarde vers plusieurs dossiers cloud. Renvoie (envoyées, en attente, bloquées)."""
        ok = queued = full = 0
        for folder in folders:
            res = self.cloud_push(backup, folder)
            if res is None:
                ok += 1
            elif res[0] == "full":
                full += 1
            else:
                self.cloud_enqueue(backup, folder)
                queued += 1
        if queued:
            self._cloud_next = time.time() + self.cloud_retry_seconds()
        return ok, queued, full

    @staticmethod
    def cloud_text(ok, queued, full):
        parts = []
        if ok:
            parts.append(T("{0} envoi(s) cloud vérifié(s)", ok))
        if queued:
            parts.append(T("{0} en attente (nouvel essai automatique)", queued))
        if full:
            parts.append(T("{0} bloqué(s) : limite de place", full))
        return ", ".join(parts)

    def cloud_after_backup(self, game, backup):
        """Après une sauvegarde AUTOMATIQUE réussie : envoi vers les dossiers cloud choisis pour ce jeu."""
        g = self.cloud_game(game)
        folders = [f for f in g["folders"] if f in self.cloud["folders"]]
        if not g["on"] or not folders:
            return ""
        text = self.cloud_text(*self.cloud_send_to(backup, folders))
        return f", {text}" if text else ""

    def cloud_tick(self, now=None):
        """Réessaie les envois en attente (dossier cloud introuvable, par exemple), au rythme choisi."""
        now = now or time.time()
        pending = self.cloud["pending"]
        if not pending or now < self._cloud_next:
            return
        keep, lost, done = [], [], 0
        for item in pending:
            kind = item.get("kind") or ("auto" if item["auto"] else "manual")
            backup = BACKUP_DIR / item["game"] / KIND_DIRS[kind] / item["name"]
            if not backup.is_dir() or item["folder"] not in self.cloud["folders"]:
                continue   # sauvegarde supprimée ou dossier retiré : on abandonne sans bruit
            res = self.cloud_push(backup, item["folder"])
            if res is None:
                done += 1
            elif res[0] == "retry":
                item["tries"] += 1
                (lost if item["tries"] >= self.cloud["tries"] else keep).append(item)
        self.cloud["pending"] = keep
        save_cloud(self.cloud)
        if keep:
            self._cloud_next = now + self.cloud_retry_seconds()
        if done:
            self.status.config(text=T("Cloud : {0} envoi(s) en attente terminé(s) et vérifié(s) ({1:%H:%M})", done, datetime.now()))
        if lost:
            self.cloud_critical(lost)
        if done or lost:
            self.show_card()

    def cloud_critical(self, lost):
        """Le seul cas où l’appli affiche un message qui bloque : un envoi abandonné après tous les essais."""
        folders = ", ".join(sorted({i["folder"] for i in lost}))
        for i in lost:
            log_error(T("Envoi cloud abandonné : {0} / {1} vers {2}", i['game'], i['name'], i['folder']))

        def show():
            messagebox.showwarning(
                T("Cloud : envoi abandonné"),
                T("{0} envoi(s) vers le cloud ont échoué après {1} essai(s).\n"
                        "\n"
                        "Dossier : {2}\n"
                        "\n"
                        "Vérifiez que ce dossier existe (Drive lancé, disque branché), puis renvoyez ces "
                        "sauvegardes avec « Envoyer vers le cloud ». Détails dans erreurs.log.", len(lost), self.cloud['tries'], folders))
        self.after(200, show)

    def cloud_send_selected(self):
        """Envoie les sauvegardes sélectionnées (manuelles ou automatiques) vers le cloud, notes comprises."""
        items = self.selected_all()
        if not items:
            return
        if not self.cloud["folders"]:
            self.status.config(text=T("Cloud : ajoutez d’abord un dossier cloud (bouton « Cloud… » en haut)."))
            return
        ok = queued = full = 0
        for p in items:
            g = self.cloud_game(game_of(p))
            folders = [f for f in g["folders"] if f in self.cloud["folders"]] or self.cloud["folders"]
            a, b, c = self.cloud_send_to(p, folders)
            ok, queued, full = ok + a, queued + b, full + c
        self.status.config(text=T("Cloud : ") + (self.cloud_text(ok, queued, full) or T("rien à envoyer")))
        self.show_card()

    def inject_selected(self):
        """Remet la sauvegarde choisie dans le jeu, à la place de l’actuelle. L’état d’avant est gardé d’abord."""
        p = self.selected()
        if not p:
            return
        game = game_of(p)
        source = self.games.get(game, "")
        if not source:
            messagebox.showinfo(T("Chemin manquant"), T("Définissez d’abord le chemin de {0} (bouton Dossier… ou Fichiers…) : c’est là que la "
                    "sauvegarde sera remise.", game))
            return
        proc = normalize_process(self.auto.get(game, {}).get("process", ""))
        if proc:
            names = list_processes()
            if names and proc in {n.lower() for n in names}:
                messagebox.showwarning(T("Jeu en cours"), T("{0} est en cours d’exécution. Fermez le jeu (ou l’émulateur) avant d’injecter une "
                        "sauvegarde, sinon il pourrait la réécrire.", proc))
                return
        where, _defined = describe_source(source)
        try:   # même contenu que le jeu en ce moment ? (Note.txt ne compte pas ; SHA-256 de chaque fichier)
            same = all(q.exists() for q in source_paths(source)) and not verify_copy(source, p)
        except Exception:
            same = False
        if same:
            if not messagebox.askyesno(
                    T("Sauvegarde identique"),
                    T("Cette sauvegarde est identique à la sauvegarde actuelle de {0} : l’injecter ne changerait "
                            "rien.\n"
                            "\n"
                            "{1}\n"
                            "\n"
                            "Voulez-vous poursuivre quand même ?", game, p.name),
                    icon="question", default="no"):
                return
        elif not messagebox.askyesno(
                T("Injecter la sauvegarde"),
                T("Remplacer la sauvegarde actuelle de {0} par celle-ci ?\n"
                        "\n"
                        "{1}\n"
                        "\n"
                        "Endroit remplacé :\n"
                        "{2}\n"
                        "\n"
                        "L’état actuel est d’abord copié dans la liste « Avant injection », vous pourrez y revenir.", game, p.name, where),
                icon="warning", default="no"):
            return
        safety = None
        if all(q.exists() for q in source_paths(source)):
            try:
                safety = make_backup(game, source, kind="inject")
            except Exception as e:
                messagebox.showerror(T("Injection annulée"),
                                     T("Impossible de garder une copie de l’état actuel : rien n’a été remplacé.\n"
                                             "\n"
                                             "{0}", e))
                return
            key = f"{game}/{safety.name}"
            self.notes[key] = T("Avant injection ({0}) {1}", next_inject_number(game), game)
            save_notes(self.notes)
            write_note_file(safety, self.notes[key])
        try:
            inject_backup(source, p)
        except Exception as e:
            self.refresh()
            back = T("\n"
                    "\n"
                    "L’état d’avant est gardé dans la liste : {0}", safety.name) if safety else ""
            messagebox.showerror(T("Injection incomplète"), f"{e}{back}")
            return
        removed = self.prune(game, self.inject_keep, auto=False, kind="inject")
        self.refresh()
        text = T("{0} : {1} injecté et vérifié à {2:%H:%M:%S}", game, p.name, datetime.now())
        if removed:
            text += T(", {0} ancienne(s) « avant injection » supprimée(s)", removed)
        self.status.config(text=text)

    def cloud_window(self):
        """Fenêtre « Cloud » : réglages (dossiers, jeux, réessais, limite de place) et aperçu de ce qu’il y a dans le cloud."""
        if self._cloud_win is not None:
            try:
                if self._cloud_win.winfo_exists():
                    self._cloud_win.deiconify()
                    self._cloud_win.lift()
                    return
            except tk.TclError:
                pass
        work = json.loads(json.dumps({k: v for k, v in self.cloud.items() if k != "pending"}))
        win = tk.Toplevel(self)
        self._cloud_win = win
        win.title(T("Cloud"))
        win.configure(bg=BG)
        win.transient(self)
        k = self.zoom / 100
        win.geometry(f"{min(int(800 * k), self.winfo_screenwidth() - 40)}x{min(int(680 * k), self.winfo_screenheight() - 80)}")
        win.minsize(560, 420)
        wl = int(680 * k)
        keep_vars = []
        max_vars = {}

        nb = ttk.Notebook(win)
        nb.pack(fill="both", expand=True, padx=12, pady=(12, 6))
        tab_set, tab_view = tk.Frame(nb), tk.Frame(nb)
        nb.add(tab_set, text=T("Réglages"))
        nb.add(tab_view, text=T("Aperçu"))

        # ----- onglet Réglages (défile s’il y a beaucoup de jeux) -----
        canvas = tk.Canvas(tab_set, bg=BG, highlightthickness=0)
        vsb = ttk.Scrollbar(tab_set, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        inner = tk.Frame(canvas, padx=12, pady=10)
        inner_id = canvas.create_window((0, 0), window=inner, anchor="nw")
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(inner_id, width=e.width))
        def wheel_on(_e=None):
            canvas.bind_all("<MouseWheel>", lambda ev: canvas.yview_scroll(int(-ev.delta / 120) or (-1 if ev.delta > 0 else 1), "units"))
            canvas.bind_all("<Button-4>", lambda ev: canvas.yview_scroll(-2, "units"))   # Linux
            canvas.bind_all("<Button-5>", lambda ev: canvas.yview_scroll(2, "units"))

        def wheel_off(_e=None):
            for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
                canvas.unbind_all(seq)

        canvas.bind("<Enter>", wheel_on)
        canvas.bind("<Leave>", wheel_off)

        def hint(parent, text, **kw):
            return tk.Label(parent, text=text, fg=MUTED, justify="left", anchor="w", wraplength=wl, **kw)

        tk.Label(inner, text=T("Dossiers cloud"), font=self.font_bold, anchor="w").pack(fill="x")
        hint(inner, T("Choisissez le dossier de Google Drive, OneDrive ou Dropbox sur votre PC (ou n’importe "
                "quel autre dossier, même sur un disque externe). L’appli y crée un dossier « Save Games "
                "Rw6 ». Retirer un dossier de cette liste ne supprime rien : les fichiers restent où ils "
                "sont. Aucun dossier = aucun envoi.")).pack(fill="x", pady=(0, 4))
        fbox = tk.Frame(inner)
        fbox.pack(fill="x")
        flist = tk.Listbox(fbox, height=4, activestyle="none", bg=PANEL, fg=FG, selectbackground=ACCENT,
                           selectforeground="#ffffff", highlightthickness=0, bd=0, exportselection=False)
        flist.pack(side="left", fill="x", expand=True)
        fbtn = tk.Frame(fbox)
        fbtn.pack(side="left", padx=(8, 0), anchor="n")
        games_box = tk.Frame(inner)

        def fill_folders():
            flist.delete(0, "end")
            for p in work["folders"]:
                flist.insert("end", p)

        def add_folder():
            p = filedialog.askdirectory(parent=win, title=T("Choisissez le dossier cloud (Google Drive, OneDrive, Dropbox…)"))
            if not p:
                return
            p = str(Path(p))
            try:
                inside = BACKUP_DIR.resolve() in (Path(p).resolve(), *Path(p).resolve().parents)
            except OSError:
                inside = False
            if inside:
                messagebox.showerror(T("Dossier refusé"), T("Choisissez un dossier hors du dossier « Sauvegardes » de l’appli."), parent=win)
                return
            if p not in work["folders"]:
                work["folders"].append(p)
                fill_folders()
                build_games()

        def remove_folder():
            sel = flist.curselection()
            if not sel:
                return
            p = work["folders"].pop(sel[0])
            for gc in work["games"].values():
                gc["folders"] = [x for x in gc["folders"] if x != p]
            fill_folders()
            build_games()

        ttk.Button(fbtn, text=T("Ajouter un dossier…"), command=add_folder).pack(fill="x")
        ttk.Button(fbtn, text=T("Retirer"), command=remove_folder).pack(fill="x", pady=(6, 0))
        games_box.pack(fill="x")

        def all_games(on):
            for name in self.games:
                gc = work["games"].setdefault(name, {"on": False, "folders": [], "max_on": True, "max": 6})
                gc["on"] = on
                if on and not gc["folders"]:
                    gc["folders"] = list(work["folders"])
            build_games()

        v_all_max = tk.StringVar(value="6")

        def apply_all_max():
            try:
                n = int(v_all_max.get())
            except ValueError:
                n = 0
            if not 1 <= n <= 999:
                messagebox.showerror(T("Valeur invalide"), T("Entrez un nombre de 1 à 999."), parent=win)
                return
            for name in self.games:
                work["games"].setdefault(name, {"on": False, "folders": [], "max_on": True, "max": 6})["max"] = n
            build_games()

        def all_max_on(flag):
            for name in self.games:
                work["games"].setdefault(name, {"on": False, "folders": [], "max_on": True, "max": 6})["max_on"] = flag
            build_games()

        def build_games():
            for w in games_box.winfo_children():
                w.destroy()
            keep_vars.clear()
            max_vars.clear()
            tk.Label(games_box, text=T("Réglages par jeu"), font=self.font_bold, anchor="w").pack(fill="x", pady=(14, 0))
            hint(games_box, T("Seules les sauvegardes AUTOMATIQUES partent toutes seules. Pour les manuelles : "
                    "sélectionnez-les dans la liste (Ctrl + clic), puis « Envoyer vers le cloud ». Tout est "
                    "désactivé par défaut.")).pack(fill="x", pady=(0, 4))
            if not self.games:
                hint(games_box, T("Aucun jeu pour l’instant.")).pack(fill="x")
            else:
                allrow = tk.Frame(games_box)
                allrow.pack(fill="x", pady=(0, 4))
                ttk.Button(allrow, text=T("Cloud pour tous les jeux"),
                           command=lambda: win.after_idle(lambda: all_games(True))).pack(side="left")
                ttk.Button(allrow, text=T("Aucun jeu"), command=lambda: win.after_idle(lambda: all_games(False))).pack(
                    side="left", padx=6)
                tk.Label(allrow, text=T("(« pour tous » coche aussi tous les dossiers cloud des jeux qui n’en ont aucun)"),
                         fg=MUTED).pack(side="left")
                maxrow = tk.Frame(games_box)
                maxrow.pack(fill="x", pady=(0, 2))
                tk.Label(maxrow, text=T("Garder au maximum pour tous :")).pack(side="left")
                ttk.Spinbox(maxrow, from_=1, to=999, width=5, textvariable=v_all_max).pack(side="left", padx=6)
                ttk.Button(maxrow, text=T("Appliquer le nombre à tous"),
                           command=lambda: win.after_idle(apply_all_max)).pack(side="left")
                chkrow = tk.Frame(games_box)
                chkrow.pack(fill="x", pady=(0, 4))
                ttk.Button(chkrow, text=T("« Garder au maximum » : cocher pour tous"),
                           command=lambda: win.after_idle(lambda: all_max_on(True))).pack(side="left")
                ttk.Button(chkrow, text=T("Décocher pour tous"),
                           command=lambda: win.after_idle(lambda: all_max_on(False))).pack(side="left", padx=6)
                tk.Label(chkrow, text=T("(« Appliquer le nombre » ne change pas les cases cochées)"), fg=MUTED).pack(side="left")
            for name in self.games:
                gc = work["games"].setdefault(name, {"on": False, "folders": [], "max_on": True, "max": 6})
                box = tk.LabelFrame(games_box, text=name, padx=8, pady=6, bg=BG, fg=FG, highlightbackground=LINE)
                box.pack(fill="x", pady=3)
                on = tk.BooleanVar(value=gc["on"])
                on.trace_add("write", lambda *_, gc=gc, v=on: gc.__setitem__("on", bool(v.get())))
                keep_vars.append(on)
                ttk.Checkbutton(box, text=T("Envoyer les sauvegardes automatiques de ce jeu vers le cloud"), variable=on).pack(anchor="w")
                if work["folders"]:
                    tk.Label(box, text=T("Envoyer vers (cochez les dossiers cloud où ce jeu doit être copié) :"),
                             fg=MUTED).pack(anchor="w", padx=(22, 0), pady=(4, 0))
                    for folder in work["folders"]:
                        fv = tk.BooleanVar(value=folder in gc["folders"])

                        def set_folder(*_, gc=gc, folder=folder, v=fv):
                            has = folder in gc["folders"]
                            if v.get() and not has:
                                gc["folders"].append(folder)
                            elif not v.get() and has:
                                gc["folders"].remove(folder)
                        fv.trace_add("write", set_folder)
                        keep_vars.append(fv)
                        ttk.Checkbutton(box, text=folder, variable=fv).pack(anchor="w", padx=(22, 0))
                else:
                    hint(box, T("Ajoutez d’abord un dossier cloud ci-dessus.")).pack(anchor="w", padx=(22, 0))
                row = tk.Frame(box)
                row.pack(fill="x", pady=(4, 0))
                mon = tk.BooleanVar(value=gc["max_on"])
                mon.trace_add("write", lambda *_, gc=gc, v=mon: gc.__setitem__("max_on", bool(v.get())))
                mv = tk.StringVar(value=str(gc["max"]))

                def set_max(*_, gc=gc, v=mv):
                    try:
                        n = int(v.get())
                    except ValueError:
                        return
                    if 1 <= n <= 999:
                        gc["max"] = n
                mv.trace_add("write", set_max)
                keep_vars.extend((mon, mv))
                max_vars[name] = mv
                ttk.Checkbutton(row, text=T("Garder au maximum"), variable=mon).pack(side="left")
                ttk.Spinbox(row, from_=1, to=999, width=5, textvariable=mv).pack(side="left", padx=6)
                tk.Label(row, text=T("sauvegardes dans le cloud (manuelles et automatiques), hors favoris ★"), fg=MUTED).pack(side="left")

        v_every, v_tries = tk.StringVar(value=str(work["retry_every"])), tk.StringVar(value=str(work["tries"]))
        v_unit = tk.StringVar(value=T(work["retry_unit"]))
        v_limit_on, v_gb = tk.BooleanVar(value=work["limit_on"]), tk.StringVar(value=f"{work['limit_gb']:g}")
        v_over = tk.StringVar(value=work["over"])
        keep_vars.extend((v_every, v_tries, v_unit, v_limit_on, v_gb, v_over))
        rest = tk.Frame(inner)
        rest.pack(fill="x")
        tk.Label(rest, text=T("Réessayer"), font=self.font_bold, anchor="w").pack(fill="x", pady=(14, 0))
        rrow = tk.Frame(rest)
        rrow.pack(fill="x", pady=3)
        tk.Label(rrow, text=T("Réessayer toutes les")).pack(side="left")
        ttk.Spinbox(rrow, from_=1, to=9999, width=5, textvariable=v_every).pack(side="left", padx=6)
        ttk.Combobox(rrow, values=tuple(T(u) for u in CLOUD_UNITS), textvariable=v_unit, state="readonly", width=9).pack(side="left")
        tk.Label(rrow, text=T(", au maximum")).pack(side="left")
        ttk.Spinbox(rrow, from_=1, to=99, width=4, textvariable=v_tries).pack(side="left", padx=6)
        tk.Label(rrow, text=T("essais en tout")).pack(side="left")
        hint(rest, T("Sert quand le dossier cloud est introuvable (Drive pas lancé, disque débranché). Sans "
                "internet, Drive garde le fichier et l’envoie tout seul plus tard : l’appli n’a rien à "
                "réessayer. Après le dernier essai raté, un message s’affiche (c’est le seul cas).")).pack(fill="x")
        tk.Label(rest, text=T("Place utilisée"), font=self.font_bold, anchor="w").pack(fill="x", pady=(14, 0))
        lrow = tk.Frame(rest)
        lrow.pack(fill="x", pady=3)
        ttk.Checkbutton(lrow, text=T("Limiter la place prise par l’appli à"), variable=v_limit_on).pack(side="left")
        ttk.Spinbox(lrow, from_=0.1, to=100000, increment=0.5, width=7, textvariable=v_gb).pack(side="left", padx=6)
        tk.Label(lrow, text=T("Go, dans chaque dossier cloud")).pack(side="left")
        ttk.Radiobutton(rest, text=T("Si la limite est atteinte : supprimer les plus anciennes sauvegardes du cloud (hors "
                "favoris ★)"),
                        variable=v_over, value="delete").pack(anchor="w", padx=(22, 0))
        ttk.Radiobutton(rest, text=T("Si la limite est atteinte : arrêter d’envoyer et me prévenir"),
                        variable=v_over, value="stop").pack(anchor="w", padx=(22, 0))
        hint(rest, T("L’appli ne mesure que son propre dossier. Elle ne voit pas le reste de votre Drive "
                "(Gmail, Photos…) : les 15 Go gratuits de Google sont partagés.")).pack(fill="x", pady=(4, 0))
        warn_text = "\n".join(f"{f} : {w}" for f in self.cloud["folders"] for w in [self.cloud_warning(f)] if w)
        tk.Label(rest, text=warn_text, fg=ERR, justify="left", anchor="w", wraplength=wl).pack(fill="x", pady=(4, 0))

        # ----- onglet Aperçu -----
        st = ttk.Style(self)
        st.configure("Cloud.Horizontal.TProgressbar", background=ACCENT, troughcolor=PANEL, bordercolor=LINE,
                     lightcolor=ACCENT, darkcolor=ACCENT)
        st.configure("CloudWarn.Horizontal.TProgressbar", background=ERR, troughcolor=PANEL, bordercolor=LINE,
                     lightcolor=ERR, darkcolor=ERR)
        head = tk.Frame(tab_view, padx=12, pady=10)
        head.pack(fill="x")
        hint(head, T("Ce que l’appli voit dans vos dossiers cloud, sur ce PC. Elle ne peut pas savoir si Drive "
                "a fini d’envoyer en ligne. Les réglages non enregistrés n’y sont pas.")).pack(side="left", fill="x", expand=True)
        gauges = tk.Frame(tab_view, padx=12)
        gauges.pack(fill="x")
        tbox = tk.Frame(tab_view, padx=12, pady=6)
        tbox.pack(fill="both", expand=True)
        tree = ttk.Treeview(tbox, columns=("kind", "date", "size", "note"), show="tree headings", selectmode="browse")
        for col, label, w in (("#0", T("Dossier cloud / jeu / sauvegarde"), 300), ("kind", T("Type"), 80), ("date", T("Date"), 120),
                              ("size", T("Taille"), 80), ("note", T("Note"), 160)):
            tree.heading(col, text=label)
            tree.column(col, width=int(w * k), stretch=col in ("#0", "note"))
        tsb = ttk.Scrollbar(tbox, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=tsb.set)
        tree.pack(side="left", fill="both", expand=True)
        tsb.pack(side="right", fill="y")

        def fill_preview():
            for w in gauges.winfo_children():
                w.destroy()
            tree.delete(*tree.get_children())
            folders = self.cloud["folders"]
            if not folders:
                hint(gauges, T("Aucun dossier cloud enregistré. Ajoutez-en un dans « Réglages », puis cliquez sur « "
                        "Enregistrer ».")).pack(fill="x")
                return
            limit = self.cloud_limit_bytes()
            for folder in folders:
                gf = tk.Frame(gauges)
                gf.pack(fill="x", pady=(0, 8))
                line = tk.Frame(gf)
                line.pack(fill="x")
                tk.Label(line, text=folder, anchor="w").pack(side="left")
                root = cloud_root(folder)
                ttk.Button(line, text=T("Ouvrir"), command=lambda r=root, f=folder: open_folder(r if r.is_dir() else f)).pack(side="right")
                if not Path(folder).is_dir():
                    tk.Label(gf, text=T("⚠ Dossier introuvable (Drive pas lancé ? disque débranché ?)"), fg=ERR, anchor="w").pack(fill="x")
                    tree.insert("", "end", text=T("{0} (introuvable)", folder))
                    continue
                rows = list_backups(None, root)
                sizes = {str(b): size_of(b) for _g, b in rows}
                used = sum(sizes.values())
                if limit:
                    ratio = used / limit
                    ttk.Progressbar(gf, maximum=limit, value=min(used, limit), mode="determinate",
                                    style="CloudWarn.Horizontal.TProgressbar" if ratio >= 0.9 else "Cloud.Horizontal.TProgressbar"
                                    ).pack(fill="x", pady=(3, 0))
                    tk.Label(gf, text=T("{0} utilisés sur {1} ({2:.0f} %)", human(used), human(limit), ratio * 100), fg=MUTED, anchor="w").pack(fill="x")
                else:
                    tk.Label(gf, text=T("{0} utilisés (aucune limite fixée)", human(used)), fg=MUTED, anchor="w").pack(fill="x")
                warn = self.cloud_warning(folder)
                if warn:
                    tk.Label(gf, text=warn, fg=ERR, anchor="w", wraplength=wl, justify="left").pack(fill="x")
                node = tree.insert("", "end", text=folder, values=("", "", human(used), ""), open=True)
                by_game = {}
                for g, b in rows:
                    by_game.setdefault(g, []).append(b)
                for g in sorted(by_game):
                    bs = by_game[g]
                    kinds = [backup_kind(b) for b in bs]
                    extra_inj = T(" · {0} av. inj.", kinds.count('inject')) if "inject" in kinds else ""
                    gn = tree.insert(node, "end", text=T("{0} · {1} manu · {2} auto{3}", g, kinds.count('manual'), kinds.count('auto'), extra_inj),
                                     values=("", "", human(sum(sizes[str(b)] for b in bs)), ""), open=len(by_game) == 1)
                    for b in bs:
                        d = parse_stamp(b.name)
                        key = f"{g}/{b.name}"
                        tree.insert(gn, "end", text=("★ " if key in self.favorites else "") + b.name,
                                    values=({"auto": "auto", "inject": T("av. inj."), "manual": T("manuelle")}[backup_kind(b)],
                                            T("{0:%d/%m/%Y %H:%M}", d) if d else "",
                                            human(sizes[str(b)]), self.notes.get(key, "")))

        ttk.Button(head, text=T("Actualiser"), command=fill_preview).pack(side="right", padx=(8, 0))
        nb.bind("<<NotebookTabChanged>>", lambda e: fill_preview() if nb.index("current") == 1 else None)

        # ----- boutons du bas -----
        def close():
            try:
                for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
                    canvas.unbind_all(seq)
            except tk.TclError:
                pass
            self._cloud_win = None
            win.destroy()

        def number(var, low, high, kind=int):
            try:
                n = kind(var.get().replace(",", ".")) if kind is float else kind(var.get())
            except ValueError:
                return None
            return n if low <= n <= high else None

        def save():
            every, tries, gb = number(v_every, 1, 9999), number(v_tries, 1, 99), number(v_gb, 0.1, 100000, float)
            if None in (every, tries, gb):
                messagebox.showerror(T("Valeur invalide"), T("Vérifiez les nombres : délai 1 à 9999, essais 1 à 99, limite de place 0,1 à 100000 Go."), parent=win)
                return
            for name, mv in max_vars.items():
                if number(mv, 1, 999) is None:
                    messagebox.showerror(T("Valeur invalide"), T("Maximum de sauvegardes pour {0} : un nombre de 1 à 999.", name), parent=win)
                    return
            work.update({"retry_every": every, "retry_unit": unit_from_label(v_unit.get(), CLOUD_UNITS, "minutes"),
                         "tries": tries, "limit_on": bool(v_limit_on.get()), "limit_gb": gb,
                         "over": v_over.get() if v_over.get() in ("stop", "delete") else "delete"})
            self.cloud.update(work)
            self.cloud["pending"] = [p for p in self.cloud["pending"] if p["folder"] in self.cloud["folders"]]
            save_cloud(self.cloud)
            self.cloud_alerts.clear()
            close()
            self.show_card()
            self.status.config(text=T("Cloud : réglages enregistrés"))

        bottom = tk.Frame(win)
        bottom.pack(fill="x", padx=12, pady=(0, 12))
        ttk.Button(bottom, text=T("Fermer"), command=close).pack(side="right", padx=(6, 0))
        ttk.Button(bottom, text=T("Enregistrer"), command=save).pack(side="right")
        win.protocol("WM_DELETE_WINDOW", close)
        fill_folders()
        build_games()
        self.dark_titlebar(win)

    def select_everything(self):
        """Ctrl+A : toutes les sauvegardes, manuelles et automatiques."""
        for t in self.all_trees():
            t.selection_set(t.get_children())

    def selected_all(self, quiet=False):
        """Toutes les sauvegardes sélectionnées, dans les deux listes (liste de chemins)."""
        sel = tuple(i for t in self.all_trees() for i in t.selection())
        if not sel and not quiet:
            messagebox.showinfo(T("Sélection"), T("Cliquez d’abord sur une sauvegarde dans la liste."))
        return [Path(i) for i in sel]

    def selected(self, quiet=False):
        """Une seule sauvegarde : pour les actions qui n’ont pas de sens sur plusieurs."""
        items = self.selected_all(quiet=quiet)
        if len(items) > 1:
            if not quiet:
                messagebox.showinfo(T("Sélection"), T("Choisissez une seule sauvegarde pour cette action."))
            return None
        return items[0] if items else None

    def on_drag_init(self, event):
        if self._lasso_active:
            return "break"
        items = self.selected_all(quiet=True)
        if not items:
            return "break"
        return (COPY, DND_FILES, tuple(str(p) for p in items))

    def edit_note(self):
        p = self.selected()
        if not p:
            return
        key = f"{game_of(p)}/{p.name}"
        new = simpledialog.askstring(T("Note"), T("Note pour la sauvegarde {0} :\n"
                "(laisser vide pour l’effacer)", p.name),
                                     initialvalue=self.notes.get(key, ""), parent=self)
        if new is None:
            return
        new = new.strip()
        if new:
            self.notes[key] = new
        else:
            self.notes.pop(key, None)
        save_notes(self.notes)
        write_note_file(p, new)  # Note.txt voyage avec le dossier (glisser-déposer, copie)
        for folder in self.cloud["folders"]:   # et avec la copie déjà envoyée dans le cloud
            target = cloud_target(folder, p)
            if target.is_dir():
                write_note_file(target, new)
        self.refresh()

    def show_menu(self, tree, event):
        """Clic droit sur une sauvegarde : les mêmes actions que les boutons du bas."""
        iid = tree.identify_row(event.y)
        if not iid:
            return
        if iid not in tree.selection():  # comme l’Explorateur : on sélectionne la ligne cliquée
            self.activate(tree)
            tree.selection_set(iid)
        else:
            self.activate(tree, keep=True)
        items = [Path(i) for t in self.all_trees() for i in t.selection()]
        keys = {f"{game_of(p)}/{p.name}" for p in items}
        one = "normal" if len(items) == 1 else "disabled"  # ces deux actions n’ont de sens que sur une seule
        menu = tk.Menu(self, tearoff=0, bg=PANEL, fg=FG, activebackground=ACCENT,
                       activeforeground="#ffffff", disabledforeground=MUTED, bd=0, relief="flat")
        menu.add_command(label=T("Copier vers…"), command=self.copy_selected)
        menu.add_command(label=T("Ouvrir le dossier"), command=self.open_selected, state=one)
        menu.add_command(label=T("Note…"), command=self.edit_note, state=one)
        menu.add_command(label=T("Envoyer vers le cloud"), command=self.cloud_send_selected)
        menu.add_command(label=T("Injecter dans le jeu…"), command=self.inject_selected, state=one)
        menu.add_command(label=T("Retirer des favoris") if keys <= self.favorites else T("★ Ajouter aux favoris"),
                         command=self.toggle_favorite)
        menu.add_separator()
        menu.add_command(label=T("Supprimer"), command=self.delete_selected)
        try:
            menu.tk_popup(event.x_root, event.y_root)
        finally:
            menu.grab_release()

    def toggle_favorite(self):
        items = self.selected_all()
        if not items:
            return
        keys = {f"{game_of(p)}/{p.name}" for p in items}
        if keys <= self.favorites:
            self.favorites -= keys
            text = T("{0} sauvegarde(s) retirée(s) des favoris", len(keys))
        else:
            self.favorites |= keys
            text = T("{0} sauvegarde(s) protégée(s) ★", len(keys))
        save_favorites(self.favorites)
        self.refresh()
        self.status.config(text=text)

    def open_selected(self):
        p = self.selected()
        if p:
            open_folder(p)

    def copy_selected(self):
        items = self.selected_all()
        if not items:
            return
        target = filedialog.askdirectory(title=T("Copier la sauvegarde vers…") if len(items) == 1
                                         else T("Copier les {0} sauvegardes vers…", len(items)))
        if not target:
            return
        done, errors = 0, []
        for p in items:
            dest = Path(target) / p.name
            try:
                shutil.copytree(p, dest)
                problems = verify_copy(p, dest)
                if problems:
                    shutil.rmtree(dest, ignore_errors=True)
                    errors.append(T("{0} : copie différente de l’original, supprimée ({1})", p.name, problems[0]))
                else:
                    done += 1
            except Exception as e:
                errors.append(f"{p.name} : {e}")
        if errors:
            messagebox.showerror(T("Copie incomplète"), T("{0} copiée(s), {1} en erreur :\n"
                    "\n", done, len(errors)) + "\n".join(errors[:6]))
        else:
            self.status.config(text=T("{0} copiée(s) et vérifiée(s) vers {1}", done, target))

    def delete_selected(self):
        items = self.selected_all()
        if not items:
            return
        if len(items) == 1:
            question = T("Supprimer définitivement cette sauvegarde ?\n"
                    "{0} – {1}", game_of(items[0]), items[0].name)
        else:
            names = "\n".join(f"{game_of(p)} – {p.name}" for p in items[:8])
            more = T("\n"
                    "… et {0} autres", len(items) - 8) if len(items) > 8 else ""
            question = T("Supprimer définitivement ces {0} sauvegardes ?\n"
                    "\n"
                    "{1}{2}", len(items), names, more)
        if not messagebox.askyesno(T("Supprimer"), question):
            return
        favs = [p for p in items if f"{game_of(p)}/{p.name}" in self.favorites]
        if favs:
            names = "\n".join(f"★ {game_of(p)} – {p.name}" for p in favs[:6])
            more = T("\n"
                    "… et {0} autres", len(favs) - 6) if len(favs) > 6 else ""
            delete_favs = messagebox.askyesno(
                T("Favoris protégés"),
                T("{0} favori(s) dans la sélection :\n"
                        "\n"
                        "{1}{2}\n"
                        "\n"
                        "Les supprimer aussi ?\n"
                        "\n"
                        "Oui : tout est supprimé, favoris compris.\n"
                        "Non : les favoris sont gardés, le reste est supprimé.", len(favs), names, more),
                icon="warning", default="no")
            if not delete_favs:
                items = [p for p in items if p not in favs]
                if not items:
                    return
        failed = []
        for p in items:
            shutil.rmtree(p, ignore_errors=True)
            if p.exists():
                failed.append(p.name)
            else:
                key = f"{game_of(p)}/{p.name}"
                if self.notes.pop(key, None) is not None:
                    save_notes(self.notes)
                if key in self.favorites:
                    self.favorites.discard(key)
                    save_favorites(self.favorites)
        self.refresh()
        if failed:
            messagebox.showwarning(T("Suppression incomplète"),
                                   T("Impossible de supprimer entièrement :\n") + "\n".join(failed[:8]) +
                                   T("\n"
                                           "\n"
                                           "Un fichier est peut-être ouvert ailleurs (Explorateur, jeu…)."))
        else:
            self.status.config(text=T("{0} sauvegarde(s) supprimée(s)", len(items)))


# ----- textes anglais (la clé est le texte français d’origine) -----
TRANSLATIONS["en"] = {
    "Jeu":
        "Game",
    "Date":
        "Date",
    "Taille":
        "Size",
    "Note":
        "Note",
    "Chemin des sauvegardes du jeu à définir":
        "Game save path not set yet",
    "{0} fichiers dans {1} : {2}{3}":
        "{0} files in {1}: {2}{3}",
    "lecture impossible ({0})":
        "unreadable ({0})",
    "fichier manquant dans la copie : {0}":
        "file missing from the copy: {0}",
    "contenu différent : {0}":
        "different content: {0}",
    "lecture impossible : {0} ({1})":
        "unreadable: {0} ({1})",
    "fichier en trop dans la copie : {0}":
        "extra file in the copy: {0}",
    "Le chemin n’existe pas :\n":
        "The path does not exist:\n",
    "Deux fichiers portent le même nom : choisissez des fichiers d’un seul dossier.":
        "Two files have the same name: choose files from a single folder.",
    "Une sauvegarde existe déjà pour cette seconde, réessayez.":
        "A backup already exists for this second, please try again.",
    "La copie n’est pas identique à l’original, elle a été supprimée.\nLe jeu ou l’émulateur est peut-être en train d’écrire sa sauvegarde : fermez-le et réessayez.\n\n":
        "The copy is not identical to the original and was deleted.\nThe game or emulator may be writing its save right now: close it and try again.\n\n",
    "Dossier cloud introuvable : {0}":
        "Cloud folder not found: {0}",
    "La copie vers le cloud n’est pas identique, elle a été supprimée : ":
        "The copy sent to the cloud is not identical and was deleted: ",
    "La sauvegarde choisie ne contient aucun fichier.":
        "The chosen backup contains no files.",
    "Fichier absent de la sauvegarde : ":
        "File missing from the backup: ",
    "Le jeu pointe vers un fichier, mais cette sauvegarde contient un dossier.":
        "The game points to a file, but this backup contains a folder.",
    "L’injection est incomplète : ":
        "The injection is incomplete: ",
    "« {0} » existe déjà dans le nouveau dossier":
        "“{0}” already exists in the new folder",
    "Ajouter un jeu":
        "Add a game",
    "Cloud…":
        "Cloud…",
    "Avant injection/manuel-auto":
        "Before injection/manual-auto",
    "Pour tous…":
        "For all…",
    "Lancer avec Windows":
        "Start with Windows",
    "Masquer":
        "Hide",
    "Taille du texte":
        "Text size",
    "Ouvrir":
        "Open",
    "Changer…":
        "Change…",
    "Dossier des sauvegardes :":
        "Backups folder:",
    "Jeux":
        "Games",
    "Injecter la sauvegarde":
        "Inject backup",
    "Envoyer vers le cloud":
        "Send to cloud",
    "Injecter : remet la sauvegarde choisie dans le jeu.":
        "Inject: puts the selected backup back into the game.",
    "Copier vers…":
        "Copy to…",
    "Ouvrir le dossier":
        "Open folder",
    "Note…":
        "Note…",
    "★ Favori":
        "★ Favorite",
    "Supprimer":
        "Delete",
    "Glissez une sauvegarde de la liste vers un dossier pour la copier.":
        "Drag a backup from the list onto a folder to copy it.",
    "Glisser-déposer : installez-le avec  py -m pip install tkinterdnd2  puis relancez.":
        "Drag and drop: install it with  py -m pip install tkinterdnd2  then restart.",
    "← Retour":
        "← Back",
    "L’état actuel du jeu est copié ici avant chaque injection : vous pouvez toujours revenir en arrière.":
        "The game's current state is copied here before each injection: you can always go back.",
    "Garder au maximum":
        "Keep at most",
    "par jeu, hors favoris ★ (les plus anciennes en trop sont supprimées à la prochaine injection)":
        "per game, excluding favorites ★ (extra older ones are deleted at the next injection)",
    "Sauvegarde automatique : désactivée":
        "Automatic backup: off",
    "⚠ Sauvegarde automatique : indiquez le programme du jeu, sinon rien n’est sauvegardé":
        "⚠ Automatic backup: set the game's program, otherwise nothing is backed up",
    "toutes les {0} {1}":
        "every {0} {1}",
    "chaque jour":
        "every day",
    "le ":
        "on ",
    "à la fin d’une session de {0}":
        "at the end of a {0} session",
    ", garde les {0} dernières":
        ", keeps the last {0}",
    "Sauvegarde automatique : {0}{1}":
        "Automatic backup: {0}{1}",
    "Sauvegarde automatique : {0}":
        "Automatic backup: {0}",
    "Cochez un ou plusieurs modes (ils marchent ensemble). Aucun coché = désactivée.":
        "Tick one or more modes (they work together). None ticked = off.",
    "Toutes les":
        "Every",
    "(seulement si la sauvegarde a changé)":
        "(only if the save has changed)",
    "À heure fixe":
        "At a fixed time",
    "À la fin d’une session de jeu":
        "At the end of a game session",
    "Programme du jeu :":
        "Game program:",
    "Choisissez le programme du jeu (ou de l’émulateur)":
        "Choose the game's program (or the emulator)",
    "Programmes":
        "Programs",
    "Tous les fichiers":
        "All files",
    "Parcourir…":
        "Browse…",
    "Choisir dans la liste…":
        "Pick from the list…",
    "sauvegardes automatiques, hors favoris ★":
        "automatic backups, excluding favorites ★",
    "Le programme du jeu est obligatoire : c’est lui qui permet de ne JAMAIS sauvegarder pendant une partie, ce qui pourrait abîmer la sauvegarde. Pour un jeu sur émulateur, c’est l’émulateur. « Parcourir… » ouvre l’explorateur de fichiers pour choisir le .exe. Si le jeu tourne à l’heure prévue, la copie se fait dès qu’il est fermé. L’appli doit rester ouverte (réduite ou masquée, c’est bon).":
        "The game's program is required: it is what lets the app NEVER back up while you are playing, which could corrupt the save. For an emulated game, it is the emulator. “Browse…” opens the file explorer to pick the program. If the game is running at the scheduled time, the copy is made as soon as it is closed. The app must stay open (minimized or hidden is fine).",
    "Valeur invalide":
        "Invalid value",
    "Vérifiez les nombres : intervalle 1 à 999, maximum 1 à 99, heure 0 à 23, minutes 0 à 59.":
        "Check the numbers: interval 1 to 999, maximum 1 to 99, hour 0 to 23, minutes 0 to 59.",
    "Jours manquants":
        "Missing days",
    "Cochez au moins un jour.":
        "Tick at least one day.",
    "Programme manquant":
        "Missing program",
    "Indiquez le programme du jeu (par exemple l’émulateur) : sans lui, l’appli ne peut pas savoir si le jeu tourne, et sauvegarder pendant une partie risque d’abîmer la sauvegarde.":
        "Enter the game's program (for example the emulator): without it, the app cannot tell whether the game is running, and backing up during a game may corrupt the save.",
    "Annuler":
        "Cancel",
    "OK":
        "OK",
    "Liste indisponible":
        "List unavailable",
    "Programmes en cours":
        "Running programs",
    "Lancez le jeu, puis choisissez son programme dans la liste.":
        "Start the game, then choose its program in the list.",
    "Actualiser":
        "Refresh",
    "Choisir":
        "Choose",
    "fin de session":
        "end of session",
    "Auto : {0} inchangé, rien à sauvegarder ({1:%H:%M})":
        "Auto: {0} unchanged, nothing to back up ({1:%H:%M})",
    "Auto : échec pour {0}, nouvel essai dans 10 min (voir erreurs.log)":
        "Auto: failed for {0}, trying again in 10 min (see erreurs.log)",
    "Auto : {0} sauvegardé et vérifié à {1:%H:%M} ({2})":
        "Auto: {0} backed up and verified at {1:%H:%M} ({2})",
    ", {0} ancienne(s) supprimée(s)":
        ", {0} old one(s) deleted",
    "{0} jeu(x) sauvegardé(s) et vérifié(s)":
        "{0} game(s) backed up and verified",
    ", sans chemin : {0}":
        ", no path: {0}",
    "Sauvegarde incomplète":
        "Incomplete backup",
    "Erreur":
        "Error",
    "{0}\n\nDétails dans le fichier erreurs.log, à côté de l’appli.":
        "{0}\n\nDetails in the erreurs.log file, next to the app.",
    "Pas d’icône près de l’horloge":
        "No tray icon",
    "La croix devrait masquer l’appli, mais le module « pystray » n’est pas installé.\n\nPour l’installer (une seule fois), ouvrez l’invite de commandes Windows et tapez :\npy -m pip install pystray\npuis relancez l’appli.\n\nFermer l’appli maintenant ?":
        "The close button should hide the app, but the “pystray” module is not installed.\n\nTo install it (only once), open the Windows command prompt and type:\npy -m pip install pystray\nthen restart the app.\n\nClose the app now?",
    "Avant injection : entrez un nombre de 1 à 99":
        "Before injection: enter a number from 1 to 99",
    "Réglage impossible ({0})":
        "Could not apply the setting ({0})",
    "Avant injection : {0} gardée(s) par jeu (appliqué à la prochaine injection)":
        "Before injection: {0} kept per game (applied at the next injection)",
    "Sauvegardes manuelles ({0})":
        "Manual backups ({0})",
    "Sauvegardes automatiques ({0})":
        "Automatic backups ({0})",
    "Avant injection ({0})":
        "Before injection ({0})",
    "Démarrage avec Windows":
        "Startup with Windows",
    "Impossible de modifier le démarrage automatique.":
        "Could not change the automatic startup.",
    "L’appli se lancera avec Windows (réduite).":
        "The app will start with Windows (minimized).",
    "L’appli ne se lancera plus avec Windows.":
        "The app will no longer start with Windows.",
    "Ouvrir Save Games Rw6":
        "Open Save Games Rw6",
    "Quitter":
        "Quit",
    "Masquer la fenêtre":
        "Hide the window",
    "La fenêtre va disparaître, mais l’appli continue de tourner (les sauvegardes automatiques aussi).\n\nPour la rouvrir : relancez l’appli (raccourci ou double-clic sur le fichier), la fenêtre déjà ouverte réapparaîtra.\nPour une icône près de l’horloge : py -m pip install pystray\n\nMasquer maintenant ?":
        "The window will disappear, but the app keeps running (automatic backups too).\n\nTo reopen it: launch the app again (shortcut or double-click on the file), the window that is already open will reappear.\nFor a tray icon: py -m pip install pystray\n\nHide now?",
    "Tous":
        "All",
    "{0} · {1} manu · {2} auto · {3} inj · {4} ★":
        "{0} · {1} manual · {2} auto · {3} inj · {4} ★",
    "Aucun jeu pour l’instant. Cliquez sur « Ajouter un jeu » pour commencer.":
        "No games yet. Click “Add a game” to get started.",
    "Tous les jeux : {0} sauvegarde(s)":
        "All games: {0} backup(s)",
    "Tout sauvegarder":
        "Back up everything",
    "{0} manuelle(s), {1} automatique(s), {2} avant injection, dernière le {3}":
        "{0} manual, {1} automatic, {2} before injection, last on {3}",
    "Aucune sauvegarde pour l’instant":
        "No backups yet",
    "Accéder au dossier":
        "Go to folder",
    "Sauvegarder {0}":
        "Back up {0}",
    "Dossier…":
        "Folder…",
    "Fichiers…":
        "Files…",
    "Renommer":
        "Rename",
    "sauvegardes manuelles, hors favoris ★ (les plus anciennes en trop sont supprimées)":
        "manual backups, excluding favorites ★ (extra older ones are deleted)",
    "Automatique…":
        "Automatic…",
    "Dossier de sauvegarde de {0}":
        "Backup folder for {0}",
    "Fichiers de sauvegarde de {0} (Ctrl ou Maj pour en choisir plusieurs)":
        "Backup files for {0} (Ctrl or Shift to pick several)",
    "Noms identiques":
        "Identical names",
    "Nom du jeu :":
        "Game name:",
    "Nom invalide":
        "Invalid name",
    "Évitez les caractères \\ / : * ? \" < > | et un point ou espace à la fin. Le nom « Auto » est réservé.":
        "Avoid the characters \\ / : * ? \" < > | and a trailing dot or space. The name “Auto” is reserved.",
    "Déjà présent":
        "Already exists",
    "{0} existe déjà.":
        "{0} already exists.",
    "Nouveau nom pour {0} :":
        "New name for {0}:",
    "Renommage impossible":
        "Rename failed",
    "Un dossier « {0} » existe déjà dans Sauvegardes.":
        "A folder “{0}” already exists in Sauvegardes.",
    "{0}\n\nFermez l’Explorateur s’il est ouvert dans ce dossier.":
        "{0}\n\nClose the file explorer if it is open in this folder.",
    "{0} renommé en {1}":
        "{0} renamed to {1}",
    "Chemin manquant":
        "Missing path",
    "Définissez d’abord le chemin de {0} (bouton Dossier… ou Fichiers…).":
        "First set the path for {0} (Folder… or Files… button).",
    "Sauvegarde impossible":
        "Backup failed",
    "{0} sauvegardé et vérifié à {1:%H:%M:%S}":
        "{0} backed up and verified at {1:%H:%M:%S}",
    "Limite de sauvegardes":
        "Backup limit",
    "Il y a déjà {0} sauvegarde(s) de {1}.\n\nAvec un maximum de {2}, la prochaine sauvegarde supprimera automatiquement les {3} plus ancienne(s).\n\nActiver cette limite ?":
        "There are already {0} backup(s) of {1}.\n\nWith a maximum of {2}, the next backup will automatically delete the {3} oldest one(s).\n\nEnable this limit?",
    "maximum {0} sauvegardes":
        "maximum {0} backups",
    "pas de limite":
        "no limit",
    "limite de {0}":
        "limit of {0}",
    "limite selon le jeu":
        "limit depends on the game",
    "Limite pour tous":
        "Limit for all",
    "Avec ce réglage, la prochaine sauvegarde supprimera automatiquement les plus anciennes (hors favoris ★) de :\n":
        "With this setting, the next backup will automatically delete the oldest ones (excluding favorites ★) of:\n",
    "\n\nContinuer ?":
        "\n\nContinue?",
    "Sauvegardes {0} : maximum {1} pour tous les jeux (cases inchangées)":
        "{0} backups: maximum {1} for all games (boxes unchanged)",
    "décochée":
        "unticked",
    "cochée":
        "ticked",
    "Sauvegardes {0} : limite {1} pour tous les jeux":
        "{0} backups: limit {1} for all games",
    "Limites pour tous les jeux":
        "Limits for all games",
    "Entrez un nombre de 1 à 99.":
        "Enter a number from 1 to 99.",
    "Appliquer le nombre à tous":
        "Apply the number to all",
    "Cocher pour tous":
        "Tick for all",
    "Décocher pour tous":
        "Untick for all",
    "Sauvegardes manuelles":
        "Manual backups",
    "Sauvegardes automatiques":
        "Automatic backups",
    "Garder les":
        "Keep the",
    "« Appliquer le nombre » change seulement le chiffre, pas la case cochée. Les favoris ★ ne comptent jamais.":
        "“Apply the number” only changes the number, not the checkbox. Favorites ★ never count.",
    "Fermer":
        "Close",
    "   ⚠ introuvable (disque débranché ?)":
        "   ⚠ not found (drive unplugged?)",
    "dossier introuvable":
        "folder not found",
    "Impossible d’ouvrir le dossier des sauvegardes ({0})":
        "Could not open the backups folder ({0})",
    "chemin introuvable":
        "path not found",
    "Impossible d’ouvrir le dossier de {0} ({1})":
        "Could not open the folder of {0} ({1})",
    "Choisissez le dossier où ranger toutes les sauvegardes":
        "Choose the folder where all backups will be stored",
    "Dossier refusé":
        "Folder refused",
    "Choisissez un dossier hors de l’ancien dossier des sauvegardes.":
        "Choose a folder outside the old backups folder.",
    "Le nouveau dossier ne peut pas contenir l’ancien : choisissez un dossier à part (la fenêtre permet d’en créer un nouveau).":
        "The new folder cannot contain the old one: choose a separate folder (the dialog lets you create a new one).",
    "Un dossier cloud est dans ce dossier :\n{0}\n\nChoisissez-en un autre.":
        "A cloud folder is inside this folder:\n{0}\n\nChoose another one.",
    "Dossier illisible":
        "Unreadable folder",
    "Ce dossier n’est pas vide":
        "This folder is not empty",
    "Ce dossier contient déjà autre chose : {0}\n\nSes sous-dossiers seraient pris pour des jeux. Mieux vaut un dossier vide (vous pouvez en créer un). L’utiliser quand même ?":
        "This folder already contains something else: {0}\n\nIts subfolders would be mistaken for games. An empty folder is better (you can create one). Use it anyway?",
    "Déplacer les sauvegardes ?":
        "Move the backups?",
    "Déplacer les sauvegardes existantes vers le nouveau dossier ?\n\nOui : elles sont copiées, vérifiées, puis supprimées de l’ancien dossier.\nNon : seul l’emplacement change, les anciennes restent dans\n{0}\n(la liste sera vide tant que vous ne les remettez pas).":
        "Move the existing backups to the new folder?\n\nYes: they are copied, verified, then deleted from the old folder.\nNo: only the location changes, the old ones stay in\n{0}\n(the list will be empty until you put them back).",
    "Déplacement impossible":
        "Move failed",
    "Rien n’a été changé.\n\n":
        "Nothing was changed.\n\n",
    "Réglage impossible":
        "Setting failed",
    "Dossier des sauvegardes : {0}":
        "Backups folder: {0}",
    "⚠ Place du cloud pleine":
        "⚠ Cloud storage full",
    "⚠ Attention : plus de 90 % de la place du cloud est utilisée":
        "⚠ Warning: more than 90 % of the cloud space is used",
    "Cloud : désactivé pour ce jeu":
        "Cloud: disabled for this game",
    "⚠ Cloud : choisissez au moins un dossier cloud (bouton Cloud…), sinon rien n’est envoyé":
        "⚠ Cloud: choose at least one cloud folder (Cloud… button), otherwise nothing is sent",
    "Cloud : envoi automatique vers {0} dossier(s){1}":
        "Cloud: automatic upload to {0} folder(s){1}",
    ", {0} en attente":
        ", {0} waiting",
    "⚠ Limite de place atteinte : envoi arrêté":
        "⚠ Space limit reached: upload stopped",
    "⚠ Limite de place atteinte : {0} ancienne(s) supprimée(s) du cloud":
        "⚠ Space limit reached: {0} old one(s) deleted from the cloud",
    "{0} envoi(s) cloud vérifié(s)":
        "{0} cloud upload(s) verified",
    "{0} en attente (nouvel essai automatique)":
        "{0} waiting (automatic retry)",
    "{0} bloqué(s) : limite de place":
        "{0} blocked: space limit",
    "Cloud : {0} envoi(s) en attente terminé(s) et vérifié(s) ({1:%H:%M})":
        "Cloud: {0} pending upload(s) completed and verified ({1:%H:%M})",
    "Envoi cloud abandonné : {0} / {1} vers {2}":
        "Cloud upload abandoned: {0} / {1} to {2}",
    "Cloud : envoi abandonné":
        "Cloud: upload abandoned",
    "{0} envoi(s) vers le cloud ont échoué après {1} essai(s).\n\nDossier : {2}\n\nVérifiez que ce dossier existe (Drive lancé, disque branché), puis renvoyez ces sauvegardes avec « Envoyer vers le cloud ». Détails dans erreurs.log.":
        "{0} cloud upload(s) failed after {1} attempt(s).\n\nFolder: {2}\n\nCheck that this folder exists (Drive running, disk plugged in), then resend these backups with “Send to cloud”. Details in erreurs.log.",
    "Cloud : ajoutez d’abord un dossier cloud (bouton « Cloud… » en haut).":
        "Cloud: first add a cloud folder (“Cloud…” button at the top).",
    "Cloud : ":
        "Cloud: ",
    "rien à envoyer":
        "nothing to send",
    "Définissez d’abord le chemin de {0} (bouton Dossier… ou Fichiers…) : c’est là que la sauvegarde sera remise.":
        "First set the path for {0} (Folder… or Files… button): that is where the backup will be put back.",
    "Jeu en cours":
        "Game running",
    "{0} est en cours d’exécution. Fermez le jeu (ou l’émulateur) avant d’injecter une sauvegarde, sinon il pourrait la réécrire.":
        "{0} is running. Close the game (or the emulator) before injecting a backup, otherwise it might overwrite it.",
    "Sauvegarde identique":
        "Identical backup",
    "Cette sauvegarde est identique à la sauvegarde actuelle de {0} : l’injecter ne changerait rien.\n\n{1}\n\nVoulez-vous poursuivre quand même ?":
        "This backup is identical to the current save of {0}: injecting it would change nothing.\n\n{1}\n\nDo you want to continue anyway?",
    "Remplacer la sauvegarde actuelle de {0} par celle-ci ?\n\n{1}\n\nEndroit remplacé :\n{2}\n\nL’état actuel est d’abord copié dans la liste « Avant injection », vous pourrez y revenir.":
        "Replace the current save of {0} with this one?\n\n{1}\n\nLocation replaced:\n{2}\n\nThe current state is first copied to the “Before injection” list, so you can go back.",
    "Injection annulée":
        "Injection cancelled",
    "Impossible de garder une copie de l’état actuel : rien n’a été remplacé.\n\n{0}":
        "Could not keep a copy of the current state: nothing was replaced.\n\n{0}",
    "Avant injection ({0}) {1}":
        "Before injection ({0}) {1}",
    "\n\nL’état d’avant est gardé dans la liste : {0}":
        "\n\nThe previous state is kept in the list: {0}",
    "Injection incomplète":
        "Injection incomplete",
    "{0} : {1} injecté et vérifié à {2:%H:%M:%S}":
        "{0}: {1} injected and verified at {2:%H:%M:%S}",
    ", {0} ancienne(s) « avant injection » supprimée(s)":
        ", {0} old “before injection” backup(s) deleted",
    "Cloud":
        "Cloud",
    "Réglages":
        "Settings",
    "Aperçu":
        "Preview",
    "Dossiers cloud":
        "Cloud folders",
    "Choisissez le dossier de Google Drive, OneDrive ou Dropbox sur votre PC (ou n’importe quel autre dossier, même sur un disque externe). L’appli y crée un dossier « Save Games Rw6 ». Retirer un dossier de cette liste ne supprime rien : les fichiers restent où ils sont. Aucun dossier = aucun envoi.":
        "Choose the Google Drive, OneDrive or Dropbox folder on your computer (or any other folder, even on an external drive). The app creates a “Save Games Rw6” folder there. Removing a folder from this list deletes nothing: the files stay where they are. No folder = nothing sent.",
    "Choisissez le dossier cloud (Google Drive, OneDrive, Dropbox…)":
        "Choose the cloud folder (Google Drive, OneDrive, Dropbox…)",
    "Choisissez un dossier hors du dossier « Sauvegardes » de l’appli.":
        "Choose a folder outside the app's “Sauvegardes” folder.",
    "Ajouter un dossier…":
        "Add a folder…",
    "Retirer":
        "Remove",
    "Entrez un nombre de 1 à 999.":
        "Enter a number from 1 to 999.",
    "Réglages par jeu":
        "Settings per game",
    "Seules les sauvegardes AUTOMATIQUES partent toutes seules. Pour les manuelles : sélectionnez-les dans la liste (Ctrl + clic), puis « Envoyer vers le cloud ». Tout est désactivé par défaut.":
        "Only AUTOMATIC backups are sent on their own. For manual ones: select them in the list (Ctrl + click), then “Send to cloud”. Everything is off by default.",
    "Aucun jeu pour l’instant.":
        "No games yet.",
    "Cloud pour tous les jeux":
        "Cloud for all games",
    "Aucun jeu":
        "No game",
    "(« pour tous » coche aussi tous les dossiers cloud des jeux qui n’en ont aucun)":
        "(“for all” also ticks all cloud folders of games that have none)",
    "Garder au maximum pour tous :":
        "Keep at most, for all:",
    "« Garder au maximum » : cocher pour tous":
        "“Keep at most”: tick for all",
    "(« Appliquer le nombre » ne change pas les cases cochées)":
        "(“Apply the number” does not change the ticked boxes)",
    "Envoyer les sauvegardes automatiques de ce jeu vers le cloud":
        "Send this game's automatic backups to the cloud",
    "Envoyer vers (cochez les dossiers cloud où ce jeu doit être copié) :":
        "Send to (tick the cloud folders where this game should be copied):",
    "Ajoutez d’abord un dossier cloud ci-dessus.":
        "First add a cloud folder above.",
    "sauvegardes dans le cloud (manuelles et automatiques), hors favoris ★":
        "backups in the cloud (manual and automatic), excluding favorites ★",
    "Réessayer":
        "Retry",
    "Réessayer toutes les":
        "Retry every",
    ", au maximum":
        ", at most",
    "essais en tout":
        "attempts in total",
    "Sert quand le dossier cloud est introuvable (Drive pas lancé, disque débranché). Sans internet, Drive garde le fichier et l’envoie tout seul plus tard : l’appli n’a rien à réessayer. Après le dernier essai raté, un message s’affiche (c’est le seul cas).":
        "Used when the cloud folder cannot be found (Drive not running, disk unplugged). Without internet, Drive keeps the file and sends it later by itself: the app has nothing to retry. After the last failed attempt, a message is shown (this is the only case).",
    "Place utilisée":
        "Space used",
    "Limiter la place prise par l’appli à":
        "Limit the space used by the app to",
    "Go, dans chaque dossier cloud":
        "GB, in each cloud folder",
    "Si la limite est atteinte : supprimer les plus anciennes sauvegardes du cloud (hors favoris ★)":
        "If the limit is reached: delete the oldest backups from the cloud (excluding favorites ★)",
    "Si la limite est atteinte : arrêter d’envoyer et me prévenir":
        "If the limit is reached: stop sending and warn me",
    "L’appli ne mesure que son propre dossier. Elle ne voit pas le reste de votre Drive (Gmail, Photos…) : les 15 Go gratuits de Google sont partagés.":
        "The app only measures its own folder. It does not see the rest of your Drive (Gmail, Photos…): Google's free 15 GB are shared.",
    "Ce que l’appli voit dans vos dossiers cloud, sur ce PC. Elle ne peut pas savoir si Drive a fini d’envoyer en ligne. Les réglages non enregistrés n’y sont pas.":
        "What the app sees in your cloud folders, on this computer. It cannot know whether Drive has finished uploading online. Unsaved settings are not included.",
    "Dossier cloud / jeu / sauvegarde":
        "Cloud folder / game / backup",
    "Type":
        "Type",
    "Aucun dossier cloud enregistré. Ajoutez-en un dans « Réglages », puis cliquez sur « Enregistrer ».":
        "No cloud folder saved. Add one in “Settings”, then click “Save”.",
    "⚠ Dossier introuvable (Drive pas lancé ? disque débranché ?)":
        "⚠ Folder not found (Drive not running? disk unplugged?)",
    "{0} (introuvable)":
        "{0} (not found)",
    "{0} utilisés sur {1} ({2:.0f} %)":
        "{0} used out of {1} ({2:.0f} %)",
    "{0} utilisés (aucune limite fixée)":
        "{0} used (no limit set)",
    " · {0} av. inj.":
        " · {0} bef. inj.",
    "{0} · {1} manu · {2} auto{3}":
        "{0} · {1} manual · {2} auto{3}",
    "av. inj.":
        "bef. inj.",
    "Vérifiez les nombres : délai 1 à 9999, essais 1 à 99, limite de place 0,1 à 100000 Go.":
        "Check the numbers: delay 1 to 9999, attempts 1 to 99, space limit 0.1 to 100000 GB.",
    "Maximum de sauvegardes pour {0} : un nombre de 1 à 999.":
        "Maximum number of backups for {0}: a number from 1 to 999.",
    "Cloud : réglages enregistrés":
        "Cloud: settings saved",
    "Enregistrer":
        "Save",
    "Sélection":
        "Selection",
    "Cliquez d’abord sur une sauvegarde dans la liste.":
        "First click a backup in the list.",
    "Choisissez une seule sauvegarde pour cette action.":
        "Choose a single backup for this action.",
    "Note pour la sauvegarde {0} :\n(laisser vide pour l’effacer)":
        "Note for backup {0}:\n(leave empty to clear it)",
    "Injecter dans le jeu…":
        "Inject into the game…",
    "Retirer des favoris":
        "Remove from favorites",
    "★ Ajouter aux favoris":
        "★ Add to favorites",
    "{0} sauvegarde(s) retirée(s) des favoris":
        "{0} backup(s) removed from favorites",
    "{0} sauvegarde(s) protégée(s) ★":
        "{0} backup(s) protected ★",
    "Copier la sauvegarde vers…":
        "Copy the backup to…",
    "Copier les {0} sauvegardes vers…":
        "Copy the {0} backups to…",
    "{0} : copie différente de l’original, supprimée ({1})":
        "{0}: copy differs from the original, deleted ({1})",
    "Copie incomplète":
        "Incomplete copy",
    "{0} copiée(s), {1} en erreur :\n\n":
        "{0} copied, {1} failed:\n\n",
    "{0} copiée(s) et vérifiée(s) vers {1}":
        "{0} copied and verified to {1}",
    "Supprimer définitivement cette sauvegarde ?\n{0} – {1}":
        "Permanently delete this backup?\n{0} – {1}",
    "\n… et {0} autres":
        "\n… and {0} more",
    "Supprimer définitivement ces {0} sauvegardes ?\n\n{1}{2}":
        "Permanently delete these {0} backups?\n\n{1}{2}",
    "Favoris protégés":
        "Protected favorites",
    "{0} favori(s) dans la sélection :\n\n{1}{2}\n\nLes supprimer aussi ?\n\nOui : tout est supprimé, favoris compris.\nNon : les favoris sont gardés, le reste est supprimé.":
        "{0} favorite(s) in the selection:\n\n{1}{2}\n\nDelete them too?\n\nYes: everything is deleted, favorites included.\nNo: favorites are kept, the rest is deleted.",
    "Suppression incomplète":
        "Deletion incomplete",
    "Impossible de supprimer entièrement :\n":
        "Could not delete completely:\n",
    "\n\nUn fichier est peut-être ouvert ailleurs (Explorateur, jeu…).":
        "\n\nA file may be open elsewhere (file explorer, game…).",
    "{0} sauvegarde(s) supprimée(s)":
        "{0} backup(s) deleted",
    "Erreur au lancement":
        "Error on startup",
    "lun":
        "Mon",
    "mar":
        "Tue",
    "mer":
        "Wed",
    "jeu":
        "Thu",
    "ven":
        "Fri",
    "sam":
        "Sat",
    "dim":
        "Sun",
    "heures":
        "hours",
    "jours":
        "days",
    "semaines":
        "weeks",
    "minutes":
        "minutes",
    "heure":
        "hour",
    "jour":
        "day",
    "semaine":
        "week",
    "minute":
        "minute",
    "manuelles":
        "Manual",
    "automatiques":
        "Automatic",
    "manuelle":
        "manual",
    "Sauvegarde automatique : ":
        "Automatic backup: ",
    "auto, ":
        "auto, ",
    "{0:%d/%m/%Y à %H:%M:%S}":
        "{0:%Y-%m-%d %H:%M:%S}",
    "{0:%d/%m/%Y à %H:%M}":
        "{0:%Y-%m-%d %H:%M}",
    "{0:%d/%m/%Y %H:%M}":
        "{0:%Y-%m-%d %H:%M}",
    "Lancer à l’ouverture de session":
        "Start at login",
    "Démarrage automatique":
        "Automatic startup",
    "L’appli se lancera à l’ouverture de session (réduite).":
        "The app will start at login (minimized).",
    "L’appli ne se lancera plus à l’ouverture de session.":
        "The app will no longer start at login.",
    "Glisser-déposer : lancez install.sh pour installer tkinterdnd2, puis relancez.":
        "Drag and drop: run install.sh to install tkinterdnd2, then restart.",
    "La croix devrait masquer l’appli, mais l’icône système n’est pas disponible (module « pystray » absent, ou bureau sans zone de notification).\n\nPour installer le module : lancez install.sh dans le dossier de l’appli, puis relancez l’appli.\n\nFermer l’appli maintenant ?":
        "The close button should hide the app, but the system tray icon is not available (“pystray” module missing, or a desktop without a notification area).\n\nTo install the module: run install.sh in the app folder, then restart the app.\n\nClose the app now?",
    "La fenêtre va disparaître, mais l’appli continue de tourner (les sauvegardes automatiques aussi).\n\nPour la rouvrir : relancez l’appli (lanceur « Save Games Rw6 »), la fenêtre déjà ouverte réapparaîtra.\nPour une icône système : lancez install.sh\n\nMasquer maintenant ?":
        "The window will disappear, but the app keeps running (automatic backups too).\n\nTo reopen it: launch the app again (“Save Games Rw6” launcher), the window that is already open will reappear.\nFor a tray icon: run install.sh\n\nHide now?",
    "La liste des programmes n’est pas disponible ici. Tapez le nom du programme à la main.":
        "The list of programs is not available here. Type the program name by hand.",
}

# (défini ici car il dépend des traductions)
COLUMNS = (("fav", "★", 36, False, "center"), ("jeu", T("Jeu"), 110, False, "w"),
           ("date", T("Date"), 190, False, "w"), ("taille", T("Taille"), 90, False, "w"),
           ("note", T("Note"), 260, True, "w"))


if __name__ == "__main__":
    if sys.platform.startswith("win"):
        try:  # identité propre à l’appli, pour que la barre des tâches affiche NOTRE icône et non celle de Python
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Rw6.SaveGames")
        except Exception:
            pass
    try:
        if "--relance" in sys.argv:   # relancée par le menu de langue : on attend que l’ancienne fenêtre ait fini de se fermer
            for _ in range(40):
                if not signal_running_instance(show=False):
                    break
                time.sleep(0.25)
        if signal_running_instance(show="--reduit" not in sys.argv):
            sys.exit(0)   # déjà lancée : on a juste réaffiché sa fenêtre
        holder = {"app": None, "pending": False}

        def on_show():   # appelé quand l’appli est relancée une 2e fois
            app = holder["app"]
            if app is None:
                holder["pending"] = True
            else:
                try:
                    app.after(0, app.show_window)
                except Exception:
                    pass

        server = listen_for_instances(on_show)
        try:
            BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        except OSError:
            log_error(f"Dossier des sauvegardes inaccessible : {BACKUP_DIR}")   # disque débranché : l’appli le signale
        migrate_old_names()
        app = App()
        holder["app"] = app
        if holder["pending"]:
            app.after(500, app.show_window)
        app.mainloop()
    except Exception as e:
        import traceback
        log_error(traceback.format_exc())
        try:
            messagebox.showerror(T("Erreur au lancement"), T("{0}\n"
                    "\n"
                    "Détails dans le fichier erreurs.log, à côté de l’appli.", e))
        except Exception:
            pass
