#!/usr/bin/env bash
# Lance Save Games Rw6 / Starts Save Games Rw6
cd "$(dirname "$(readlink -f "$0")")" || exit 1
if [ -x .venv/bin/python ]; then
    exec .venv/bin/python save_games_rw6.py "$@"
fi
exec python3 save_games_rw6.py "$@"
