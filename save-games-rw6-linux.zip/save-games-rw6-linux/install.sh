#!/usr/bin/env bash
# Save Games Rw6 - installation Linux / Linux installation
# Installe tout dans ce dossier (.venv) et ajoute un lanceur au menu des applications. Rien n'est installe en global.
# Installs everything in this folder (.venv) and adds a launcher to the applications menu. Nothing is installed globally.
set -u
cd "$(dirname "$(readlink -f "$0")")" || exit 1
APP_DIR="$(pwd)"

case "${LC_ALL:-${LC_MESSAGES:-${LANG:-}}}" in fr*) FR=1 ;; *) FR=0 ;; esac
say() { if [ "$FR" = 1 ]; then printf '%s\n' "$1"; else printf '%s\n' "$2"; fi; }

pkg_hint() {  # $1 = apt, $2 = dnf, $3 = pacman, $4 = zypper
    if command -v apt >/dev/null 2>&1; then echo "sudo apt install $1"
    elif command -v dnf >/dev/null 2>&1; then echo "sudo dnf install $2"
    elif command -v pacman >/dev/null 2>&1; then echo "sudo pacman -S $3"
    elif command -v zypper >/dev/null 2>&1; then echo "sudo zypper install $4"
    else echo ""; fi
}

echo
say "== Save Games Rw6 : installation Linux ==" "== Save Games Rw6: Linux installation =="
echo

# 1. Python 3
if ! command -v python3 >/dev/null 2>&1; then
    say "Python 3 est introuvable. Installe-le, puis relance ./install.sh" "Python 3 was not found. Install it, then run ./install.sh again."
    h="$(pkg_hint python3 python3 python python3)"; [ -n "$h" ] && echo "  $h"
    exit 1
fi
say "Python trouve : $(python3 --version 2>&1)" "Python found: $(python3 --version 2>&1)"

# 2. tkinter (l'interface)
if ! python3 -c "import tkinter" >/dev/null 2>&1; then
    say "tkinter (l'interface graphique de Python) est absent. Installe-le, puis relance ./install.sh :" \
        "tkinter (Python's graphical interface) is missing. Install it, then run ./install.sh again:"
    h="$(pkg_hint python3-tk python3-tkinter tk python3-tk)"; [ -n "$h" ] && echo "  $h"
    exit 1
fi

# 3. environnement Python local (avec les modules du systeme : tkinter, et AppIndicator si present)
if [ ! -x .venv/bin/python ]; then
    say "Creation de l'environnement Python local (.venv)..." "Creating the local Python environment (.venv)..."
    if ! python3 -m venv --system-site-packages .venv; then
        say "Impossible de creer .venv. Installe le module venv, puis relance ./install.sh :" \
            "Could not create .venv. Install the venv module, then run ./install.sh again:"
        h="$(pkg_hint python3-venv python3 python python3)"; [ -n "$h" ] && echo "  $h"
        rm -rf .venv
        exit 1
    fi
fi

# 4. modules facultatifs (glisser-deposer, icone systeme)
say "Installation de tkinterdnd2 et pystray..." "Installing tkinterdnd2 and pystray..."
if .venv/bin/python -m pip install --quiet --disable-pip-version-check tkinterdnd2 pystray; then
    say "Modules installes." "Modules installed."
else
    say "ATTENTION : installation des modules impossible (pas d'internet ?). L'appli marchera, sans glisser-deposer ni icone systeme. Relance ./install.sh plus tard." \
        "WARNING: could not install the modules (no internet?). The app will work, without drag and drop or the tray icon. Run ./install.sh again later."
fi

# 5. lanceurs
chmod +x save-games-rw6.sh desinstaller.sh reinitialiser_fenetre.sh save_games_rw6.py 2>/dev/null
mkdir -p "$HOME/.local/share/applications"
ICON="document-save"; [ -f "$APP_DIR/icone.png" ] && ICON="$APP_DIR/icone.png"
cat > "$HOME/.local/share/applications/save-games-rw6.desktop" <<DESKTOP
[Desktop Entry]
Type=Application
Name=Save Games Rw6
Comment=Backups of your game saves / Sauvegardes de vos jeux
Exec="$APP_DIR/save-games-rw6.sh"
Path=$APP_DIR
Icon=$ICON
Terminal=false
Categories=Utility;Game;
DESKTOP
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1

echo
say "Termine ! Lance « Save Games Rw6 » depuis le menu des applications," "Done! Start “Save Games Rw6” from the applications menu,"
say "ou dans un terminal : ./save-games-rw6.sh" "or in a terminal: ./save-games-rw6.sh"
say "(Si le lanceur n'apparait pas tout de suite, ferme et rouvre ta session.)" "(If the launcher does not show up right away, log out and back in.)"
