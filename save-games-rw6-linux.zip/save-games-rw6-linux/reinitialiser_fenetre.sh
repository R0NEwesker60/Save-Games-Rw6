#!/usr/bin/env bash
# Remet la fenetre a sa taille et a sa place d'origine. / Resets the window size and position.
cd "$(dirname "$(readlink -f "$0")")" || exit 1
rm -f fenetre.json
echo "Fenetre reinitialisee. Relance l'appli. / Window reset. Start the app again."
